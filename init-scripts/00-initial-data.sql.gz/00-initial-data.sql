--
-- PostgreSQL database cluster dump
--

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

-- CREATE ROLE metabase;
ALTER ROLE metabase WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:q6I+kFfdgJM+1RLWg0MhHQ==$eYPdGQSo847brlsFeUJkMuNUYXhx+o/l5QSiSg6dbrY=:jsqHNCu5T1L4vnmGfm5BLgv+Lv3xFH8SFazD9s4rwFo=';

--
-- User Configurations
--








--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "metabase" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: metabase; Type: DATABASE; Schema: -; Owner: metabase
--

-- CREATE DATABASE metabase WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE metabase OWNER TO metabase;

\connect metabase

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- Database "metabase_app" dump
--

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: metabase_app; Type: DATABASE; Schema: -; Owner: metabase
--

CREATE DATABASE metabase_app WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE metabase_app OWNER TO metabase;

\connect metabase_app

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: action; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.action (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    type text NOT NULL,
    model_id integer NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    parameters text,
    parameter_mappings text,
    visualization_settings text,
    public_uuid character(36),
    made_public_by_id integer,
    creator_id integer,
    archived boolean DEFAULT false NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.action OWNER TO metabase;

--
-- Name: TABLE action; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.action IS 'An action is something you can do, such as run a readwrite query';


--
-- Name: COLUMN action.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.created_at IS 'The timestamp of when the action was created';


--
-- Name: COLUMN action.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.updated_at IS 'The timestamp of when the action was updated';


--
-- Name: COLUMN action.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.type IS 'Type of action';


--
-- Name: COLUMN action.model_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.model_id IS 'The associated model';


--
-- Name: COLUMN action.name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.name IS 'The name of the action';


--
-- Name: COLUMN action.description; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.description IS 'The description of the action';


--
-- Name: COLUMN action.parameters; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.parameters IS 'The saved parameters for this action';


--
-- Name: COLUMN action.parameter_mappings; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.parameter_mappings IS 'The saved parameter mappings for this action';


--
-- Name: COLUMN action.visualization_settings; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.visualization_settings IS 'The UI visualization_settings for this action';


--
-- Name: COLUMN action.public_uuid; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.public_uuid IS 'Unique UUID used to in publically-accessible links to this Action.';


--
-- Name: COLUMN action.made_public_by_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.made_public_by_id IS 'The ID of the User who first publically shared this Action.';


--
-- Name: COLUMN action.creator_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.creator_id IS 'The user who created the action';


--
-- Name: COLUMN action.archived; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.archived IS 'Whether or not the action has been archived';


--
-- Name: COLUMN action.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.action.entity_id IS 'Random NanoID tag for unique identity.';


--
-- Name: action_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.action ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.action_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.api_key (
    id integer NOT NULL,
    user_id integer,
    key character varying(254) NOT NULL,
    key_prefix character varying(7) NOT NULL,
    creator_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(254) NOT NULL,
    updated_by_id integer NOT NULL,
    scope character varying(64)
);


ALTER TABLE public.api_key OWNER TO metabase;

--
-- Name: TABLE api_key; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.api_key IS 'An API Key';


--
-- Name: COLUMN api_key.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.id IS 'The ID of the API Key itself';


--
-- Name: COLUMN api_key.user_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.user_id IS 'The ID of the user who this API Key acts as';


--
-- Name: COLUMN api_key.key; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.key IS 'The hashed API key';


--
-- Name: COLUMN api_key.key_prefix; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.key_prefix IS 'The first 7 characters of the unhashed key';


--
-- Name: COLUMN api_key.creator_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.creator_id IS 'The ID of the user that created this API key';


--
-- Name: COLUMN api_key.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.created_at IS 'The timestamp when the key was created';


--
-- Name: COLUMN api_key.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.updated_at IS 'The timestamp when the key was last updated';


--
-- Name: COLUMN api_key.name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.name IS 'The user-defined name of the API key.';


--
-- Name: COLUMN api_key.updated_by_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.updated_by_id IS 'The ID of the user that last updated this API key';


--
-- Name: COLUMN api_key.scope; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.api_key.scope IS 'The scope of the API key, if applicable';


--
-- Name: api_key_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.api_key ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_key_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: application_permissions_revision; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.application_permissions_revision (
    id integer NOT NULL,
    before text NOT NULL,
    after text NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    remark text
);


ALTER TABLE public.application_permissions_revision OWNER TO metabase;

--
-- Name: application_permissions_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.application_permissions_revision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.application_permissions_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    topic character varying(32) NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    end_timestamp timestamp with time zone,
    user_id integer,
    model character varying(32),
    model_id integer,
    details text NOT NULL
);


ALTER TABLE public.audit_log OWNER TO metabase;

--
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.audit_log IS 'Used to store application events for auditing use cases';


--
-- Name: COLUMN audit_log.topic; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log.topic IS 'The topic of a given audit event';


--
-- Name: COLUMN audit_log."timestamp"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log."timestamp" IS 'The time an event was recorded';


--
-- Name: COLUMN audit_log.end_timestamp; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log.end_timestamp IS 'The time an event ended, if applicable';


--
-- Name: COLUMN audit_log.user_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log.user_id IS 'The user who performed an action or triggered an event';


--
-- Name: COLUMN audit_log.model; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log.model IS 'The name of the model this event applies to (e.g. Card, Dashboard), if applicable';


--
-- Name: COLUMN audit_log.model_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log.model_id IS 'The ID of the model this event applies to, if applicable';


--
-- Name: COLUMN audit_log.details; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.audit_log.details IS 'A JSON map with metadata about the event';


--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.audit_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: bookmark_ordering; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.bookmark_ordering (
    id integer NOT NULL,
    user_id integer NOT NULL,
    type character varying(255) NOT NULL,
    item_id integer NOT NULL,
    ordering integer NOT NULL
);


ALTER TABLE public.bookmark_ordering OWNER TO metabase;

--
-- Name: bookmark_ordering_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.bookmark_ordering ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.bookmark_ordering_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cache_config; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.cache_config (
    id integer NOT NULL,
    model character varying(32) NOT NULL,
    model_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    strategy text NOT NULL,
    config text NOT NULL,
    state text,
    invalidated_at timestamp with time zone,
    next_run_at timestamp with time zone,
    refresh_automatically boolean DEFAULT false
);


ALTER TABLE public.cache_config OWNER TO metabase;

--
-- Name: TABLE cache_config; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.cache_config IS 'Cache Configuration';


--
-- Name: COLUMN cache_config.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.id IS 'Unique ID';


--
-- Name: COLUMN cache_config.model; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.model IS 'Name of an entity model';


--
-- Name: COLUMN cache_config.model_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.model_id IS 'ID of the said entity';


--
-- Name: COLUMN cache_config.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.created_at IS 'Timestamp when the config was inserted';


--
-- Name: COLUMN cache_config.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.updated_at IS 'Timestamp when the config was updated';


--
-- Name: COLUMN cache_config.strategy; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.strategy IS 'caching strategy name';


--
-- Name: COLUMN cache_config.config; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.config IS 'caching strategy configuration';


--
-- Name: COLUMN cache_config.state; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.state IS 'state for strategies needing to keep some data between runs';


--
-- Name: COLUMN cache_config.invalidated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.invalidated_at IS 'indicates when a cache was invalidated last time for schedule-based strategies';


--
-- Name: COLUMN cache_config.next_run_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.next_run_at IS 'keeps next time to run for schedule-based strategies';


--
-- Name: COLUMN cache_config.refresh_automatically; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cache_config.refresh_automatically IS 'Whether or not we should automatically refresh cache results when a cache expires';


--
-- Name: cache_config_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.cache_config ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cache_config_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: card_bookmark; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.card_bookmark (
    id integer NOT NULL,
    user_id integer NOT NULL,
    card_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.card_bookmark OWNER TO metabase;

--
-- Name: card_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.card_bookmark ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.card_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: card_label; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.card_label (
    id integer NOT NULL,
    card_id integer NOT NULL,
    label_id integer NOT NULL
);


ALTER TABLE public.card_label OWNER TO metabase;

--
-- Name: card_label_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.card_label ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.card_label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.channel (
    id integer NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    type character varying(32) NOT NULL,
    details text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.channel OWNER TO metabase;

--
-- Name: TABLE channel; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.channel IS 'Channel configurations';


--
-- Name: COLUMN channel.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.id IS 'Unique ID';


--
-- Name: COLUMN channel.name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.name IS 'channel name';


--
-- Name: COLUMN channel.description; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.description IS 'channel description';


--
-- Name: COLUMN channel.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.type IS 'Channel type';


--
-- Name: COLUMN channel.details; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.details IS 'Channel details, used to store authentication information or channel-specific settings';


--
-- Name: COLUMN channel.active; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.active IS 'whether the channel is active';


--
-- Name: COLUMN channel.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.created_at IS 'Timestamp when the channel was inserted';


--
-- Name: COLUMN channel.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel.updated_at IS 'Timestamp when the channel was updated';


--
-- Name: channel_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.channel ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.channel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: channel_template; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.channel_template (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    channel_type character varying(64) NOT NULL,
    details text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.channel_template OWNER TO metabase;

--
-- Name: TABLE channel_template; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.channel_template IS 'custom template for the channel';


--
-- Name: COLUMN channel_template.name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel_template.name IS 'the name of the template';


--
-- Name: COLUMN channel_template.channel_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel_template.channel_type IS 'the channel type of the template';


--
-- Name: COLUMN channel_template.details; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel_template.details IS 'the details of the template';


--
-- Name: COLUMN channel_template.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel_template.created_at IS 'The timestamp of when the template was created';


--
-- Name: COLUMN channel_template.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.channel_template.updated_at IS 'The timestamp of when the template was last updated';


--
-- Name: channel_template_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.channel_template ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.channel_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cloud_migration; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.cloud_migration (
    id integer NOT NULL,
    external_id text NOT NULL,
    upload_url text NOT NULL,
    state character varying(32) DEFAULT 'init'::character varying NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.cloud_migration OWNER TO metabase;

--
-- Name: TABLE cloud_migration; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.cloud_migration IS 'Migrate to cloud directly from Metabase';


--
-- Name: COLUMN cloud_migration.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.id IS 'Unique ID';


--
-- Name: COLUMN cloud_migration.external_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.external_id IS 'Matching ID in Cloud for this migration';


--
-- Name: COLUMN cloud_migration.upload_url; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.upload_url IS 'URL where the backup will be uploaded to';


--
-- Name: COLUMN cloud_migration.state; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.state IS 'Current state of the migration: init, setup, dump, upload, done, error, cancelled';


--
-- Name: COLUMN cloud_migration.progress; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.progress IS 'Number between 0 to 100 representing progress as a percentage';


--
-- Name: COLUMN cloud_migration.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.created_at IS 'Timestamp when the config was inserted';


--
-- Name: COLUMN cloud_migration.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.cloud_migration.updated_at IS 'Timestamp when the config was updated';


--
-- Name: cloud_migration_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.cloud_migration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.cloud_migration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: collection; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.collection (
    id integer NOT NULL,
    name text NOT NULL,
    description text,
    archived boolean DEFAULT false NOT NULL,
    location character varying(254) DEFAULT '/'::character varying NOT NULL,
    personal_owner_id integer,
    slug character varying(510) NOT NULL,
    namespace character varying(254),
    authority_level character varying(255),
    entity_id character(21),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    type character varying(256),
    is_sample boolean DEFAULT false NOT NULL,
    archive_operation_id character(36),
    archived_directly boolean
);


ALTER TABLE public.collection OWNER TO metabase;

--
-- Name: COLUMN collection.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.collection.created_at IS 'Timestamp of when this Collection was created.';


--
-- Name: COLUMN collection.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.collection.type IS 'This is used to differentiate instance-analytics collections from all other collections.';


--
-- Name: COLUMN collection.is_sample; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.collection.is_sample IS 'Is the collection part of the sample content?';


--
-- Name: COLUMN collection.archive_operation_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.collection.archive_operation_id IS 'The UUID of the trash operation. Each time you trash a collection subtree, you get a unique ID.';


--
-- Name: COLUMN collection.archived_directly; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.collection.archived_directly IS 'Whether the item was trashed independently or as a subcollection';


--
-- Name: collection_bookmark; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.collection_bookmark (
    id integer NOT NULL,
    user_id integer NOT NULL,
    collection_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.collection_bookmark OWNER TO metabase;

--
-- Name: collection_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.collection_bookmark ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.collection_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: collection_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.collection ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.collection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: collection_permission_graph_revision; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.collection_permission_graph_revision (
    id integer NOT NULL,
    before text NOT NULL,
    after text NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    remark text
);


ALTER TABLE public.collection_permission_graph_revision OWNER TO metabase;

--
-- Name: collection_permission_graph_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.collection_permission_graph_revision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.collection_permission_graph_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: connection_impersonations; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.connection_impersonations (
    id integer NOT NULL,
    db_id integer NOT NULL,
    group_id integer NOT NULL,
    attribute text
);


ALTER TABLE public.connection_impersonations OWNER TO metabase;

--
-- Name: TABLE connection_impersonations; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.connection_impersonations IS 'Table for holding connection impersonation policies';


--
-- Name: COLUMN connection_impersonations.db_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.connection_impersonations.db_id IS 'ID of the database this connection impersonation policy affects';


--
-- Name: COLUMN connection_impersonations.group_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.connection_impersonations.group_id IS 'ID of the permissions group this connection impersonation policy affects';


--
-- Name: COLUMN connection_impersonations.attribute; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.connection_impersonations.attribute IS 'User attribute associated with the database role to use for this connection impersonation policy';


--
-- Name: connection_impersonations_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.connection_impersonations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.connection_impersonations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_session; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.core_session (
    id character varying(254) NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    anti_csrf_token text,
    key_hashed character varying(254) NOT NULL
);


ALTER TABLE public.core_session OWNER TO metabase;

--
-- Name: COLUMN core_session.key_hashed; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.core_session.key_hashed IS 'Hashed version of the session key';


--
-- Name: core_user; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.core_user (
    id integer NOT NULL,
    email public.citext NOT NULL,
    first_name character varying(254),
    last_name character varying(254),
    password character varying(254),
    password_salt character varying(254) DEFAULT 'default'::character varying,
    date_joined timestamp with time zone NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    reset_token character varying(254),
    reset_triggered bigint,
    is_qbnewb boolean DEFAULT true NOT NULL,
    login_attributes text,
    updated_at timestamp with time zone,
    sso_source character varying(254),
    locale character varying(5),
    is_datasetnewb boolean DEFAULT true NOT NULL,
    settings text,
    type character varying(64) DEFAULT 'personal'::character varying NOT NULL,
    entity_id character(21),
    deactivated_at timestamp with time zone
);


ALTER TABLE public.core_user OWNER TO metabase;

--
-- Name: COLUMN core_user.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.core_user.type IS 'The type of user';


--
-- Name: COLUMN core_user.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.core_user.entity_id IS 'NanoID tag for each user';


--
-- Name: COLUMN core_user.deactivated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.core_user.deactivated_at IS 'The timestamp at which a user was deactivated';


--
-- Name: core_user_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.core_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dashboard_bookmark; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.dashboard_bookmark (
    id integer NOT NULL,
    user_id integer NOT NULL,
    dashboard_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dashboard_bookmark OWNER TO metabase;

--
-- Name: dashboard_bookmark_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.dashboard_bookmark ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dashboard_bookmark_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dashboard_favorite; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.dashboard_favorite (
    id integer NOT NULL,
    user_id integer NOT NULL,
    dashboard_id integer NOT NULL
);


ALTER TABLE public.dashboard_favorite OWNER TO metabase;

--
-- Name: dashboard_favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.dashboard_favorite ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dashboard_favorite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dashboard_tab; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.dashboard_tab (
    id integer NOT NULL,
    dashboard_id integer NOT NULL,
    name text NOT NULL,
    "position" integer NOT NULL,
    entity_id character(21),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.dashboard_tab OWNER TO metabase;

--
-- Name: TABLE dashboard_tab; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.dashboard_tab IS 'Join table connecting dashboard to dashboardcards';


--
-- Name: COLUMN dashboard_tab.dashboard_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.dashboard_tab.dashboard_id IS 'The dashboard that a tab is on';


--
-- Name: COLUMN dashboard_tab.name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.dashboard_tab.name IS 'Displayed name of the tab';


--
-- Name: COLUMN dashboard_tab."position"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.dashboard_tab."position" IS 'Position of the tab with respect to others tabs in dashboard';


--
-- Name: COLUMN dashboard_tab.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.dashboard_tab.entity_id IS 'Random NanoID tag for unique identity.';


--
-- Name: COLUMN dashboard_tab.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.dashboard_tab.created_at IS 'The timestamp at which the tab was created';


--
-- Name: COLUMN dashboard_tab.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.dashboard_tab.updated_at IS 'The timestamp at which the tab was last updated';


--
-- Name: dashboard_tab_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.dashboard_tab ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dashboard_tab_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dashboardcard_series; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.dashboardcard_series (
    id integer NOT NULL,
    dashboardcard_id integer NOT NULL,
    card_id integer NOT NULL,
    "position" integer NOT NULL
);


ALTER TABLE public.dashboardcard_series OWNER TO metabase;

--
-- Name: dashboardcard_series_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.dashboardcard_series ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dashboardcard_series_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: data_permissions; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.data_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    perm_type character varying(64) NOT NULL,
    db_id integer NOT NULL,
    schema_name character varying(254),
    table_id integer,
    perm_value character varying(64) NOT NULL
);


ALTER TABLE public.data_permissions OWNER TO metabase;

--
-- Name: TABLE data_permissions; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.data_permissions IS 'A table to store database and table permissions';


--
-- Name: COLUMN data_permissions.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.id IS 'The ID of the permission';


--
-- Name: COLUMN data_permissions.group_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.group_id IS 'The ID of the associated permission group';


--
-- Name: COLUMN data_permissions.perm_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.perm_type IS 'The type of the permission (e.g. "data", "collection", "download"...)';


--
-- Name: COLUMN data_permissions.db_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.db_id IS 'A database ID, for DB and table-level permissions';


--
-- Name: COLUMN data_permissions.schema_name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.schema_name IS 'A schema name, for table-level permissions';


--
-- Name: COLUMN data_permissions.table_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.table_id IS 'A table ID';


--
-- Name: COLUMN data_permissions.perm_value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.data_permissions.perm_value IS 'The value this permission is set to.';


--
-- Name: data_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.data_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.data_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: databasechangelog; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.databasechangelog (
    id character varying(255) NOT NULL,
    author character varying(255) NOT NULL,
    filename character varying(255) NOT NULL,
    dateexecuted timestamp without time zone NOT NULL,
    orderexecuted integer NOT NULL,
    exectype character varying(10) NOT NULL,
    md5sum character varying(35),
    description character varying(255),
    comments character varying(255),
    tag character varying(255),
    liquibase character varying(20),
    contexts character varying(255),
    labels character varying(255),
    deployment_id character varying(10)
);


ALTER TABLE public.databasechangelog OWNER TO metabase;

--
-- Name: dependency; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.dependency (
    id integer NOT NULL,
    model character varying(32) NOT NULL,
    model_id integer NOT NULL,
    dependent_on_model character varying(32) NOT NULL,
    dependent_on_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL
);


ALTER TABLE public.dependency OWNER TO metabase;

--
-- Name: dependency_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.dependency ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dependency_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: dimension; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.dimension (
    id integer NOT NULL,
    field_id integer NOT NULL,
    name character varying(254) NOT NULL,
    type character varying(254) NOT NULL,
    human_readable_field_id integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.dimension OWNER TO metabase;

--
-- Name: dimension_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.dimension ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dimension_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: field_usage; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.field_usage (
    id integer NOT NULL,
    field_id integer NOT NULL,
    query_execution_id integer NOT NULL,
    used_in character varying(25) NOT NULL,
    filter_op character varying(25),
    aggregation_function character varying(25),
    breakout_temporal_unit character varying(25),
    breakout_binning_strategy character varying(25),
    breakout_binning_num_bins integer,
    breakout_binning_bin_width integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.field_usage OWNER TO metabase;

--
-- Name: TABLE field_usage; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.field_usage IS 'Used to store field usage during query execution';


--
-- Name: COLUMN field_usage.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.id IS 'Unique ID';


--
-- Name: COLUMN field_usage.field_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.field_id IS 'ID of the field';


--
-- Name: COLUMN field_usage.query_execution_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.query_execution_id IS 'referenced query execution';


--
-- Name: COLUMN field_usage.used_in; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.used_in IS 'which part of the query the field was used in';


--
-- Name: COLUMN field_usage.filter_op; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.filter_op IS 'filter''s operator that applied to the field';


--
-- Name: COLUMN field_usage.aggregation_function; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.aggregation_function IS 'the aggregation function that field applied to';


--
-- Name: COLUMN field_usage.breakout_temporal_unit; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.breakout_temporal_unit IS 'temporal unit options of the breakout';


--
-- Name: COLUMN field_usage.breakout_binning_strategy; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.breakout_binning_strategy IS 'the strategy of breakout';


--
-- Name: COLUMN field_usage.breakout_binning_num_bins; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.breakout_binning_num_bins IS 'The numbin option of breakout';


--
-- Name: COLUMN field_usage.breakout_binning_bin_width; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.breakout_binning_bin_width IS 'The numbin option of breakout';


--
-- Name: COLUMN field_usage.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.field_usage.created_at IS 'The time a field usage was recorded';


--
-- Name: field_usage_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.field_usage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.field_usage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sandboxes; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.sandboxes (
    id integer NOT NULL,
    group_id integer NOT NULL,
    table_id integer NOT NULL,
    card_id integer,
    attribute_remappings text
);


ALTER TABLE public.sandboxes OWNER TO metabase;

--
-- Name: group_table_access_policy_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.sandboxes ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.group_table_access_policy_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: http_action; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.http_action (
    action_id integer NOT NULL,
    template text NOT NULL,
    response_handle text,
    error_handle text
);


ALTER TABLE public.http_action OWNER TO metabase;

--
-- Name: TABLE http_action; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.http_action IS 'An http api call type of action';


--
-- Name: COLUMN http_action.action_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.http_action.action_id IS 'The related action';


--
-- Name: COLUMN http_action.template; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.http_action.template IS 'A template that defines method,url,body,headers required to make an api call';


--
-- Name: COLUMN http_action.response_handle; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.http_action.response_handle IS 'A program to take an api response and transform to an appropriate response for emitters';


--
-- Name: COLUMN http_action.error_handle; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.http_action.error_handle IS 'A program to take an api response to determine if an error occurred';


--
-- Name: implicit_action; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.implicit_action (
    action_id integer NOT NULL,
    kind text NOT NULL
);


ALTER TABLE public.implicit_action OWNER TO metabase;

--
-- Name: TABLE implicit_action; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.implicit_action IS 'An action with dynamic parameters based on the underlying model';


--
-- Name: COLUMN implicit_action.action_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.implicit_action.action_id IS 'The associated action';


--
-- Name: COLUMN implicit_action.kind; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.implicit_action.kind IS 'The kind of implicit action create/update/delete';


--
-- Name: label; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.label (
    id integer NOT NULL,
    name character varying(254) NOT NULL,
    slug character varying(254) NOT NULL,
    icon character varying(128)
);


ALTER TABLE public.label OWNER TO metabase;

--
-- Name: label_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.label ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.label_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: login_history; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.login_history (
    id integer NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    user_id integer NOT NULL,
    session_id character varying(254),
    device_id character(36) NOT NULL,
    device_description text NOT NULL,
    ip_address text NOT NULL
);


ALTER TABLE public.login_history OWNER TO metabase;

--
-- Name: login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.login_history ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.login_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: metabase_cluster_lock; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metabase_cluster_lock (
    lock_name character varying(254) NOT NULL
);


ALTER TABLE public.metabase_cluster_lock OWNER TO metabase;

--
-- Name: TABLE metabase_cluster_lock; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.metabase_cluster_lock IS 'A table to allow metabase instances to take locks across a cluster';


--
-- Name: COLUMN metabase_cluster_lock.lock_name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_cluster_lock.lock_name IS 'a single column that can be used to a lock across a cluster';


--
-- Name: metabase_database; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metabase_database (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    details text NOT NULL,
    engine character varying(254) NOT NULL,
    is_sample boolean DEFAULT false NOT NULL,
    is_full_sync boolean DEFAULT true NOT NULL,
    points_of_interest text,
    caveats text,
    metadata_sync_schedule character varying(254) DEFAULT '0 50 * * * ? *'::character varying NOT NULL,
    cache_field_values_schedule character varying(254) DEFAULT NULL::character varying,
    timezone character varying(254),
    is_on_demand boolean DEFAULT false NOT NULL,
    auto_run_queries boolean DEFAULT true NOT NULL,
    refingerprint boolean,
    cache_ttl integer,
    initial_sync_status character varying(32) DEFAULT 'complete'::character varying NOT NULL,
    creator_id integer,
    settings text,
    dbms_version text,
    is_audit boolean DEFAULT false NOT NULL,
    uploads_enabled boolean DEFAULT false NOT NULL,
    uploads_schema_name text,
    uploads_table_prefix text,
    is_attached_dwh boolean DEFAULT false NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.metabase_database OWNER TO metabase;

--
-- Name: COLUMN metabase_database.dbms_version; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.dbms_version IS 'A JSON object describing the flavor and version of the DBMS.';


--
-- Name: COLUMN metabase_database.is_audit; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.is_audit IS 'Only the app db, visible to admins via auditing should have this set true.';


--
-- Name: COLUMN metabase_database.uploads_enabled; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.uploads_enabled IS 'Whether uploads are enabled for this database';


--
-- Name: COLUMN metabase_database.uploads_schema_name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.uploads_schema_name IS 'The schema name for uploads';


--
-- Name: COLUMN metabase_database.uploads_table_prefix; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.uploads_table_prefix IS 'The prefix for upload table names';


--
-- Name: COLUMN metabase_database.is_attached_dwh; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.is_attached_dwh IS 'This is an attached data warehouse, do not serialize it and hide its details from the UI';


--
-- Name: COLUMN metabase_database.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_database.entity_id IS 'Random NanoID tag for unique identity.';


--
-- Name: metabase_database_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.metabase_database ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.metabase_database_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: metabase_field; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metabase_field (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(254) NOT NULL,
    base_type character varying(255) NOT NULL,
    semantic_type character varying(255),
    active boolean DEFAULT true NOT NULL,
    description text,
    preview_display boolean DEFAULT true NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    table_id integer NOT NULL,
    parent_id integer,
    display_name character varying(254),
    visibility_type character varying(32) DEFAULT 'normal'::character varying NOT NULL,
    fk_target_field_id integer,
    last_analyzed timestamp with time zone,
    points_of_interest text,
    caveats text,
    fingerprint text,
    fingerprint_version integer DEFAULT 0 NOT NULL,
    database_type text NOT NULL,
    has_field_values text,
    settings text,
    database_position integer DEFAULT 0 NOT NULL,
    custom_position integer DEFAULT 0 NOT NULL,
    effective_type character varying(255),
    coercion_strategy character varying(255),
    nfc_path character varying(254),
    database_required boolean DEFAULT false NOT NULL,
    json_unfolding boolean DEFAULT false NOT NULL,
    database_is_auto_increment boolean DEFAULT false NOT NULL,
    database_indexed boolean,
    database_partitioned boolean,
    is_defective_duplicate boolean DEFAULT false NOT NULL,
    unique_field_helper integer GENERATED ALWAYS AS (
CASE
    WHEN (is_defective_duplicate = true) THEN NULL::integer
    ELSE
    CASE
        WHEN (parent_id IS NULL) THEN 0
        ELSE parent_id
    END
END) STORED,
    entity_id character(21)
);


ALTER TABLE public.metabase_field OWNER TO metabase;

--
-- Name: COLUMN metabase_field.json_unfolding; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_field.json_unfolding IS 'Enable/disable JSON unfolding for a field';


--
-- Name: COLUMN metabase_field.database_is_auto_increment; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_field.database_is_auto_increment IS 'Indicates this field is auto incremented';


--
-- Name: COLUMN metabase_field.database_indexed; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_field.database_indexed IS 'If the database supports indexing, this column indicate whether or not a field is indexed, or is the 1st column in a composite index';


--
-- Name: COLUMN metabase_field.database_partitioned; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_field.database_partitioned IS 'Whether the table is partitioned by this field';


--
-- Name: COLUMN metabase_field.is_defective_duplicate; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_field.is_defective_duplicate IS 'Indicates whether column is a defective duplicate field that should never have been created.';


--
-- Name: COLUMN metabase_field.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_field.entity_id IS 'Random NanoID tag for unique identity.';


--
-- Name: metabase_field_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.metabase_field ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.metabase_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: metabase_fieldvalues; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metabase_fieldvalues (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    "values" text,
    human_readable_values text,
    field_id integer NOT NULL,
    has_more_values boolean DEFAULT false,
    type character varying(32) DEFAULT 'full'::character varying NOT NULL,
    hash_key text,
    last_used_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.metabase_fieldvalues OWNER TO metabase;

--
-- Name: COLUMN metabase_fieldvalues.last_used_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_fieldvalues.last_used_at IS 'Timestamp of when these FieldValues were last used.';


--
-- Name: metabase_fieldvalues_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.metabase_fieldvalues ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.metabase_fieldvalues_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: metabase_table; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metabase_table (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(256) NOT NULL,
    description text,
    entity_type character varying(254),
    active boolean NOT NULL,
    db_id integer NOT NULL,
    display_name character varying(256),
    visibility_type character varying(254),
    schema character varying(254),
    points_of_interest text,
    caveats text,
    show_in_getting_started boolean DEFAULT false NOT NULL,
    field_order character varying(254) DEFAULT 'database'::character varying NOT NULL,
    initial_sync_status character varying(32) DEFAULT 'complete'::character varying NOT NULL,
    is_upload boolean DEFAULT false NOT NULL,
    database_require_filter boolean,
    estimated_row_count bigint,
    view_count integer DEFAULT 0 NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.metabase_table OWNER TO metabase;

--
-- Name: COLUMN metabase_table.is_upload; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_table.is_upload IS 'Was the table created from user-uploaded (i.e., from a CSV) data?';


--
-- Name: COLUMN metabase_table.database_require_filter; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_table.database_require_filter IS 'If true, the table requires a filter to be able to query it';


--
-- Name: COLUMN metabase_table.estimated_row_count; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_table.estimated_row_count IS 'The estimated row count';


--
-- Name: COLUMN metabase_table.view_count; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_table.view_count IS 'Keeps a running count of card views';


--
-- Name: COLUMN metabase_table.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.metabase_table.entity_id IS 'Random NanoID tag for unique identity.';


--
-- Name: metabase_table_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.metabase_table ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.metabase_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: metric; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metric (
    id integer NOT NULL,
    table_id integer NOT NULL,
    creator_id integer NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    archived boolean DEFAULT false NOT NULL,
    definition text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    points_of_interest text,
    caveats text,
    how_is_this_calculated text,
    show_in_getting_started boolean DEFAULT false NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.metric OWNER TO metabase;

--
-- Name: metric_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.metric ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.metric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: metric_important_field; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.metric_important_field (
    id integer NOT NULL,
    metric_id integer NOT NULL,
    field_id integer NOT NULL
);


ALTER TABLE public.metric_important_field OWNER TO metabase;

--
-- Name: metric_important_field_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.metric_important_field ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.metric_important_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: model_index; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.model_index (
    id integer NOT NULL,
    model_id integer,
    pk_ref text NOT NULL,
    value_ref text NOT NULL,
    schedule text NOT NULL,
    state text NOT NULL,
    indexed_at timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    creator_id integer NOT NULL
);


ALTER TABLE public.model_index OWNER TO metabase;

--
-- Name: TABLE model_index; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.model_index IS 'Used to keep track of which models have indexed columns.';


--
-- Name: COLUMN model_index.model_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.model_id IS 'The ID of the indexed model.';


--
-- Name: COLUMN model_index.pk_ref; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.pk_ref IS 'Serialized JSON of the primary key field ref.';


--
-- Name: COLUMN model_index.value_ref; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.value_ref IS 'Serialized JSON of the label field ref.';


--
-- Name: COLUMN model_index.schedule; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.schedule IS 'The cron schedule for when value syncing should happen.';


--
-- Name: COLUMN model_index.state; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.state IS 'The status of the index: initializing, indexed, error, overflow.';


--
-- Name: COLUMN model_index.indexed_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.indexed_at IS 'When the status changed';


--
-- Name: COLUMN model_index.error; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.error IS 'The error message if the status is error.';


--
-- Name: COLUMN model_index.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.created_at IS 'The timestamp of when these changes were made.';


--
-- Name: COLUMN model_index.creator_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index.creator_id IS 'ID of the user who created the event';


--
-- Name: model_index_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.model_index ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.model_index_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: model_index_value; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.model_index_value (
    model_index_id integer,
    model_pk integer NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.model_index_value OWNER TO metabase;

--
-- Name: TABLE model_index_value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.model_index_value IS 'Used to keep track of the values indexed in a model';


--
-- Name: COLUMN model_index_value.model_index_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index_value.model_index_id IS 'The ID of the indexed model.';


--
-- Name: COLUMN model_index_value.model_pk; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index_value.model_pk IS 'The primary key of the indexed value';


--
-- Name: COLUMN model_index_value.name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.model_index_value.name IS 'The label to display identifying the indexed value.';


--
-- Name: moderation_review; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.moderation_review (
    id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    status character varying(255),
    text text,
    moderated_item_id integer NOT NULL,
    moderated_item_type character varying(255) NOT NULL,
    moderator_id integer NOT NULL,
    most_recent boolean NOT NULL
);


ALTER TABLE public.moderation_review OWNER TO metabase;

--
-- Name: moderation_review_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.moderation_review ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.moderation_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: native_query_snippet; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.native_query_snippet (
    id integer NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    content text NOT NULL,
    creator_id integer NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    collection_id integer,
    entity_id character(21)
);


ALTER TABLE public.native_query_snippet OWNER TO metabase;

--
-- Name: native_query_snippet_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.native_query_snippet ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.native_query_snippet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.notification (
    id integer NOT NULL,
    payload_type character varying(64) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    internal_id character varying(254),
    payload_id integer,
    creator_id integer
);


ALTER TABLE public.notification OWNER TO metabase;

--
-- Name: TABLE notification; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.notification IS 'join table that connect notification subscriptions and notification handlers';


--
-- Name: COLUMN notification.payload_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.payload_type IS 'the type of the payload';


--
-- Name: COLUMN notification.active; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.active IS 'whether the notification is active';


--
-- Name: COLUMN notification.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.created_at IS 'The timestamp of when the notification was created';


--
-- Name: COLUMN notification.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.updated_at IS 'The timestamp of when the notification was updated';


--
-- Name: COLUMN notification.internal_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.internal_id IS 'the internal id of the notification';


--
-- Name: COLUMN notification.payload_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.payload_id IS 'the internal id of the notification';


--
-- Name: COLUMN notification.creator_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification.creator_id IS 'the id of the creator';


--
-- Name: notification_card; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.notification_card (
    id integer NOT NULL,
    card_id integer,
    send_once boolean DEFAULT false NOT NULL,
    send_condition character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_card OWNER TO metabase;

--
-- Name: TABLE notification_card; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.notification_card IS 'Card related notifications';


--
-- Name: COLUMN notification_card.card_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_card.card_id IS 'the card that the alert is connected to';


--
-- Name: COLUMN notification_card.send_once; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_card.send_once IS 'whether the alert should only run once';


--
-- Name: COLUMN notification_card.send_condition; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_card.send_condition IS 'the condition of the alert';


--
-- Name: COLUMN notification_card.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_card.created_at IS 'The timestamp of when the recipient was created';


--
-- Name: COLUMN notification_card.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_card.updated_at IS 'The timestamp of when the recipient was updated';


--
-- Name: notification_card_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.notification_card ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notification_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification_handler; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.notification_handler (
    id integer NOT NULL,
    channel_type character varying(64) NOT NULL,
    notification_id integer NOT NULL,
    channel_id integer,
    template_id integer,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_handler OWNER TO metabase;

--
-- Name: TABLE notification_handler; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.notification_handler IS 'which channel to send the notification to';


--
-- Name: COLUMN notification_handler.channel_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.channel_type IS 'the type of the channel, like :channel/email, :channel/slack';


--
-- Name: COLUMN notification_handler.notification_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.notification_id IS 'the notification that the handler is connected to';


--
-- Name: COLUMN notification_handler.channel_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.channel_id IS 'the channel that the handler is connected to';


--
-- Name: COLUMN notification_handler.template_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.template_id IS 'the template that the handler is connected to';


--
-- Name: COLUMN notification_handler.active; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.active IS 'whether the handler is active';


--
-- Name: COLUMN notification_handler.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.created_at IS 'The timestamp of when the handler was created';


--
-- Name: COLUMN notification_handler.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_handler.updated_at IS 'The timestamp of when the handler was updated';


--
-- Name: notification_handler_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.notification_handler ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notification_handler_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.notification ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notification_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification_recipient; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.notification_recipient (
    id integer NOT NULL,
    notification_handler_id integer NOT NULL,
    type character varying(64) NOT NULL,
    user_id integer,
    permissions_group_id integer,
    details text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.notification_recipient OWNER TO metabase;

--
-- Name: TABLE notification_recipient; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.notification_recipient IS 'who should receive the notification';


--
-- Name: COLUMN notification_recipient.notification_handler_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.notification_handler_id IS 'the handler that the recipient is connected to';


--
-- Name: COLUMN notification_recipient.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.type IS 'the type of the recipient';


--
-- Name: COLUMN notification_recipient.user_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.user_id IS 'a user if the recipient has type user';


--
-- Name: COLUMN notification_recipient.permissions_group_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.permissions_group_id IS 'a permissions group if the recipient has type permissions_group';


--
-- Name: COLUMN notification_recipient.details; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.details IS 'custom details for the recipient';


--
-- Name: COLUMN notification_recipient.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.created_at IS 'The timestamp of when the recipient was created';


--
-- Name: COLUMN notification_recipient.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_recipient.updated_at IS 'The timestamp of when the recipient was updated';


--
-- Name: notification_recipient_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.notification_recipient ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notification_recipient_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notification_subscription; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.notification_subscription (
    id integer NOT NULL,
    notification_id integer NOT NULL,
    type character varying(64) NOT NULL,
    event_name character varying(64),
    created_at timestamp with time zone NOT NULL,
    cron_schedule character varying(128),
    ui_display_type character varying(32)
);


ALTER TABLE public.notification_subscription OWNER TO metabase;

--
-- Name: TABLE notification_subscription; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.notification_subscription IS 'which type of trigger a notification is subscribed to';


--
-- Name: COLUMN notification_subscription.notification_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_subscription.notification_id IS 'the notification that the subscription is connected to';


--
-- Name: COLUMN notification_subscription.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_subscription.type IS 'the type of the subscription';


--
-- Name: COLUMN notification_subscription.event_name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_subscription.event_name IS 'the event name of subscriptions with type :notification-subscription/system-event';


--
-- Name: COLUMN notification_subscription.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_subscription.created_at IS 'The timestamp of when the subscription was created';


--
-- Name: COLUMN notification_subscription.cron_schedule; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_subscription.cron_schedule IS 'the cron schedule for the subscription';


--
-- Name: COLUMN notification_subscription.ui_display_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.notification_subscription.ui_display_type IS 'the display of the subscription, used for the UI only';


--
-- Name: notification_subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.notification_subscription ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.notification_subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: parameter_card; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.parameter_card (
    id integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    card_id integer NOT NULL,
    parameterized_object_type character varying(32) NOT NULL,
    parameterized_object_id integer NOT NULL,
    parameter_id character varying(36) NOT NULL
);


ALTER TABLE public.parameter_card OWNER TO metabase;

--
-- Name: TABLE parameter_card; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.parameter_card IS 'Join table connecting cards to entities (dashboards, other cards, etc.) that use the values generated by the card for filter values';


--
-- Name: COLUMN parameter_card.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.parameter_card.updated_at IS 'most recent modification time';


--
-- Name: COLUMN parameter_card.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.parameter_card.created_at IS 'creation time';


--
-- Name: COLUMN parameter_card.card_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.parameter_card.card_id IS 'ID of the card generating the values';


--
-- Name: COLUMN parameter_card.parameterized_object_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.parameter_card.parameterized_object_type IS 'Type of the entity consuming the values (dashboard, card, etc.)';


--
-- Name: COLUMN parameter_card.parameterized_object_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.parameter_card.parameterized_object_id IS 'ID of the entity consuming the values';


--
-- Name: COLUMN parameter_card.parameter_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.parameter_card.parameter_id IS 'The parameter ID';


--
-- Name: parameter_card_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.parameter_card ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.parameter_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.permissions (
    id integer NOT NULL,
    object character varying(254) NOT NULL,
    group_id integer NOT NULL,
    perm_value character varying(64),
    perm_type character varying(64),
    collection_id integer
);


ALTER TABLE public.permissions OWNER TO metabase;

--
-- Name: COLUMN permissions.perm_value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.permissions.perm_value IS 'The value of the permission';


--
-- Name: COLUMN permissions.perm_type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.permissions.perm_type IS 'The type of the permission';


--
-- Name: COLUMN permissions.collection_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.permissions.collection_id IS 'The linked collection, if applicable';


--
-- Name: permissions_group; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.permissions_group (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.permissions_group OWNER TO metabase;

--
-- Name: COLUMN permissions_group.entity_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.permissions_group.entity_id IS 'NanoID tag for each user';


--
-- Name: permissions_group_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.permissions_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.permissions_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permissions_group_membership; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.permissions_group_membership (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL,
    is_group_manager boolean DEFAULT false NOT NULL
);


ALTER TABLE public.permissions_group_membership OWNER TO metabase;

--
-- Name: permissions_group_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.permissions_group_membership ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.permissions_group_membership_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permissions_revision; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.permissions_revision (
    id integer NOT NULL,
    before text NOT NULL,
    after text NOT NULL,
    user_id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    remark text
);


ALTER TABLE public.permissions_revision OWNER TO metabase;

--
-- Name: permissions_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.permissions_revision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.permissions_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: persisted_info; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.persisted_info (
    id integer NOT NULL,
    database_id integer NOT NULL,
    card_id integer,
    question_slug text NOT NULL,
    table_name text NOT NULL,
    definition text,
    query_hash text,
    active boolean DEFAULT false NOT NULL,
    state text NOT NULL,
    refresh_begin timestamp with time zone NOT NULL,
    refresh_end timestamp with time zone,
    state_change_at timestamp with time zone,
    error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    creator_id integer
);


ALTER TABLE public.persisted_info OWNER TO metabase;

--
-- Name: persisted_info_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.persisted_info ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.persisted_info_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pulse; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.pulse (
    id integer NOT NULL,
    creator_id integer NOT NULL,
    name character varying(254),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    skip_if_empty boolean DEFAULT false NOT NULL,
    alert_condition character varying(254),
    alert_first_only boolean,
    alert_above_goal boolean,
    collection_id integer,
    collection_position smallint,
    archived boolean DEFAULT false,
    dashboard_id integer,
    parameters text NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.pulse OWNER TO metabase;

--
-- Name: pulse_card; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.pulse_card (
    id integer NOT NULL,
    pulse_id integer NOT NULL,
    card_id integer NOT NULL,
    "position" integer NOT NULL,
    include_csv boolean DEFAULT false NOT NULL,
    include_xls boolean DEFAULT false NOT NULL,
    dashboard_card_id integer,
    entity_id character(21),
    format_rows boolean DEFAULT true,
    pivot_results boolean DEFAULT false
);


ALTER TABLE public.pulse_card OWNER TO metabase;

--
-- Name: COLUMN pulse_card.format_rows; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.pulse_card.format_rows IS 'Whether or not to apply formatting to the rows of the export';


--
-- Name: COLUMN pulse_card.pivot_results; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.pulse_card.pivot_results IS 'Whether or not to apply pivot processing to the rows of the export';


--
-- Name: pulse_card_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.pulse_card ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pulse_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pulse_channel; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.pulse_channel (
    id integer NOT NULL,
    pulse_id integer NOT NULL,
    channel_type character varying(32) NOT NULL,
    details text NOT NULL,
    schedule_type character varying(32) NOT NULL,
    schedule_hour integer,
    schedule_day character varying(64),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    schedule_frame character varying(32),
    enabled boolean DEFAULT true NOT NULL,
    entity_id character(21),
    channel_id integer
);


ALTER TABLE public.pulse_channel OWNER TO metabase;

--
-- Name: COLUMN pulse_channel.channel_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.pulse_channel.channel_id IS 'The channel ID';


--
-- Name: pulse_channel_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.pulse_channel ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pulse_channel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pulse_channel_recipient; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.pulse_channel_recipient (
    id integer NOT NULL,
    pulse_channel_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.pulse_channel_recipient OWNER TO metabase;

--
-- Name: pulse_channel_recipient_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.pulse_channel_recipient ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pulse_channel_recipient_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: pulse_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.pulse ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.pulse_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: qrtz_blob_triggers; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_blob_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    blob_data bytea
);


ALTER TABLE public.qrtz_blob_triggers OWNER TO metabase;

--
-- Name: qrtz_calendars; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_calendars (
    sched_name character varying(120) NOT NULL,
    calendar_name character varying(200) NOT NULL,
    calendar bytea NOT NULL
);


ALTER TABLE public.qrtz_calendars OWNER TO metabase;

--
-- Name: qrtz_cron_triggers; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_cron_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    cron_expression character varying(120) NOT NULL,
    time_zone_id character varying(80)
);


ALTER TABLE public.qrtz_cron_triggers OWNER TO metabase;

--
-- Name: qrtz_fired_triggers; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_fired_triggers (
    sched_name character varying(120) NOT NULL,
    entry_id character varying(95) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    instance_name character varying(200) NOT NULL,
    fired_time bigint NOT NULL,
    sched_time bigint,
    priority integer NOT NULL,
    state character varying(16) NOT NULL,
    job_name character varying(200),
    job_group character varying(200),
    is_nonconcurrent boolean,
    requests_recovery boolean
);


ALTER TABLE public.qrtz_fired_triggers OWNER TO metabase;

--
-- Name: qrtz_job_details; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_job_details (
    sched_name character varying(120) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    job_class_name character varying(250) NOT NULL,
    is_durable boolean NOT NULL,
    is_nonconcurrent boolean NOT NULL,
    is_update_data boolean NOT NULL,
    requests_recovery boolean NOT NULL,
    job_data bytea
);


ALTER TABLE public.qrtz_job_details OWNER TO metabase;

--
-- Name: qrtz_locks; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_locks (
    sched_name character varying(120) NOT NULL,
    lock_name character varying(40) NOT NULL
);


ALTER TABLE public.qrtz_locks OWNER TO metabase;

--
-- Name: qrtz_paused_trigger_grps; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_paused_trigger_grps (
    sched_name character varying(120) NOT NULL,
    trigger_group character varying(200) NOT NULL
);


ALTER TABLE public.qrtz_paused_trigger_grps OWNER TO metabase;

--
-- Name: qrtz_scheduler_state; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_scheduler_state (
    sched_name character varying(120) NOT NULL,
    instance_name character varying(200) NOT NULL,
    last_checkin_time bigint NOT NULL,
    checkin_interval bigint NOT NULL
);


ALTER TABLE public.qrtz_scheduler_state OWNER TO metabase;

--
-- Name: qrtz_simple_triggers; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_simple_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    repeat_count bigint NOT NULL,
    repeat_interval bigint NOT NULL,
    times_triggered bigint NOT NULL
);


ALTER TABLE public.qrtz_simple_triggers OWNER TO metabase;

--
-- Name: qrtz_simprop_triggers; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_simprop_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    str_prop_1 character varying(512),
    str_prop_2 character varying(512),
    str_prop_3 character varying(512),
    int_prop_1 integer,
    int_prop_2 integer,
    long_prop_1 bigint,
    long_prop_2 bigint,
    dec_prop_1 numeric(13,4),
    dec_prop_2 numeric(13,4),
    bool_prop_1 boolean,
    bool_prop_2 boolean
);


ALTER TABLE public.qrtz_simprop_triggers OWNER TO metabase;

--
-- Name: qrtz_triggers; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.qrtz_triggers (
    sched_name character varying(120) NOT NULL,
    trigger_name character varying(200) NOT NULL,
    trigger_group character varying(200) NOT NULL,
    job_name character varying(200) NOT NULL,
    job_group character varying(200) NOT NULL,
    description character varying(250),
    next_fire_time bigint,
    prev_fire_time bigint,
    priority integer,
    trigger_state character varying(16) NOT NULL,
    trigger_type character varying(8) NOT NULL,
    start_time bigint NOT NULL,
    end_time bigint,
    calendar_name character varying(200),
    misfire_instr smallint,
    job_data bytea
);


ALTER TABLE public.qrtz_triggers OWNER TO metabase;

--
-- Name: query; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query (
    query_hash bytea NOT NULL,
    average_execution_time integer NOT NULL,
    query text
);


ALTER TABLE public.query OWNER TO metabase;

--
-- Name: query_action; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query_action (
    action_id integer NOT NULL,
    database_id integer NOT NULL,
    dataset_query text NOT NULL
);


ALTER TABLE public.query_action OWNER TO metabase;

--
-- Name: TABLE query_action; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.query_action IS 'A readwrite query type of action';


--
-- Name: COLUMN query_action.action_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_action.action_id IS 'The related action';


--
-- Name: COLUMN query_action.database_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_action.database_id IS 'The associated database';


--
-- Name: COLUMN query_action.dataset_query; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_action.dataset_query IS 'The MBQL writeback query';


--
-- Name: query_analysis; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query_analysis (
    id integer NOT NULL,
    card_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    status text
);


ALTER TABLE public.query_analysis OWNER TO metabase;

--
-- Name: TABLE query_analysis; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.query_analysis IS 'Parent node for query analysis records';


--
-- Name: COLUMN query_analysis.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_analysis.id IS 'PK';


--
-- Name: COLUMN query_analysis.card_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_analysis.card_id IS 'referenced card';


--
-- Name: COLUMN query_analysis.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_analysis.created_at IS 'The timestamp of when the analysis was created';


--
-- Name: COLUMN query_analysis.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_analysis.updated_at IS 'The timestamp of when the analysis was updated';


--
-- Name: COLUMN query_analysis.status; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_analysis.status IS 'running, failed, or completed';


--
-- Name: query_analysis_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.query_analysis ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.query_analysis_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: query_cache; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query_cache (
    query_hash bytea NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    results bytea NOT NULL
);


ALTER TABLE public.query_cache OWNER TO metabase;

--
-- Name: query_execution; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query_execution (
    id integer NOT NULL,
    hash bytea NOT NULL,
    started_at timestamp with time zone NOT NULL,
    running_time integer NOT NULL,
    result_rows integer NOT NULL,
    native boolean NOT NULL,
    context character varying(32),
    error text,
    executor_id integer,
    card_id integer,
    dashboard_id integer,
    pulse_id integer,
    database_id integer,
    cache_hit boolean,
    action_id integer,
    is_sandboxed boolean,
    cache_hash bytea,
    embedding_client character varying(254),
    embedding_version character varying(254),
    parameterized boolean
);


ALTER TABLE public.query_execution OWNER TO metabase;

--
-- Name: COLUMN query_execution.action_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_execution.action_id IS 'The ID of the action associated with this query execution, if any.';


--
-- Name: COLUMN query_execution.is_sandboxed; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_execution.is_sandboxed IS 'Is query from a sandboxed user';


--
-- Name: COLUMN query_execution.cache_hash; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_execution.cache_hash IS 'Hash of normalized query, calculated in middleware.cache';


--
-- Name: COLUMN query_execution.embedding_client; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_execution.embedding_client IS 'Used by the embedding team to track SDK usage';


--
-- Name: COLUMN query_execution.embedding_version; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_execution.embedding_version IS 'Used by the embedding team to track SDK version usage';


--
-- Name: COLUMN query_execution.parameterized; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_execution.parameterized IS 'Whether or not the query has parameters with non-nil values';


--
-- Name: query_execution_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.query_execution ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.query_execution_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: query_field; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query_field (
    id integer NOT NULL,
    card_id integer NOT NULL,
    field_id integer,
    explicit_reference boolean DEFAULT true NOT NULL,
    "column" character varying(254) NOT NULL,
    "table" character varying(254),
    table_id integer,
    analysis_id integer NOT NULL,
    schema character varying(254)
);


ALTER TABLE public.query_field OWNER TO metabase;

--
-- Name: TABLE query_field; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.query_field IS 'Fields used by a card''s query';


--
-- Name: COLUMN query_field.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.id IS 'PK';


--
-- Name: COLUMN query_field.card_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.card_id IS 'referenced card';


--
-- Name: COLUMN query_field.field_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.field_id IS 'referenced field';


--
-- Name: COLUMN query_field.explicit_reference; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.explicit_reference IS 'Is the Field referenced directly or via a wildcard';


--
-- Name: COLUMN query_field."column"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field."column" IS 'name of the table or card being referenced';


--
-- Name: COLUMN query_field."table"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field."table" IS 'name of the table or card being referenced';


--
-- Name: COLUMN query_field.table_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.table_id IS 'track the table directly, in case the field does not exist';


--
-- Name: COLUMN query_field.analysis_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.analysis_id IS 'round of analysis';


--
-- Name: COLUMN query_field.schema; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_field.schema IS 'name of the schema of the table being referenced';


--
-- Name: query_field_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.query_field ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.query_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: query_table; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.query_table (
    id integer NOT NULL,
    card_id integer NOT NULL,
    analysis_id integer NOT NULL,
    table_id integer,
    schema character varying(254),
    "table" character varying(254) NOT NULL
);


ALTER TABLE public.query_table OWNER TO metabase;

--
-- Name: TABLE query_table; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.query_table IS 'Tables used by a card''s query';


--
-- Name: COLUMN query_table.id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_table.id IS 'PK';


--
-- Name: COLUMN query_table.card_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_table.card_id IS 'referenced card';


--
-- Name: COLUMN query_table.analysis_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_table.analysis_id IS 'round of analysis';


--
-- Name: COLUMN query_table.table_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_table.table_id IS 'referenced field';


--
-- Name: COLUMN query_table.schema; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_table.schema IS 'name of the schema of the table being referenced';


--
-- Name: COLUMN query_table."table"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.query_table."table" IS 'name of the table or card being referenced';


--
-- Name: query_table_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.query_table ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.query_table_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: recent_views; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.recent_views (
    id integer NOT NULL,
    user_id integer NOT NULL,
    model character varying(16) NOT NULL,
    model_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    context character varying(256) DEFAULT 'view'::character varying NOT NULL
);


ALTER TABLE public.recent_views OWNER TO metabase;

--
-- Name: TABLE recent_views; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.recent_views IS 'Used to store recently viewed objects for each user';


--
-- Name: COLUMN recent_views.user_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.recent_views.user_id IS 'The user associated with this view';


--
-- Name: COLUMN recent_views.model; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.recent_views.model IS 'The name of the model that was viewed';


--
-- Name: COLUMN recent_views.model_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.recent_views.model_id IS 'The ID of the model that was viewed';


--
-- Name: COLUMN recent_views."timestamp"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.recent_views."timestamp" IS 'The time a view was recorded';


--
-- Name: COLUMN recent_views.context; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.recent_views.context IS 'The contextual action that netted a recent view.';


--
-- Name: recent_views_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.recent_views ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.recent_views_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: report_card; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.report_card (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    display character varying(254) NOT NULL,
    dataset_query text NOT NULL,
    visualization_settings text NOT NULL,
    creator_id integer NOT NULL,
    database_id integer NOT NULL,
    table_id integer,
    query_type character varying(16),
    archived boolean DEFAULT false NOT NULL,
    collection_id integer,
    public_uuid character(36),
    made_public_by_id integer,
    enable_embedding boolean DEFAULT false NOT NULL,
    embedding_params text,
    cache_ttl integer,
    result_metadata text,
    collection_position smallint,
    entity_id character(21),
    parameters text,
    parameter_mappings text,
    collection_preview boolean DEFAULT true NOT NULL,
    metabase_version character varying(100),
    type character varying(16) DEFAULT 'question'::character varying NOT NULL,
    initially_published_at timestamp with time zone,
    cache_invalidated_at timestamp with time zone,
    last_used_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    view_count integer DEFAULT 0 NOT NULL,
    archived_directly boolean DEFAULT false NOT NULL,
    dataset_query_metrics_v2_migration_backup text,
    source_card_id integer,
    dashboard_id integer
);


ALTER TABLE public.report_card OWNER TO metabase;

--
-- Name: COLUMN report_card.metabase_version; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.metabase_version IS 'Metabase version used to create the card.';


--
-- Name: COLUMN report_card.type; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.type IS 'The type of card, could be ''question'', ''model'', ''metric''';


--
-- Name: COLUMN report_card.initially_published_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.initially_published_at IS 'The timestamp when the card was first published in a static embed';


--
-- Name: COLUMN report_card.cache_invalidated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.cache_invalidated_at IS 'An invalidation time that can supersede cache_config.invalidated_at';


--
-- Name: COLUMN report_card.last_used_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.last_used_at IS 'The timestamp of when the card is last used';


--
-- Name: COLUMN report_card.view_count; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.view_count IS 'Keeps a running count of card views';


--
-- Name: COLUMN report_card.archived_directly; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.archived_directly IS 'Was this thing trashed directly';


--
-- Name: COLUMN report_card.dataset_query_metrics_v2_migration_backup; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.dataset_query_metrics_v2_migration_backup IS 'The copy of dataset_query before the metrics v2 migration';


--
-- Name: COLUMN report_card.source_card_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.source_card_id IS 'The ID of the model or question this card is based on';


--
-- Name: COLUMN report_card.dashboard_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_card.dashboard_id IS 'The dashboard that owns the card, if it is a dashboard-internal card.';


--
-- Name: report_card_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.report_card ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.report_card_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: report_cardfavorite; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.report_cardfavorite (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    card_id integer NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.report_cardfavorite OWNER TO metabase;

--
-- Name: report_cardfavorite_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.report_cardfavorite ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.report_cardfavorite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: report_dashboard; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.report_dashboard (
    id integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    creator_id integer NOT NULL,
    parameters text NOT NULL,
    points_of_interest text,
    caveats text,
    show_in_getting_started boolean DEFAULT false NOT NULL,
    public_uuid character(36),
    made_public_by_id integer,
    enable_embedding boolean DEFAULT false NOT NULL,
    embedding_params text,
    archived boolean DEFAULT false NOT NULL,
    "position" integer,
    collection_id integer,
    collection_position smallint,
    cache_ttl integer,
    entity_id character(21),
    auto_apply_filters boolean DEFAULT true NOT NULL,
    width character varying(16) DEFAULT 'fixed'::character varying NOT NULL,
    initially_published_at timestamp with time zone,
    view_count integer DEFAULT 0 NOT NULL,
    archived_directly boolean DEFAULT false NOT NULL,
    last_viewed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.report_dashboard OWNER TO metabase;

--
-- Name: COLUMN report_dashboard.auto_apply_filters; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboard.auto_apply_filters IS 'Whether or not to auto-apply filters on a dashboard';


--
-- Name: COLUMN report_dashboard.width; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboard.width IS 'The value of the dashboard''s width setting can be fixed or full. New dashboards will be set to fixed';


--
-- Name: COLUMN report_dashboard.initially_published_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboard.initially_published_at IS 'The timestamp when the dashboard was first published in a static embed';


--
-- Name: COLUMN report_dashboard.view_count; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboard.view_count IS 'Keeps a running count of dashboard views';


--
-- Name: COLUMN report_dashboard.archived_directly; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboard.archived_directly IS 'Was this thing trashed directly';


--
-- Name: COLUMN report_dashboard.last_viewed_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboard.last_viewed_at IS 'Timestamp of when this dashboard was last viewed';


--
-- Name: report_dashboard_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.report_dashboard ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.report_dashboard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: report_dashboardcard; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.report_dashboardcard (
    id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    size_x integer NOT NULL,
    size_y integer NOT NULL,
    "row" integer NOT NULL,
    col integer NOT NULL,
    card_id integer,
    dashboard_id integer NOT NULL,
    parameter_mappings text NOT NULL,
    visualization_settings text NOT NULL,
    entity_id character(21),
    action_id integer,
    dashboard_tab_id integer
);


ALTER TABLE public.report_dashboardcard OWNER TO metabase;

--
-- Name: COLUMN report_dashboardcard.action_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboardcard.action_id IS 'The related action';


--
-- Name: COLUMN report_dashboardcard.dashboard_tab_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.report_dashboardcard.dashboard_tab_id IS 'The referenced tab id that dashcard is on, it''s nullable for dashboard with no tab';


--
-- Name: report_dashboardcard_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.report_dashboardcard ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.report_dashboardcard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: revision; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.revision (
    id integer NOT NULL,
    model character varying(16) NOT NULL,
    model_id integer NOT NULL,
    user_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    object text NOT NULL,
    is_reversion boolean DEFAULT false NOT NULL,
    is_creation boolean DEFAULT false NOT NULL,
    message text,
    most_recent boolean DEFAULT false NOT NULL,
    metabase_version character varying(100)
);


ALTER TABLE public.revision OWNER TO metabase;

--
-- Name: COLUMN revision.most_recent; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.revision.most_recent IS 'Whether a revision is the most recent one';


--
-- Name: COLUMN revision.metabase_version; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.revision.metabase_version IS 'Metabase version used to create the revision.';


--
-- Name: revision_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.revision ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: search_index_metadata; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.search_index_metadata (
    id integer NOT NULL,
    engine character varying(64) NOT NULL,
    version character varying(254) NOT NULL,
    index_name character varying(254) NOT NULL,
    status character varying(32),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.search_index_metadata OWNER TO metabase;

--
-- Name: TABLE search_index_metadata; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.search_index_metadata IS 'Each entry corresponds to some queryable index, and contains metadata about it.';


--
-- Name: COLUMN search_index_metadata.engine; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.search_index_metadata.engine IS 'The kind of search engine which this index belongs to.';


--
-- Name: COLUMN search_index_metadata.version; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.search_index_metadata.version IS 'Used to determine metabase compatibility. Format may depend on engine in future.';


--
-- Name: COLUMN search_index_metadata.index_name; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.search_index_metadata.index_name IS 'The name by which the given engine refers to this particular index, e.g. table name.';


--
-- Name: COLUMN search_index_metadata.status; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.search_index_metadata.status IS 'One of ''pending'', ''active'', or ''retired''';


--
-- Name: COLUMN search_index_metadata.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.search_index_metadata.created_at IS 'The timestamp of when the index was created';


--
-- Name: COLUMN search_index_metadata.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.search_index_metadata.updated_at IS 'The timestamp of when the index status was updated';


--
-- Name: search_index_metadata_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.search_index_metadata ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.search_index_metadata_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: secret; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.secret (
    id integer NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    creator_id integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    name character varying(254) NOT NULL,
    kind character varying(254) NOT NULL,
    source character varying(254),
    value bytea NOT NULL
);


ALTER TABLE public.secret OWNER TO metabase;

--
-- Name: secret_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.secret ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.secret_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: segment; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.segment (
    id integer NOT NULL,
    table_id integer NOT NULL,
    creator_id integer NOT NULL,
    name character varying(254) NOT NULL,
    description text,
    archived boolean DEFAULT false NOT NULL,
    definition text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    points_of_interest text,
    caveats text,
    show_in_getting_started boolean DEFAULT false NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.segment OWNER TO metabase;

--
-- Name: segment_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.segment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.segment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: setting; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.setting (
    key character varying(254) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.setting OWNER TO metabase;

--
-- Name: table_privileges; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.table_privileges (
    table_id integer NOT NULL,
    role character varying(255),
    "select" boolean DEFAULT false NOT NULL,
    update boolean DEFAULT false NOT NULL,
    insert boolean DEFAULT false NOT NULL,
    delete boolean DEFAULT false NOT NULL
);


ALTER TABLE public.table_privileges OWNER TO metabase;

--
-- Name: TABLE table_privileges; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.table_privileges IS 'Table for user and role privileges by table';


--
-- Name: COLUMN table_privileges.table_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.table_privileges.table_id IS 'Table ID';


--
-- Name: COLUMN table_privileges.role; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.table_privileges.role IS 'Role name. NULL indicates the privileges are the current user''s';


--
-- Name: COLUMN table_privileges."select"; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.table_privileges."select" IS 'Privilege to select from the table';


--
-- Name: COLUMN table_privileges.update; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.table_privileges.update IS 'Privilege to update records in the table';


--
-- Name: COLUMN table_privileges.insert; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.table_privileges.insert IS 'Privilege to insert records into the table';


--
-- Name: COLUMN table_privileges.delete; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.table_privileges.delete IS 'Privilege to delete records from the table';


--
-- Name: task_history; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.task_history (
    id integer NOT NULL,
    task character varying(254) NOT NULL,
    db_id integer,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    ended_at timestamp with time zone,
    duration integer,
    task_details text,
    status character varying(21) DEFAULT 'started'::character varying NOT NULL
);


ALTER TABLE public.task_history OWNER TO metabase;

--
-- Name: COLUMN task_history.status; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.task_history.status IS 'the status of task history, could be started, failed, success, unknown';


--
-- Name: task_history_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.task_history ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.task_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: timeline; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.timeline (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    icon character varying(128) NOT NULL,
    collection_id integer,
    archived boolean DEFAULT false NOT NULL,
    creator_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    "default" boolean DEFAULT false NOT NULL,
    entity_id character(21)
);


ALTER TABLE public.timeline OWNER TO metabase;

--
-- Name: timeline_event; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.timeline_event (
    id integer NOT NULL,
    timeline_id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(255),
    "timestamp" timestamp with time zone NOT NULL,
    time_matters boolean NOT NULL,
    timezone character varying(255) NOT NULL,
    icon character varying(128) NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    creator_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.timeline_event OWNER TO metabase;

--
-- Name: timeline_event_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.timeline_event ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.timeline_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: timeline_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.timeline ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.timeline_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_key_value; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.user_key_value (
    id integer NOT NULL,
    user_id integer NOT NULL,
    namespace character varying(254) NOT NULL,
    key character varying(254) NOT NULL,
    value text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone
);


ALTER TABLE public.user_key_value OWNER TO metabase;

--
-- Name: TABLE user_key_value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.user_key_value IS 'A simple key value store for each user.';


--
-- Name: COLUMN user_key_value.user_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.user_id IS 'The ID of the user this KV-pair is for';


--
-- Name: COLUMN user_key_value.namespace; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.namespace IS 'The namespace for this KV, e.g. "dashboard-filters" or "nobody-knows"';


--
-- Name: COLUMN user_key_value.key; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.key IS 'The key';


--
-- Name: COLUMN user_key_value.value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.value IS 'The value, serialized JSON';


--
-- Name: COLUMN user_key_value.created_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.created_at IS 'When this row was created';


--
-- Name: COLUMN user_key_value.updated_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.updated_at IS 'When this row was last updated';


--
-- Name: COLUMN user_key_value.expires_at; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_key_value.expires_at IS 'If set, when this row expires';


--
-- Name: user_key_value_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.user_key_value ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.user_key_value_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_parameter_value; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.user_parameter_value (
    id integer NOT NULL,
    user_id integer NOT NULL,
    parameter_id character varying(36) NOT NULL,
    value text,
    dashboard_id integer
);


ALTER TABLE public.user_parameter_value OWNER TO metabase;

--
-- Name: TABLE user_parameter_value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON TABLE public.user_parameter_value IS 'Table holding last set value of a parameter per user';


--
-- Name: COLUMN user_parameter_value.user_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_parameter_value.user_id IS 'ID of the User who has set the parameter value';


--
-- Name: COLUMN user_parameter_value.parameter_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_parameter_value.parameter_id IS 'The parameter ID';


--
-- Name: COLUMN user_parameter_value.value; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_parameter_value.value IS 'Value of the parameter';


--
-- Name: COLUMN user_parameter_value.dashboard_id; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.user_parameter_value.dashboard_id IS 'The ID of the dashboard';


--
-- Name: user_parameter_value_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.user_parameter_value ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.user_parameter_value_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: v_alerts; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_alerts AS
 WITH parsed_cron AS (
         SELECT n_1.id,
            ns.cron_schedule,
            split_part((ns.cron_schedule)::text, ' '::text, 3) AS hours,
            split_part((ns.cron_schedule)::text, ' '::text, 4) AS day_of_month,
            split_part((ns.cron_schedule)::text, ' '::text, 6) AS day_of_week
           FROM (public.notification n_1
             JOIN public.notification_subscription ns ON ((n_1.id = ns.notification_id)))
          WHERE (((n_1.payload_type)::text = 'notification/card'::text) AND ((ns.type)::text = 'notification-subscription/cron'::text))
        ), schedule_info AS (
         SELECT parsed_cron.id,
                CASE
                    WHEN ((parsed_cron.day_of_month <> '*'::text) AND ((parsed_cron.day_of_week = '?'::text) OR (parsed_cron.day_of_week ~ '^\d#1$'::text) OR (parsed_cron.day_of_week ~ '^\dL$'::text))) THEN 'monthly'::text
                    WHEN ((parsed_cron.day_of_week <> '?'::text) AND (parsed_cron.day_of_week <> '*'::text)) THEN 'weekly'::text
                    WHEN (parsed_cron.hours <> '*'::text) THEN 'daily'::text
                    ELSE 'hourly'::text
                END AS schedule_type,
                CASE
                    WHEN (parsed_cron.day_of_week ~ '^1'::text) THEN 'sun'::text
                    WHEN (parsed_cron.day_of_week ~ '^2'::text) THEN 'mon'::text
                    WHEN (parsed_cron.day_of_week ~ '^3'::text) THEN 'tue'::text
                    WHEN (parsed_cron.day_of_week ~ '^4'::text) THEN 'wed'::text
                    WHEN (parsed_cron.day_of_week ~ '^5'::text) THEN 'thu'::text
                    WHEN (parsed_cron.day_of_week ~ '^6'::text) THEN 'fri'::text
                    WHEN (parsed_cron.day_of_week ~ '^7'::text) THEN 'sat'::text
                    ELSE NULL::text
                END AS schedule_day,
                CASE
                    WHEN (parsed_cron.hours = '*'::text) THEN NULL::integer
                    ELSE (parsed_cron.hours)::integer
                END AS schedule_hour
           FROM parsed_cron
        ), agg_recipients AS (
         SELECT nr.notification_handler_id,
            string_agg((cu.email)::text, ','::text) AS recipients,
            string_agg(
                CASE
                    WHEN ((nr.type)::text = 'notification-recipient/raw-value'::text) THEN nr.details
                    ELSE NULL::text
                END, ','::text) FILTER (WHERE ((nr.type)::text = 'notification-recipient/raw-value'::text)) AS recipient_external
           FROM (public.notification_recipient nr
             LEFT JOIN public.core_user cu ON (((nr.user_id = cu.id) AND ((nr.type)::text = 'notification-recipient/user'::text))))
          GROUP BY nr.notification_handler_id
        )
 SELECT n.id AS entity_id,
    ('notification_'::text || n.id) AS entity_qualified_id,
    n.created_at,
    n.updated_at,
    n.creator_id,
    nc.card_id,
    ('card_'::text || nc.card_id) AS card_qualified_id,
        CASE
            WHEN ((nc.send_condition)::text = 'has_result'::text) THEN 'rows'::text
            WHEN ((nc.send_condition)::text = ANY (ARRAY[('goal_above'::character varying)::text, ('goal_below'::character varying)::text])) THEN 'goal'::text
            ELSE NULL::text
        END AS alert_condition,
    si.schedule_type,
    si.schedule_day,
    si.schedule_hour,
    (NOT n.active) AS archived,
    nh.channel_type AS recipient_type,
    ar.recipients,
    ar.recipient_external
   FROM ((((public.notification n
     JOIN public.notification_card nc ON ((n.payload_id = nc.id)))
     JOIN schedule_info si ON ((n.id = si.id)))
     LEFT JOIN public.notification_handler nh ON ((n.id = nh.notification_id)))
     LEFT JOIN agg_recipients ar ON ((nh.id = ar.notification_handler_id)))
  WHERE ((n.payload_type)::text = 'notification/card'::text);


ALTER VIEW public.v_alerts OWNER TO metabase;

--
-- Name: v_audit_log; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_audit_log AS
 SELECT id,
        CASE
            WHEN ((topic)::text = 'card-create'::text) THEN 'card-create'::character varying
            WHEN ((topic)::text = 'card-delete'::text) THEN 'card-delete'::character varying
            WHEN ((topic)::text = 'card-update'::text) THEN 'card-update'::character varying
            WHEN ((topic)::text = 'pulse-create'::text) THEN 'subscription-create'::character varying
            WHEN ((topic)::text = 'pulse-delete'::text) THEN 'subscription-delete'::character varying
            ELSE topic
        END AS topic,
    "timestamp",
    NULL::text AS end_timestamp,
    COALESCE(user_id, 0) AS user_id,
    lower((model)::text) AS entity_type,
    model_id AS entity_id,
        CASE
            WHEN ((model)::text = 'Dataset'::text) THEN ('card_'::text || model_id)
            WHEN (model_id IS NULL) THEN NULL::text
            ELSE ((lower((model)::text) || '_'::text) || model_id)
        END AS entity_qualified_id,
    details
   FROM public.audit_log
  WHERE ((topic)::text <> ALL (ARRAY[('card-read'::character varying)::text, ('card-query'::character varying)::text, ('dashboard-read'::character varying)::text, ('dashboard-query'::character varying)::text, ('table-read'::character varying)::text]));


ALTER VIEW public.v_audit_log OWNER TO metabase;

--
-- Name: v_content; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_content AS
 SELECT action.id AS entity_id,
    ('action_'::text || action.id) AS entity_qualified_id,
    'action'::text AS entity_type,
    action.created_at,
    action.updated_at,
    action.creator_id,
    action.name,
    action.description,
    NULL::integer AS collection_id,
    action.made_public_by_id AS made_public_by_user,
    NULL::boolean AS is_embedding_enabled,
    NULL::boolean AS is_verified,
    action.archived,
    action.type AS action_type,
    action.model_id AS action_model_id,
    NULL::boolean AS collection_is_official,
    NULL::boolean AS collection_is_personal,
    NULL::text AS question_viz_type,
    NULL::text AS question_database_id,
    NULL::boolean AS question_is_native,
    NULL::timestamp without time zone AS event_timestamp
   FROM public.action
UNION
 SELECT collection.id AS entity_id,
    ('collection_'::text || collection.id) AS entity_qualified_id,
    'collection'::text AS entity_type,
    collection.created_at,
    NULL::timestamp with time zone AS updated_at,
    NULL::integer AS creator_id,
    collection.name,
    collection.description,
    NULL::integer AS collection_id,
    NULL::integer AS made_public_by_user,
    NULL::boolean AS is_embedding_enabled,
    NULL::boolean AS is_verified,
    collection.archived,
    NULL::text AS action_type,
    NULL::integer AS action_model_id,
        CASE
            WHEN ((collection.authority_level)::text = 'official'::text) THEN true
            ELSE false
        END AS collection_is_official,
        CASE
            WHEN (collection.personal_owner_id IS NOT NULL) THEN true
            ELSE false
        END AS collection_is_personal,
    NULL::text AS question_viz_type,
    NULL::text AS question_database_id,
    NULL::boolean AS question_is_native,
    NULL::timestamp without time zone AS event_timestamp
   FROM public.collection
UNION
 SELECT report_card.id AS entity_id,
    ('card_'::text || report_card.id) AS entity_qualified_id,
    report_card.type AS entity_type,
    report_card.created_at,
    report_card.updated_at,
    report_card.creator_id,
    report_card.name,
    report_card.description,
    report_card.collection_id,
    report_card.made_public_by_id AS made_public_by_user,
    report_card.enable_embedding AS is_embedding_enabled,
        CASE
            WHEN moderation.is_verified THEN true
            ELSE false
        END AS is_verified,
    report_card.archived,
    NULL::text AS action_type,
    NULL::integer AS action_model_id,
    NULL::boolean AS collection_is_official,
    NULL::boolean AS collection_is_personal,
    report_card.display AS question_viz_type,
    ('database_'::text || report_card.database_id) AS question_database_id,
        CASE
            WHEN ((report_card.query_type)::text = 'native'::text) THEN true
            ELSE false
        END AS question_is_native,
    NULL::timestamp without time zone AS event_timestamp
   FROM (public.report_card
     LEFT JOIN ( SELECT (((moderation_review.moderated_item_type)::text || '_'::text) || moderation_review.moderated_item_id) AS entity_qualified_id,
                CASE
                    WHEN ((moderation_review.status)::text = 'verified'::text) THEN true
                    ELSE false
                END AS is_verified
           FROM public.moderation_review
          WHERE moderation_review.most_recent) moderation ON ((('card_'::text || report_card.id) = moderation.entity_qualified_id)))
UNION
 SELECT report_dashboard.id AS entity_id,
    ('dashboard_'::text || report_dashboard.id) AS entity_qualified_id,
    'dashboard'::text AS entity_type,
    report_dashboard.created_at,
    report_dashboard.updated_at,
    report_dashboard.creator_id,
    report_dashboard.name,
    report_dashboard.description,
    report_dashboard.collection_id,
    report_dashboard.made_public_by_id AS made_public_by_user,
    report_dashboard.enable_embedding AS is_embedding_enabled,
        CASE
            WHEN moderation.is_verified THEN true
            ELSE false
        END AS is_verified,
    report_dashboard.archived,
    NULL::text AS action_type,
    NULL::integer AS action_model_id,
    NULL::boolean AS collection_is_official,
    NULL::boolean AS collection_is_personal,
    NULL::text AS question_viz_type,
    NULL::text AS question_database_id,
    NULL::boolean AS question_is_native,
    NULL::timestamp without time zone AS event_timestamp
   FROM (public.report_dashboard
     LEFT JOIN ( SELECT (((moderation_review.moderated_item_type)::text || '_'::text) || moderation_review.moderated_item_id) AS entity_qualified_id,
                CASE
                    WHEN ((moderation_review.status)::text = 'verified'::text) THEN true
                    ELSE false
                END AS is_verified
           FROM public.moderation_review
          WHERE moderation_review.most_recent) moderation ON ((('dashboard_'::text || report_dashboard.id) = moderation.entity_qualified_id)))
UNION
 SELECT event.id AS entity_id,
    ('event_'::text || event.id) AS entity_qualified_id,
    'event'::text AS entity_type,
    event.created_at,
    event.updated_at,
    event.creator_id,
    event.name,
    event.description,
    timeline.collection_id,
    NULL::integer AS made_public_by_user,
    NULL::boolean AS is_embedding_enabled,
    NULL::boolean AS is_verified,
    event.archived,
    NULL::text AS action_type,
    NULL::integer AS action_model_id,
    NULL::boolean AS collection_is_official,
    NULL::boolean AS collection_is_personal,
    NULL::text AS question_viz_type,
    NULL::text AS question_database_id,
    NULL::boolean AS question_is_native,
    event."timestamp" AS event_timestamp
   FROM (public.timeline_event event
     LEFT JOIN public.timeline ON ((event.timeline_id = timeline.id)));


ALTER VIEW public.v_content OWNER TO metabase;

--
-- Name: v_dashboardcard; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_dashboardcard AS
 SELECT id AS entity_id,
    concat('dashboardcard_', id) AS entity_qualified_id,
    concat('dashboard_', dashboard_id) AS dashboard_qualified_id,
    concat('dashboardtab_', dashboard_tab_id) AS dashboardtab_id,
    concat('card_', card_id) AS card_qualified_id,
    created_at,
    updated_at,
    size_x,
    size_y,
    visualization_settings,
    parameter_mappings
   FROM public.report_dashboardcard;


ALTER VIEW public.v_dashboardcard OWNER TO metabase;

--
-- Name: v_databases; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_databases AS
 SELECT id AS entity_id,
    concat('database_', id) AS entity_qualified_id,
    created_at,
    updated_at,
    name,
    description,
    engine AS database_type,
    metadata_sync_schedule,
    cache_field_values_schedule,
    timezone,
    is_on_demand,
    auto_run_queries,
    cache_ttl,
    creator_id,
    dbms_version AS db_version
   FROM public.metabase_database
  WHERE (id <> 13371337);


ALTER VIEW public.v_databases OWNER TO metabase;

--
-- Name: v_fields; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_fields AS
 SELECT id AS entity_id,
    ('field_'::text || id) AS entity_qualified_id,
    created_at,
    updated_at,
    name,
    display_name,
    description,
    base_type,
    visibility_type,
    fk_target_field_id,
    has_field_values,
    active,
    table_id
   FROM public.metabase_field;


ALTER VIEW public.v_fields OWNER TO metabase;

--
-- Name: v_group_members; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_group_members AS
 SELECT permissions_group_membership.user_id,
    permissions_group.id AS group_id,
    permissions_group.name AS group_name
   FROM (public.permissions_group_membership
     LEFT JOIN public.permissions_group ON ((permissions_group_membership.group_id = permissions_group.id)))
UNION
 SELECT 0 AS user_id,
    0 AS group_id,
    'Anonymous users'::character varying AS group_name;


ALTER VIEW public.v_group_members OWNER TO metabase;

--
-- Name: v_query_log; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_query_log AS
 SELECT query_execution.id AS entity_id,
    query_execution.started_at,
    ((query_execution.running_time)::double precision / (1000)::double precision) AS running_time_seconds,
    query_execution.result_rows,
    query_execution.native AS is_native,
    query_execution.context AS query_source,
    query_execution.error,
    COALESCE(query_execution.executor_id, 0) AS user_id,
    query_execution.card_id,
    ('card_'::text || query_execution.card_id) AS card_qualified_id,
    query_execution.dashboard_id,
    ('dashboard_'::text || query_execution.dashboard_id) AS dashboard_qualified_id,
    query_execution.pulse_id,
    query_execution.database_id,
    ('database_'::text || query_execution.database_id) AS database_qualified_id,
    query_execution.cache_hit,
    query_execution.action_id,
    ('action_'::text || query_execution.action_id) AS action_qualified_id,
    query.query
   FROM (public.query_execution
     LEFT JOIN public.query ON ((query_execution.hash = query.query_hash)));


ALTER VIEW public.v_query_log OWNER TO metabase;

--
-- Name: v_subscriptions; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_subscriptions AS
 WITH agg_recipients AS (
         SELECT pulse_channel_recipient.pulse_channel_id,
            string_agg((core_user.email)::text, ','::text) AS recipients
           FROM (public.pulse_channel_recipient
             LEFT JOIN public.core_user ON ((pulse_channel_recipient.user_id = core_user.id)))
          GROUP BY pulse_channel_recipient.pulse_channel_id
        )
 SELECT pulse.id AS entity_id,
    ('pulse_'::text || pulse.id) AS entity_qualified_id,
    pulse.created_at,
    pulse.updated_at,
    pulse.creator_id,
    pulse.archived,
    ('dashboard_'::text || pulse.dashboard_id) AS dashboard_qualified_id,
    pulse_channel.schedule_type,
    pulse_channel.schedule_day,
    pulse_channel.schedule_hour,
    pulse_channel.channel_type AS recipient_type,
    agg_recipients.recipients,
    pulse_channel.details AS recipient_external,
    pulse.parameters
   FROM ((public.pulse
     LEFT JOIN public.pulse_channel ON ((pulse.id = pulse_channel.pulse_id)))
     LEFT JOIN agg_recipients ON ((pulse_channel.id = agg_recipients.pulse_channel_id)))
  WHERE (pulse.alert_condition IS NULL);


ALTER VIEW public.v_subscriptions OWNER TO metabase;

--
-- Name: v_tables; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_tables AS
 SELECT id AS entity_id,
    ('table_'::text || id) AS entity_qualified_id,
    created_at,
    updated_at,
    name,
    display_name,
    description,
    active,
    db_id AS database_id,
    schema,
    is_upload
   FROM public.metabase_table;


ALTER VIEW public.v_tables OWNER TO metabase;

--
-- Name: v_tasks; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_tasks AS
 SELECT id,
    task,
    status,
    ('database_'::text || db_id) AS database_qualified_id,
    started_at,
    ended_at,
    ((duration)::double precision / (1000)::double precision) AS duration_seconds,
    task_details AS details
   FROM public.task_history;


ALTER VIEW public.v_tasks OWNER TO metabase;

--
-- Name: v_users; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_users AS
 SELECT core_user.id AS user_id,
    ('user_'::text || core_user.id) AS entity_qualified_id,
    core_user.type,
        CASE
            WHEN ((core_user.type)::text = 'api-key'::text) THEN NULL::public.citext
            ELSE core_user.email
        END AS email,
    core_user.first_name,
    core_user.last_name,
    (((core_user.first_name)::text || ' '::text) || (core_user.last_name)::text) AS full_name,
    core_user.date_joined,
    core_user.last_login,
    core_user.updated_at,
    core_user.is_superuser AS is_admin,
    core_user.is_active,
    core_user.sso_source,
    core_user.locale
   FROM public.core_user
UNION
 SELECT 0 AS user_id,
    'user_0'::text AS entity_qualified_id,
    'anonymous'::character varying AS type,
    NULL::public.citext AS email,
    'External'::character varying AS first_name,
    'User'::character varying AS last_name,
    'External User'::text AS full_name,
    NULL::timestamp with time zone AS date_joined,
    NULL::timestamp with time zone AS last_login,
    NULL::timestamp with time zone AS updated_at,
    false AS is_admin,
    NULL::boolean AS is_active,
    NULL::character varying AS sso_source,
    NULL::character varying AS locale;


ALTER VIEW public.v_users OWNER TO metabase;

--
-- Name: view_log; Type: TABLE; Schema: public; Owner: metabase
--

CREATE TABLE public.view_log (
    id integer NOT NULL,
    user_id integer,
    model character varying(16) NOT NULL,
    model_id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    metadata text,
    has_access boolean,
    context character varying(32),
    embedding_client character varying(254),
    embedding_version character varying(254)
);


ALTER TABLE public.view_log OWNER TO metabase;

--
-- Name: COLUMN view_log.has_access; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.view_log.has_access IS 'Whether the user who initiated the view had read access to the item being viewed.';


--
-- Name: COLUMN view_log.context; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.view_log.context IS 'The context of the view, can be collection, question, or dashboard. Only for cards.';


--
-- Name: COLUMN view_log.embedding_client; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.view_log.embedding_client IS 'Used by the embedding team to track SDK usage';


--
-- Name: COLUMN view_log.embedding_version; Type: COMMENT; Schema: public; Owner: metabase
--

COMMENT ON COLUMN public.view_log.embedding_version IS 'Used by the embedding team to track SDK version usage';


--
-- Name: v_view_log; Type: VIEW; Schema: public; Owner: metabase
--

CREATE VIEW public.v_view_log AS
 SELECT id,
    "timestamp",
    COALESCE(user_id, 0) AS user_id,
    model AS entity_type,
    model_id AS entity_id,
    (((model)::text || '_'::text) || model_id) AS entity_qualified_id
   FROM public.view_log;


ALTER VIEW public.v_view_log OWNER TO metabase;

--
-- Name: view_log_id_seq; Type: SEQUENCE; Schema: public; Owner: metabase
--

ALTER TABLE public.view_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.view_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: action; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.action (id, created_at, updated_at, type, model_id, name, description, parameters, parameter_mappings, visualization_settings, public_uuid, made_public_by_id, creator_id, archived, entity_id) FROM stdin;
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.api_key (id, user_id, key, key_prefix, creator_id, created_at, updated_at, name, updated_by_id, scope) FROM stdin;
\.


--
-- Data for Name: application_permissions_revision; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.application_permissions_revision (id, before, after, user_id, created_at, remark) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.audit_log (id, topic, "timestamp", end_timestamp, user_id, model, model_id, details) FROM stdin;
\.


--
-- Data for Name: bookmark_ordering; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.bookmark_ordering (id, user_id, type, item_id, ordering) FROM stdin;
\.


--
-- Data for Name: cache_config; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.cache_config (id, model, model_id, created_at, updated_at, strategy, config, state, invalidated_at, next_run_at, refresh_automatically) FROM stdin;
\.


--
-- Data for Name: card_bookmark; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.card_bookmark (id, user_id, card_id, created_at) FROM stdin;
\.


--
-- Data for Name: card_label; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.card_label (id, card_id, label_id) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.channel (id, name, description, type, details, active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel_template; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.channel_template (id, name, channel_type, details, created_at, updated_at) FROM stdin;
1	User joined Email template	channel/email	{"type":"email/handlebars-resource","subject":"{{payload.custom.user_invited_email_subject}}","path":"metabase/channel/email/new_user_invite.hbs","recipient-type":"cc"}	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
2	Notification Card Created Confirmation	channel/email	{"type":"email/handlebars-resource","subject":"You set up an alert","path":"metabase/channel/email/notification_card_new_confirmation.hbs","recipient-type":"cc"}	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
3	Slack Token Error Email template	channel/email	{"type":"email/handlebars-resource","subject":"Your Slack connection stopped working","path":"metabase/channel/email/slack_token_error.hbs","recipient-type":"cc"}	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
\.


--
-- Data for Name: cloud_migration; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.cloud_migration (id, external_id, upload_url, state, progress, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: collection; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.collection (id, name, description, archived, location, personal_owner_id, slug, namespace, authority_level, entity_id, created_at, type, is_sample, archive_operation_id, archived_directly) FROM stdin;
1	Trash	\N	f	/	\N	trash	\N	\N	trashtrashtrashtrasht	2025-04-13 06:23:49.215206+00	trash	f	\N	\N
2	Examples	Some examples to get started with	f	/	\N	examples	\N	\N	HyB3nRtqb7pBPhFG26evI	2025-04-13 06:23:57.296644+00	\N	t	\N	\N
3	E-commerce	Questions and metrics used for the parent dashboard	t	/2/	\N	e_commerce	\N	\N	54O0IbgCzm290Nnxf1wRH	2025-04-13 06:23:57.296644+00	\N	f	1e52f2e4-1304-4e09-9e0e-1dce5ea843af	t
4	admin super's Personal Collection	\N	f	/	1	admin_super_s_personal_collection	\N	\N	AIcAzgCMyzTJ-atmwwtjC	2025-04-13 06:25:44.760086+00	\N	f	\N	\N
\.


--
-- Data for Name: collection_bookmark; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.collection_bookmark (id, user_id, collection_id, created_at) FROM stdin;
\.


--
-- Data for Name: collection_permission_graph_revision; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.collection_permission_graph_revision (id, before, after, user_id, created_at, remark) FROM stdin;
\.


--
-- Data for Name: connection_impersonations; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.connection_impersonations (id, db_id, group_id, attribute) FROM stdin;
\.


--
-- Data for Name: core_session; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.core_session (id, user_id, created_at, anti_csrf_token, key_hashed) FROM stdin;
kfBRTpaKiZ5L	1	2025-04-13 06:25:18.553483+00	\N	9ccca4a2e7c311a6f2a3cda8bb7540c5747e91eef9528b3799b3ed78393156b63a9f81a43a3d6a65ebf97b8bf83bdf2b13e1d57fb0d0406d8b19e12ef7d1f757
\.


--
-- Data for Name: core_user; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.core_user (id, email, first_name, last_name, password, password_salt, date_joined, last_login, is_superuser, is_active, reset_token, reset_triggered, is_qbnewb, login_attributes, updated_at, sso_source, locale, is_datasetnewb, settings, type, entity_id, deactivated_at) FROM stdin;
13371338	internal@metabase.com	Metabase	Internal	$2a$10$0b5yXa6a4bhOuPURIfmzduVY9d5v74ECyHiGN88X1LiE9ySXsrtaK	c89121ec-93e8-4b0a-ba9c-e43b4aeb5140	2025-04-13 06:23:48.896986+00	\N	f	f	\N	\N	t	\N	\N	\N	\N	t	\N	internal	\N	\N
1	admin@example.com	admin	super	$2a$10$b/7ngPxot5bfmR869rovq.UpExCBv3dfkj9IeYkkfjjjEwbr4FDdW	2e29765e-ec7b-4c8f-a366-37bb0eab4e72	2025-04-13 06:25:18.553483+00	2025-04-13 06:25:18.796697+00	t	t	\N	\N	t	\N	2025-04-13 06:25:18.796697+00	\N	\N	t	{"last-acknowledged-version":"v0.54.2"}	personal	SndoOHhCkuYuK3dZobigl	\N
\.


--
-- Data for Name: dashboard_bookmark; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.dashboard_bookmark (id, user_id, dashboard_id, created_at) FROM stdin;
\.


--
-- Data for Name: dashboard_favorite; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.dashboard_favorite (id, user_id, dashboard_id) FROM stdin;
\.


--
-- Data for Name: dashboard_tab; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.dashboard_tab (id, dashboard_id, name, "position", entity_id, created_at, updated_at) FROM stdin;
1	1	Overview	0	UaPZl7PULaGoAGquao9XS	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00
2	1	Portfolio Performance	1	N-o1tJ9swdO4YJycqMA8P	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00
3	1	Website Analysis	2	dJjVk7QtJaNp6panPlnH5	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00
\.


--
-- Data for Name: dashboardcard_series; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.dashboardcard_series (id, dashboardcard_id, card_id, "position") FROM stdin;
\.


--
-- Data for Name: data_permissions; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.data_permissions (id, group_id, perm_type, db_id, schema_name, table_id, perm_value) FROM stdin;
1	1	perms/view-data	1	\N	\N	unrestricted
2	1	perms/create-queries	1	\N	\N	query-builder-and-native
3	1	perms/download-results	1	\N	\N	one-million-rows
4	1	perms/manage-table-metadata	1	\N	\N	no
5	1	perms/manage-database	1	\N	\N	no
7	1	perms/create-queries	2	\N	\N	query-builder-and-native
8	1	perms/view-data	2	\N	\N	unrestricted
9	1	perms/download-results	2	\N	\N	one-million-rows
10	1	perms/manage-table-metadata	2	\N	\N	no
11	1	perms/manage-database	2	\N	\N	no
\.


--
-- Data for Name: databasechangelog; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.databasechangelog (id, author, filename, dateexecuted, orderexecuted, exectype, md5sum, description, comments, tag, liquibase, contexts, labels, deployment_id) FROM stdin;
v50.2024-05-14T12:42:42	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.220124	348	EXECUTED	9:f31e7cb92753232e89fd9ec9cb1d43d5	sql	Create the Trash collection	\N	4.26.0	\N	\N	4525414792
v45.00-033	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.80381	18	MARK_RAN	9:b93dab321e4a1fcaeb74d12b52867fd4	sql	Added 0.45.0 -- add default value for DashboardCard created_at (MySQL/MariaDB)	\N	4.26.0	\N	\N	4525414792
v00.00-000	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.647239	1	EXECUTED	9:e346841fa1cd9d142e1237b37fdc8a20	sqlFile path=initialization/metabase_postgres.sql; sqlFile path=initialization/metabase_mysql.sql; sqlFile path=initialization/metabase_h2.sql	Initialze metabase	\N	4.26.0	\N	\N	4525414792
v45.00-001	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.660978	2	EXECUTED	9:15c13a8aa3fdc72ef0c54f4cccfc39e1	createTable tableName=action	Added 0.44.0 - writeback	\N	4.26.0	\N	\N	4525414792
v45.00-002	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.673203	3	EXECUTED	9:d2c9f50f5a29947a07e4808957d63ab6	createTable tableName=query_action	Added 0.44.0 - writeback	\N	4.26.0	\N	\N	4525414792
v45.00-003	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.681721	4	EXECUTED	9:dafaaf7c9f0efbf92670ea93c001f7a1	addPrimaryKey constraintName=pk_query_action, tableName=query_action	Added 0.44.0 - writeback	\N	4.26.0	\N	\N	4525414792
v45.00-011	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.691296	5	EXECUTED	9:c539f152aa1c2287c5b602c7a395f9e8	addColumn tableName=report_card	Added 0.44.0 - writeback	\N	4.26.0	\N	\N	4525414792
v45.00-012	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.708896	6	EXECUTED	9:b872219f47d12ec80db8f1731be4ce94	createTable tableName=http_action	Added 0.44.0 - writeback	\N	4.26.0	\N	\N	4525414792
v45.00-013	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.715804	7	EXECUTED	9:54c5d6a9659b7ae62e8c42f60f9620d2	addPrimaryKey constraintName=pk_http_action, tableName=http_action	Added 0.44.0 - writeback	\N	4.26.0	\N	\N	4525414792
v45.00-022	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.730485	8	EXECUTED	9:06e8a3ba8c4c5e5cf8e6aa3f35081cac	createTable tableName=app	Added 0.45.0 - add app container	\N	4.26.0	\N	\N	4525414792
v45.00-023	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.742792	9	EXECUTED	9:082d296233ee6dbbf2871b9d93c3a6a4	addForeignKeyConstraint baseTableName=app, constraintName=fk_app_ref_dashboard_id, referencedTableName=report_dashboard	Added 0.45.0 - add app container	\N	4.26.0	\N	\N	4525414792
v45.00-025	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.752295	10	EXECUTED	9:2214b0d71acc8a8cf90781a2aca98664	addColumn tableName=report_dashboard	Added 0.45.0 - mark app pages	\N	4.26.0	\N	\N	4525414792
v45.00-026	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.760693	11	EXECUTED	9:9f2ce2d2d79d0dce365ddf3464d1f648	addColumn tableName=report_dashboardcard	Added 0.45.0 - apps add action_id to report_dashboardcard	\N	4.26.0	\N	\N	4525414792
v45.00-027	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.768115	12	EXECUTED	9:73718f7b7c3fb4ef30f71dc6e6170528	addForeignKeyConstraint baseTableName=report_dashboardcard, constraintName=fk_report_dashboardcard_ref_action_id, referencedTableName=action	Added 0.45.0 - apps add fk for action_id to report_dashboardcard	\N	4.26.0	\N	\N	4525414792
v45.00-028	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.774325	13	EXECUTED	9:883315d70f3fc10b07858aa0e48ed9da	renameColumn newColumnName=size_x, oldColumnName=sizeX, tableName=report_dashboardcard	Added 0.45.0 -- rename DashboardCard sizeX to size_x. See https://github.com/metabase/metabase/issues/16344	\N	4.26.0	\N	\N	4525414792
v45.00-029	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.781436	14	EXECUTED	9:fe3b8aca811ef5b541f922a83c7ded8c	renameColumn newColumnName=size_y, oldColumnName=sizeY, tableName=report_dashboardcard	Added 0.45.0 -- rename DashboardCard size_y to size_y. See https://github.com/metabase/metabase/issues/16344	\N	4.26.0	\N	\N	4525414792
v45.00-030	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.786774	15	EXECUTED	9:63da8f2f82baf396ad30f3fd451c501d	addDefaultValue columnName=size_x, tableName=report_dashboardcard	Added 0.45.0 -- add default value to DashboardCard size_x -- this was previously done by Toucan	\N	4.26.0	\N	\N	4525414792
v45.00-031	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.79292	16	EXECUTED	9:3628c1c692bec0f7258ea983b18340b5	addDefaultValue columnName=size_y, tableName=report_dashboardcard	Added 0.45.0 -- add default value to DashboardCard size_y -- this was previously done by Toucan	\N	4.26.0	\N	\N	4525414792
v45.00-032	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.800103	17	EXECUTED	9:7a6f0320210b82c5eafe836ea98f477d	addDefaultValue columnName=created_at, tableName=report_dashboardcard	Added 0.45.0 -- add default value for DashboardCard created_at (Postgres/H2)	\N	4.26.0	\N	\N	4525414792
v45.00-034	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.813428	19	EXECUTED	9:39c965f9dc521d2a1e196f645d11de9e	addDefaultValue columnName=updated_at, tableName=report_dashboardcard	Added 0.45.0 -- add default value for DashboardCard updated_at (Postgres/H2)	\N	4.26.0	\N	\N	4525414792
v45.00-035	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.815962	20	MARK_RAN	9:207984e21c44681a6135592cab3d0f3f	sql	Added 0.45.0 -- add default value for DashboardCard updated_at (MySQL/MariaDB)	\N	4.26.0	\N	\N	4525414792
v45.00-036	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.833839	21	EXECUTED	9:8632f7a046e1094399c517b05f0feea3	createTable tableName=model_action	Added 0.45.0 - add model action table	\N	4.26.0	\N	\N	4525414792
v45.00-037	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.842473	22	EXECUTED	9:6600702fb0cc9dcd8628fca8df9c0b39	addUniqueConstraint constraintName=unique_model_action_card_id_slug, tableName=model_action	Added 0.45.0 - model action	\N	4.26.0	\N	\N	4525414792
v45.00-038	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.849733	23	EXECUTED	9:5ae52c12861e5eec6a2a9a8c5a442826	addDefaultValue columnName=created_at, tableName=metabase_database	Added 0.45.0 -- add default value for Database created_at (Postgres/H2)	\N	4.26.0	\N	\N	4525414792
v45.00-039	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.852717	24	MARK_RAN	9:7b331f47a0260218275c58fa21fdcc60	sql	Added 0.45.0 -- add default value for Database created_at (MySQL/MariaDB)	\N	4.26.0	\N	\N	4525414792
v45.00-040	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.861402	25	EXECUTED	9:6d6fb2c7cd62868b9878a951c8596cec	addDefaultValue columnName=updated_at, tableName=metabase_database	Added 0.45.0 -- add default value for Database updated_at (Postgres/H2)	\N	4.26.0	\N	\N	4525414792
v45.00-041	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.864775	26	MARK_RAN	9:84d479472b81809b8067f72b28934954	sql	Added 0.45.0 -- add default value for Database updated_at (MySQL/MariaDB)	\N	4.26.0	\N	\N	4525414792
v45.00-042	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.872244	27	EXECUTED	9:f600f2e052bf44938d081165c8d87364	sql	Added 0.45.0 -- add default value for Database with NULL details	\N	4.26.0	\N	\N	4525414792
v45.00-043	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.880084	28	EXECUTED	9:f97ef9506c96084958075bb7c8d67b37	addNotNullConstraint columnName=details, tableName=metabase_database	Added 0.45.0 -- make Database details NOT NULL	\N	4.26.0	\N	\N	4525414792
v45.00-044	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.8926	29	EXECUTED	9:3a2bdd2e615d4577394828afda7fe61b	createTable tableName=app_permission_graph_revision	Added 0.45.0 -- create app permission graph revision table	\N	4.26.0	\N	\N	4525414792
v45.00-048	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.901691	30	EXECUTED	9:20fea59b307a381f506485c07b3434f0	addColumn tableName=collection	Added 0.45.0 -- add created_at to Collection	\N	4.26.0	\N	\N	4525414792
v45.00-049	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.908633	31	EXECUTED	9:525cdee9190fec1c22f431bbc4c33165	sql; sql; sql	Added 0.45.0 -- set Collection.created_at to User.date_joined for Personal Collections	\N	4.26.0	\N	\N	4525414792
v45.00-050	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.919531	32	EXECUTED	9:6a28bbf7cf34c8730e1d3151fcc5b090	sql; sql; sql	Added 0.45.0 -- seed Collection.created_at with value of oldest item for non-Personal Collections	\N	4.26.0	\N	\N	4525414792
v45.00-051	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.922213	33	MARK_RAN	9:21a53bba289feab23d8a322e28c1e281	modifyDataType columnName=after, tableName=collection_permission_graph_revision	Added 0.45.0 - modify type of collection_permission_graph_revision.after from text to text on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v45.00-052	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.926438	34	MARK_RAN	9:6cbe88994cc644d01d336851484f7d04	modifyDataType columnName=before, tableName=collection_permission_graph_revision	Added 0.45.0 - modify type of collection_permission_graph_revision.before from text to text on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v45.00-053	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.930727	35	MARK_RAN	9:ea7fc60a2091ce7a78266b6b2a0f91ef	modifyDataType columnName=remark, tableName=collection_permission_graph_revision	Added 0.45.0 - modify type of collection_permission_graph_revision.remark from text to text on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v45.00-054	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.934307	36	MARK_RAN	9:b150b811b511b9a2f9a063f1e72e144b	modifyDataType columnName=after, tableName=permissions_revision	Added 0.45.0 - modify type of permissions_revision.after from text to text on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v45.00-055	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.938415	37	MARK_RAN	9:b0e45cae16c5f3ba5b3becf3b767dced	modifyDataType columnName=before, tableName=permissions_revision	Added 0.45.0 - modify type of permissions_revision.before from text to text on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v45.00-056	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.942838	38	MARK_RAN	9:2b7e01dd0c5f8d720cbc346526f712ae	modifyDataType columnName=remark, tableName=permissions_revision	Added 0.45.0 - modify type of permissions_revision.remark from text to text on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v45.00-057	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.947463	39	MARK_RAN	9:d1125daee3e40f7a316c59c6b7a0fb1b	modifyDataType columnName=value, tableName=secret	Added 0.45.0 - modify type of secret.value from blob to longblob on mysql,mariadb	\N	4.26.0	\N	\N	4525414792
v46.00-000	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.958864	40	EXECUTED	9:ebf6161a0fd64634e0032cf8c44e2c64	createTable tableName=implicit_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-001	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.966173	41	EXECUTED	9:9a3a543cd836c34d8131b6c929061425	addColumn tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-002	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.973007	42	EXECUTED	9:a352e46d75236605148308fc7e95cfe6	addColumn tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-003	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.98063	43	EXECUTED	9:c9ae88de84e869dbda6681c543d9701c	addColumn tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-004	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.987162	44	EXECUTED	9:f7b94fa036afd26110610156dc0054ea	addColumn tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-005	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:35.994629	45	EXECUTED	9:60be619c1c562da167a15ea8cc7421b3	addColumn tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-006	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.000865	46	EXECUTED	9:3c24b56f156b5891db5ee8a3b0a68195	addColumn tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-007	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.00809	47	EXECUTED	9:604733020cb8d94b0b21728393b9227a	addForeignKeyConstraint baseTableName=action, constraintName=fk_action_model_id, referencedTableName=report_card	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-008	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.015678	48	EXECUTED	9:24adc5d36405f95e479157afa6ac7090	addColumn tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-009	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.024364	49	EXECUTED	9:a54fda21eeecdf97eab5c25e7ad616be	addColumn tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-010	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.032536	50	EXECUTED	9:17661d9a15cea0e046aa22bbe05f8ca9	addForeignKeyConstraint baseTableName=query_action, constraintName=fk_query_action_database_id, referencedTableName=metabase_database	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-011	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.040616	51	EXECUTED	9:704a13bc4f66dba37ce7fbf130c2d207	sql; sql; sql	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-012	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.04874	52	EXECUTED	9:f5e43052660cb6fd61dca7385a41690f	dropNotNullConstraint columnName=card_id, tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-013	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.067786	53	EXECUTED	9:12bf37b0e6732f2f09122f76cb8b59b5	sql	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-014	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.075312	54	EXECUTED	9:f5856fab23b69dbc669c354d5cb14d36	dropForeignKeyConstraint baseTableName=query_action, constraintName=fk_query_action_ref_card_id	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-015	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.082466	55	EXECUTED	9:1ef231990b57b1f8496070f5f63f4579	dropColumn columnName=card_id, tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-016	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.088794	56	EXECUTED	9:cf5ae825070bb05fd046b0a22f299403	sql	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-017	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.095956	57	EXECUTED	9:7428779ccdce61097d0fe5e761e05b18	dropColumn columnName=name, tableName=http_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-018	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.101802	58	EXECUTED	9:1ae9ab13080fc2dd4df6ccdeb28baf72	dropColumn columnName=description, tableName=http_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-019	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.108491	59	EXECUTED	9:ffa18e1fb9a06d0a673a1d6aab1edfbc	dropColumn columnName=is_write, tableName=report_card	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-020	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.114961	60	EXECUTED	9:f96413cb1260923de7be41fd0a665543	addNotNullConstraint columnName=database_id, tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-021	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.121688	61	EXECUTED	9:92176e007f82994418edd21c13ea648d	addNotNullConstraint columnName=dataset_query, tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-022	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.128474	62	EXECUTED	9:92176e007f82994418edd21c13ea648d	addNotNullConstraint columnName=dataset_query, tableName=query_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-023	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.134606	63	EXECUTED	9:072dea52b8b04cbb2829741c8523d768	addNotNullConstraint columnName=model_id, tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-024	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.141779	64	EXECUTED	9:92798789cb9756596896f74e7055988d	addNotNullConstraint columnName=name, tableName=action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-025	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.151441	65	EXECUTED	9:cedeeebf30271f749b77f79609b197ba	dropTable tableName=model_action	Added 0.46.0 - Unify action representation	\N	4.26.0	\N	\N	4525414792
v46.00-026	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.158606	66	EXECUTED	9:2466f8ea4308426e2dfaa1a0f89d2807	addColumn tableName=metabase_database	Added 0.46.0 -- add field for tracking DBMS versions	\N	4.26.0	\N	\N	4525414792
v46.00-027	snoe	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.165843	67	EXECUTED	9:1450a0a51d88a368393d2202a8e194fd	addColumn tableName=metabase_fieldvalues	Added 0.46.0 -- add last_used_at to FieldValues	\N	4.26.0	\N	\N	4525414792
v46.00-028	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.182604	68	EXECUTED	9:cc1b9daf6ce06234decfadd3a2629a80	createTable tableName=parameter_card	Added 0.46.0 -- Join table connecting cards to dashboards/cards's parameters that need custom filter values from the card	\N	4.26.0	\N	\N	4525414792
v46.00-029	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.190707	69	EXECUTED	9:c95d07d656ec9c2d06e9d83ab14e5170	dropUniqueConstraint constraintName=unique_dimension_field_id_name, tableName=dimension	Make Dimension <=> Field a 1t1 relationship. Drop unique constraint on field_id + name. (1/3)	\N	4.26.0	\N	\N	4525414792
v46.00-030	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.198344	70	EXECUTED	9:3342b8ad5e8160325705f4df619c1416	sql	Make Dimension <=> Field a 1t1 relationship. Delete duplicate entries. (2/3)	\N	4.26.0	\N	\N	4525414792
v46.00-031	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.20616	71	EXECUTED	9:5822fde920ae9c048d75e951674c6570	addUniqueConstraint constraintName=unique_dimension_field_id, tableName=dimension	Make Dimension <=> Field a 1t1 relationship. Add unique constraint on field_id. (3/3)	\N	4.26.0	\N	\N	4525414792
v46.00-032	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.214581	72	EXECUTED	9:2e882eb92ce78edf23d417dcbc7c4f03	addUniqueConstraint constraintName=unique_parameterized_object_card_parameter, tableName=parameter_card	Added 0.46.0 -- Unique parameter_card	\N	4.26.0	\N	\N	4525414792
v46.00-033	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.222415	73	EXECUTED	9:2ca24580b18e8a0736cc1c0b463d43a6	createIndex indexName=idx_parameter_card_parameterized_object_id, tableName=parameter_card	Added 0.46.0 -- parameter_card index on connected object	\N	4.26.0	\N	\N	4525414792
v46.00-034	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.230337	74	EXECUTED	9:654f10ff8db9163f27f87fc7da686912	createIndex indexName=idx_parameter_card_card_id, tableName=parameter_card	Added 0.46.0 -- parameter_card index on connected card	\N	4.26.0	\N	\N	4525414792
v50.2024-01-04T13:52:51	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.590378	290	EXECUTED	9:19f8b6614c4fe95ff71b42830785df04	createTable tableName=data_permissions	Data permissions table	\N	4.26.0	\N	\N	4525414792
v46.00-035	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.23704	75	EXECUTED	9:54d48bc5d1b60faa10ba000c3409c973	addForeignKeyConstraint baseTableName=parameter_card, constraintName=fk_parameter_card_ref_card_id, referencedTableName=report_card	Added 0.46.0 - parameter_card.card_id foreign key	\N	4.26.0	\N	\N	4525414792
v46.00-036	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.244715	76	EXECUTED	9:5e155b0c1edc895bddf0e5de96def85e	dropTable tableName=app_permission_graph_revision	App containers are removed in 0.46.0	\N	4.26.0	\N	\N	4525414792
v46.00-037	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.251201	77	EXECUTED	9:ba61742e04377180572fb011d5ad3263	dropColumn columnName=is_app_page, tableName=report_dashboard	App pages are removed in 0.46.0	\N	4.26.0	\N	\N	4525414792
v46.00-038	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.261563	78	EXECUTED	9:a45d7cfa18714cd1d536bd17b927e3ac	dropTable tableName=app	App containers are removed in 0.46.0	\N	4.26.0	\N	\N	4525414792
v46.00-039	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.271064	79	EXECUTED	9:a850f5255ad1f2abb52d4a7c93fa68a0	addColumn tableName=parameter_card	Added 0.46.0 - add entity_id to parameter_card	\N	4.26.0	\N	\N	4525414792
v46.00-040	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.278287	80	EXECUTED	9:400fe00b6e522509e4949a71cc12e196	addDefaultValue columnName=size_x, tableName=report_dashboardcard	Added 0.46.0 -- Bump default dashcard size to 4x4	\N	4.26.0	\N	\N	4525414792
v46.00-041	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.286153	81	EXECUTED	9:0f7635baf2acb131464865f2a94a17ed	addDefaultValue columnName=size_y, tableName=report_dashboardcard	Added 0.46.0 -- Bump default dashcard size to 4x4	\N	4.26.0	\N	\N	4525414792
v46.00-042	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.293737	82	EXECUTED	9:6b99f953adbc8c3f536c7d729ef780a2	createIndex indexName=idx_query_execution_executor_id, tableName=query_execution	Added 0.46.0 -- index query_execution.executor_id	\N	4.26.0	\N	\N	4525414792
v46.00-043	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.300721	83	EXECUTED	9:6fd04070a9c19ac34c15a5cbe27def47	createIndex indexName=idx_query_execution_context, tableName=query_execution	Added 0.46.0 -- index query_execution.context	\N	4.26.0	\N	\N	4525414792
v46.00-045	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.308463	84	EXECUTED	9:1f61e64d7ce15c315ff530ef8a2dc7f3	addColumn tableName=action	Added 0.46.0 -- add public_uuid to action.	\N	4.26.0	\N	\N	4525414792
v46.00-051	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.315238	85	EXECUTED	9:7f54a26b4edf1aa4bc86b95f9c316dea	dropDefaultValue columnName=row, tableName=report_dashboardcard	Added 0.46.0 -- drop defaults for dashcard's position and size	\N	4.26.0	\N	\N	4525414792
v46.00-052	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.320687	86	EXECUTED	9:4fc7e45d19ab28e91bd27325d23afd83	dropDefaultValue columnName=col, tableName=report_dashboardcard	Added 0.46.0 -- drop defaults for dashcard's position and size	\N	4.26.0	\N	\N	4525414792
v46.00-053	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.326365	87	EXECUTED	9:2d2836a1c76d1c5db400219364aa070e	dropDefaultValue columnName=size_x, tableName=report_dashboardcard	Added 0.46.0 -- drop defaults for dashcard's position and size	\N	4.26.0	\N	\N	4525414792
v46.00-054	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.332244	88	EXECUTED	9:60b7a066e6ca1826efcb8b562b33f331	dropDefaultValue columnName=size_y, tableName=report_dashboardcard	Added 0.46.0 -- drop defaults for dashcard's position and size	\N	4.26.0	\N	\N	4525414792
v46.00-055	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.3386	89	EXECUTED	9:5b583b1b5eac915914f40a27163263b3	addColumn tableName=action	Added 0.46.0 -- add made_public_by_id	\N	4.26.0	\N	\N	4525414792
v46.00-056	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.34662	90	EXECUTED	9:9e37acc40f5685ec3992dff91bbfa618	createIndex indexName=idx_action_public_uuid, tableName=action	Added 0.46.0 -- add public_uuid and made_public_by_id to action. public_uuid is indexed	\N	4.26.0	\N	\N	4525414792
v46.00-057	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.353449	91	EXECUTED	9:86b2d39951f748b94abd2e1c7b68144a	modifyDataType columnName=parameter_id, tableName=parameter_card	Added 0.46.0 -- parameter_card.parameter_id long enough to hold a uuid	\N	4.26.0	\N	\N	4525414792
v46.00-058	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.360843	92	EXECUTED	9:7458ddbf194a385219df05900d78185d	addForeignKeyConstraint baseTableName=action, constraintName=fk_action_made_public_by_id, referencedTableName=core_user	Added 0.46.0 -- add FK constraint for action.made_public_by_id with core_user.id	\N	4.26.0	\N	\N	4525414792
v46.00-059	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.367807	93	EXECUTED	9:55a077fb646639308046b80c3f64267e	addColumn tableName=action	Added 0.46.0 -- add actions.creator_id	\N	4.26.0	\N	\N	4525414792
v46.00-060	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.375416	94	EXECUTED	9:a0726ea2ef7c354af8b60a8ab37d24bd	createIndex indexName=idx_action_creator_id, tableName=action	Added 0.46.0 -- action.creator_id index	\N	4.26.0	\N	\N	4525414792
v46.00-061	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.383246	95	EXECUTED	9:7497cc10ea1fdad211179b36d53bde6a	addForeignKeyConstraint baseTableName=action, constraintName=fk_action_creator_id, referencedTableName=core_user	Added 0.46.0 -- action.creator_id index	\N	4.26.0	\N	\N	4525414792
v46.00-062	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.391326	96	EXECUTED	9:35cc67731bc19abd498bcdbb0aeb688e	addColumn tableName=action	Added 0.46.0 -- add actions.archived	\N	4.26.0	\N	\N	4525414792
v46.00-064	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.398524	97	EXECUTED	9:a73357bb088af23043336f048172a1f3	renameTable newTableName=sandboxes, oldTableName=group_table_access_policy	Added 0.46.0 -- rename `group_table_access_policy` to `sandboxes`	\N	4.26.0	\N	\N	4525414792
v46.00-065	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.405053	98	EXECUTED	9:b5b5d61c3e6f7daa528acce1a52b6f75	addColumn tableName=sandboxes	Added 0.46.0 -- add `permission_id` to `sandboxes`	\N	4.26.0	\N	\N	4525414792
v46.00-070	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.414211	99	EXECUTED	9:e52174e49aa14e61eb922ba200cfc002	addColumn tableName=action	Added 0.46.0 - add entity_id column to action	\N	4.26.0	\N	\N	4525414792
v46.00-074	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.419536	100	EXECUTED	9:c2c5004951b49617a624ba2cf79fb617	modifyDataType columnName=updated_at, tableName=report_card	Added 0.46.0 -- increase precision of updated_at of report_card	\N	4.26.0	\N	\N	4525414792
v46.00-079	john-metabase	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.424689	101	EXECUTED	9:e5ce98dd7ac26fb102db98625e10dfab	sql	Added 0.46.0 -- migrates Databases using deprecated and removed presto driver to presto-jdbc	\N	4.26.0	\N	\N	4525414792
v46.00-080	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.460971	102	EXECUTED	9:742aaa27012538f89770095551808dbc	customChange	Migrate data permission paths from v1 to v2 (splitting them into separate data and query permissions)	\N	4.26.0	\N	\N	4525414792
v46.00-084	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.467375	103	EXECUTED	9:ec26e53892d1293ef822005b0e2d5d0d	dropForeignKeyConstraint baseTableName=action, constraintName=fk_action_model_id	Added 0.46.0 - CASCADE delete for action.model_id	\N	4.26.0	\N	\N	4525414792
v46.00-085	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.474126	104	EXECUTED	9:013d55806a3c819a2e94ff2d5cb71df2	addForeignKeyConstraint baseTableName=action, constraintName=fk_action_model_id, referencedTableName=report_card	Added 0.46.0 - CASCADE delete for action.model_id	\N	4.26.0	\N	\N	4525414792
v46.00-086	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.575705	105	EXECUTED	9:3029f7b7b204834ce65fc573378b3425	customChange	Added 0.46.0 - Delete the abandonment email task	\N	4.26.0	\N	\N	4525414792
v46.00-088	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.581574	106	EXECUTED	9:c38b799746664b436dc8c63f2c6214c6	sql	Added 0.46.5 -- backfill `permission_id` values in `sandboxes`. This is a fixed verison of v46.00-066 which has been removed, since it had a bug that blocked a customer from upgrading.	\N	4.26.0	\N	\N	4525414792
v46.00-089	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:36.586485	107	EXECUTED	9:7a7761ef80cae24914abb65143fb0503	sql	Added 0.46.5 -- remove orphaned entries in `sandboxes`	\N	4.26.0	\N	\N	4525414792
v46.00-090	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.446879	108	EXECUTED	9:d17eaed2e43c5589332682c53e4a6458	addForeignKeyConstraint baseTableName=sandboxes, constraintName=fk_sandboxes_ref_permissions, referencedTableName=permissions	Add foreign key constraint on sandboxes.permission_id	\N	4.26.0	\N	\N	4525414792
v47.00-001	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.453453	109	EXECUTED	9:b655eb44da8863f3021bd71dc14e69b3	sql	Added 0.47.0 -- set base-type to type/JSON for JSON database-types for postgres and mysql	\N	4.26.0	\N	\N	4525414792
v47.00-002	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.459408	110	EXECUTED	9:1983e3e2e005932513c2146770aa7f37	addColumn tableName=metabase_field	Added 0.47.0 - Add json_unfolding column to metabase_field	\N	4.26.0	\N	\N	4525414792
v47.00-003	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.463696	111	EXECUTED	9:a3cdc062588a6c5c4459d48dc1b76519	sql	Added 0.47.0 - Populate metabase_field.json_unfolding based on base_type	\N	4.26.0	\N	\N	4525414792
v47.00-004	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.469031	112	EXECUTED	9:9457f62a9c6533da79c4881ca21d727f	addColumn tableName=metabase_field	Added 0.47.0 - Add auto_incremented to metabase_field	\N	4.26.0	\N	\N	4525414792
v47.00-005	winlost	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.475402	113	EXECUTED	9:afc9309217305117e3b9e88018c5437e	addColumn tableName=report_dashboard	Added 0.47.0 - Add auto_apply_filters to dashboard	\N	4.26.0	\N	\N	4525414792
v47.00-006	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.488234	114	EXECUTED	9:98647900eba8f78d7bef0678415ebe2a	createTable tableName=dashboard_tab	Added 0.47.0 - Add dashboard_tab table	\N	4.26.0	\N	\N	4525414792
v47.00-007	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.494814	115	EXECUTED	9:7e6c0250df2957d89875cd0d14d271ee	addColumn tableName=report_dashboardcard	Added 0.47.0 -- add report_dashboardcard.dashboard_tab_id	\N	4.26.0	\N	\N	4525414792
v47.00-008	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.50172	116	EXECUTED	9:606ece18373d1e534db0714add1c41e8	addForeignKeyConstraint baseTableName=report_dashboardcard, constraintName=fk_report_dashboardcard_ref_dashboard_tab_id, referencedTableName=dashboard_tab	Added 0.47.0 -- add report_dashboardcard.dashboard_tab_id fk constraint	\N	4.26.0	\N	\N	4525414792
v47.00-009	qwef	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.506788	117	EXECUTED	9:738a13b99f62269ff366f57c09652ebc	sql	Added 0.47.0 - Replace user google_auth and ldap_auth columns with sso_source values	\N	4.26.0	\N	\N	4525414792
v47.00-010	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.512458	118	EXECUTED	9:5d9a509a79dedadff743042b6f82ddbe	modifyDataType columnName=name, tableName=metabase_table	Added 0.47.0 - Make metabase_table.name long enough for H2 names	\N	4.26.0	\N	\N	4525414792
v47.00-011	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.51789	119	EXECUTED	9:7a6a06886b1428bf54d5105d1d4fcf0a	modifyDataType columnName=display_name, tableName=metabase_table	Added 0.47.0 - Make metabase_table.display_name long enough for H2 names	\N	4.26.0	\N	\N	4525414792
v47.00-012	qwef	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.522672	120	EXECUTED	9:42ca291fec3fb0a7bdd74dd17d03339a	dropColumn columnName=google_auth, tableName=core_user	Added 0.47.0 - Replace user google_auth and ldap_auth columns with sso_source values	\N	4.26.0	\N	\N	4525414792
v47.00-013	qwef	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.527408	121	EXECUTED	9:fcc22e7f3fd2f6e52739a8b9778f8e50	sql	Added 0.47.0 - Replace user google_auth and ldap_auth columns with sso_source values	\N	4.26.0	\N	\N	4525414792
v47.00-014	qwef	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.53386	122	EXECUTED	9:e8309c65ac1f122f944e64d702409377	dropColumn columnName=ldap_auth, tableName=core_user	Added 0.47.0 - Replace user google_auth and ldap_auth columns with sso_source values	\N	4.26.0	\N	\N	4525414792
v47.00-015	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.540544	123	EXECUTED	9:a05fe66edd2512f17a9fc7f9ff122669	addColumn tableName=metabase_database	added 0.47.0 - Add is_audit to metabase_database	\N	4.26.0	\N	\N	4525414792
v47.00-016	calherres	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.55661	124	EXECUTED	9:dbd88ce575f7976114e5b8c7e0382a5a	customChange	Added 0.47.0 - Migrate the report_card.visualization_settings.column_settings field refs from legacy format	\N	4.26.0	\N	\N	4525414792
v47.00-018	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.568205	125	EXECUTED	9:ec0895ba935e438f7cd104534b3b13f4	createTable tableName=model_index	Indexed Entities information table	\N	4.26.0	\N	\N	4525414792
v47.00-019	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.575414	126	EXECUTED	9:d3d383af3f3c901efdd891a405c2639b	createTable tableName=model_index_value	Indexed Entities values table	\N	4.26.0	\N	\N	4525414792
v47.00-020	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.582815	127	EXECUTED	9:96991ffa2c754f2f70d61928c7574e31	addUniqueConstraint constraintName=unique_model_index_value_model_index_id_model_pk, tableName=model_index_value	Add unique constraint on index_id and pk	\N	4.26.0	\N	\N	4525414792
v47.00-023	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.58884	128	EXECUTED	9:ab9a7a030405fc844b36f10d77fef039	createIndex indexName=idx_model_index_model_id, tableName=model_index	Added 0.47.0 -- model_index index	\N	4.26.0	\N	\N	4525414792
v47.00-024	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.595781	129	EXECUTED	9:ab4cd02348503fcaa7cedd49d11d217d	addForeignKeyConstraint baseTableName=model_index, constraintName=fk_model_index_model_id, referencedTableName=report_card	Added 0.47.0 -- model_index foriegn key to report_card	\N	4.26.0	\N	\N	4525414792
v50.2024-03-22T00:38:28	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.872006	316	EXECUTED	9:24cd167582544658226746847e145181	createTable tableName=field_usage	Add field_usage table	\N	4.26.0	\N	\N	4525414792
v47.00-025	dpsutton	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.600965	130	EXECUTED	9:e002aab419bb327f68a09b604eb24fa5	addForeignKeyConstraint baseTableName=model_index_value, constraintName=fk_model_index_value_model_id, referencedTableName=model_index	Added 0.47.0 -- model_index_value foriegn key to model_index	\N	4.26.0	\N	\N	4525414792
v47.00-026	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.612244	131	EXECUTED	9:cd23ef8fb587021b6a7190811db35b90	createTable tableName=connection_impersonations	Added 0.47.0 - New table for connection impersonation policies	\N	4.26.0	\N	\N	4525414792
v47.00-027	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.622434	132	EXECUTED	9:a40730a20a1f9ae345d15f9c2bfa443e	customChange	Added 0.47.0 - Migrate field_ref in report_card.result_metadata from legacy format	\N	4.26.0	\N	\N	4525414792
v47.00-028	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.631424	133	EXECUTED	9:66ec973062109ac00d89c8bb1a867d1e	customChange	Added 0.47.0 - Add join-alias to the report_card.visualization_settings.column_settings field refs	\N	4.26.0	\N	\N	4525414792
v47.00-029	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.636723	134	EXECUTED	9:4e63a84adeeacdbe8ecf771e3f6cf65e	customChange	Added 0.47.0 - Stack cards vertically for dashboard with tabs on downgrade	\N	4.26.0	\N	\N	4525414792
v47.00-030	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.643644	135	EXECUTED	9:e6d3c56859e8c41a5c5f6b7ebcc489d7	addColumn tableName=collection	Added 0.47.0 - Type column for collections for instance-analytics	\N	4.26.0	\N	\N	4525414792
v47.00-031	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.649867	136	EXECUTED	9:6c0047955d2fc52cd25e4e4aabdc7143	sql; sql	Added 0.47.0 - migrate dashboard grid size from 18 to 24	\N	4.26.0	\N	\N	4525414792
v47.00-032	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.657383	137	EXECUTED	9:e9621439a79c5255a2cfe540c1e8df73	customChange	Added 0.47.0 - migrate dashboard grid size from 18 to 24 for revisions	\N	4.26.0	\N	\N	4525414792
v47.00-033	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.664246	138	EXECUTED	9:ef48cabec16353dc09a6297d06e27a9f	customChange	Added 0.47.0 - Migrate field refs in visualization_settings.column_settings keys from legacy format	\N	4.26.0	\N	\N	4525414792
v47.00-034	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.670058	139	EXECUTED	9:9032d7052ab38a476e7f83d9486e8609	customChange	Added 0.47.0 - Add join-alias to the visualization_settings.column_settings field refs in card revisions	\N	4.26.0	\N	\N	4525414792
v47.00-035	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.674966	140	EXECUTED	9:57f53ab4caba81bea788f23487b6888a	dropForeignKeyConstraint baseTableName=implicit_action, constraintName=fk_implicit_action_action_id	Added 0.47.0 - Drop foreign key constraint on implicit_action.action_id	\N	4.26.0	\N	\N	4525414792
v47.00-036	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.680629	141	EXECUTED	9:c45b0246a2068f7bed037662a25e52c0	addPrimaryKey constraintName=pk_implicit_action, tableName=implicit_action	Added 0.47.0 - Set primary key to action_id for implicit_action table	\N	4.26.0	\N	\N	4525414792
v47.00-037	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.686266	142	EXECUTED	9:8a7a6c51a3f52acb8b69bf10782e3a6e	addForeignKeyConstraint baseTableName=implicit_action, constraintName=fk_implicit_action_action_id, referencedTableName=action	Added 0.47.0 - Add foreign key constraint on implicit_action.action_id	\N	4.26.0	\N	\N	4525414792
v47.00-043	calherres	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.695568	143	EXECUTED	9:d7a6e633d99b064539cbc7563c7f1905	customChange	Added 0.47.0 - Migrate report_dashboardcard.visualization_settings.column_settings field refs from legacy format	\N	4.26.0	\N	\N	4525414792
v47.00-044	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.702901	144	EXECUTED	9:905e1385202b3626c9e67e4645b44375	customChange	Added 0.47.0 - Add join-alias to the report_dashboardcard.visualization_settings.column_settings field refs	\N	4.26.0	\N	\N	4525414792
v47.00-045	calherres	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.710976	145	EXECUTED	9:ad1660852fc3eacd2c35e164d3c97609	customChange	Added 0.47.0 - Migrate dashboard revision dashboard cards' visualization_settings.column_settings field refs from legacy format	\N	4.26.0	\N	\N	4525414792
v47.00-046	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.716427	146	EXECUTED	9:e0cd8b50dc855ce3362b562dc80afbb0	customChange	Added 0.47.0 - Add join-alias to dashboard revision dashboard cards' visualization_settings.column_settings field refs	\N	4.26.0	\N	\N	4525414792
v47.00-050	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.721573	147	EXECUTED	9:8e9aad6950c3b6f4799f51f0a7277457	addColumn tableName=metabase_table	Added 0.47.0 - table.is_upload	\N	4.26.0	\N	\N	4525414792
v47.00-051	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.727305	148	EXECUTED	9:ec914ed2458e64fdd021bc6ca19e85c1	dropForeignKeyConstraint baseTableName=connection_impersonations, constraintName=fk_conn_impersonation_db_id	Added 0.47.0 - Drop foreign key constraint on connection_impersonations.db_id	\N	4.26.0	\N	\N	4525414792
v47.00-052	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.732333	149	EXECUTED	9:9dc7bed69c542749be182f5d76233488	dropForeignKeyConstraint baseTableName=connection_impersonations, constraintName=fk_conn_impersonation_group_id	Added 0.47.0 - Drop foreign key constraint on connection_impersonations.group_id	\N	4.26.0	\N	\N	4525414792
v47.00-053	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.745822	150	EXECUTED	9:91a175d49e28b1653ac8a7bad2a8204f	createIndex indexName=idx_conn_impersonations_db_id, tableName=connection_impersonations	Added 0.47.0 -- connection_impersonations index for db_id column	\N	4.26.0	\N	\N	4525414792
v47.00-054	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.753028	151	EXECUTED	9:5245b1f06e5d1ae3a4c929f6cfcde9d4	createIndex indexName=idx_conn_impersonations_group_id, tableName=connection_impersonations	Added 0.47.0 -- connection_impersonations index for group_id column	\N	4.26.0	\N	\N	4525414792
v47.00-055	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.758789	152	EXECUTED	9:aef0d48122a09e653a9683d3b7074165	addUniqueConstraint constraintName=conn_impersonation_unique_group_id_db_id, tableName=connection_impersonations	Added 0.47.0 - unique constraint for connection impersonations	\N	4.26.0	\N	\N	4525414792
v47.00-056	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.767671	153	EXECUTED	9:bac4590e83ce8522e9fad8703aa88295	addForeignKeyConstraint baseTableName=connection_impersonations, constraintName=fk_conn_impersonation_db_id, referencedTableName=metabase_database	Added 0.47.0 - re-add foreign key constraint on connection_impersonations.db_id	\N	4.26.0	\N	\N	4525414792
v47.00-057	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.774894	154	EXECUTED	9:21e3b2ee3c1ae91f35c7c1fbd0f82dac	addForeignKeyConstraint baseTableName=connection_impersonations, constraintName=fk_conn_impersonation_group_id, referencedTableName=permissions_group	Added 0.47.0 - re-add foreign key constraint on connection_impersonations.group_id	\N	4.26.0	\N	\N	4525414792
v47.00-058	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.782332	155	EXECUTED	9:d268796eef28773e767c286904f50cee	dropColumn columnName=entity_id, tableName=parameter_card	Drop parameter_card.entity_id	\N	4.26.0	\N	\N	4525414792
v47.00-059	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.786974	156	EXECUTED	9:087e632c348027aeb01bc49bb428f67a	dropNotNullConstraint columnName=entity_id, tableName=dashboard_tab	Drops not null from dashboard_tab.entity_id since it breaks drop-entity-ids command	\N	4.26.0	\N	\N	4525414792
v48.00-001	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.798005	157	EXECUTED	9:2dd9aa417cd83b00a59b5eb1deb9ae55	customChange	Added 0.47.0 - Migrate database.options to database.settings	\N	4.26.0	\N	\N	4525414792
v48.00-002	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.803852	158	EXECUTED	9:7a9312346a8d041d62726cd99d27e02b	dropColumn columnName=options, tableName=metabase_database	Added 0.47.0 - drop metabase_database.options	\N	4.26.0	\N	\N	4525414792
v48.00-003	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.814659	159	EXECUTED	9:b623ee408e368c53ef1865af15a5edac	dropTable tableName=computation_job_result	Added 0.48.0 - drop computation_job_result table	\N	4.26.0	\N	\N	4525414792
v48.00-004	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.822323	160	EXECUTED	9:e9bdc7a7ca09fe29d5b3479d9925bbd7	dropTable tableName=computation_job	Added 0.48.0 - drop computation_job table	\N	4.26.0	\N	\N	4525414792
v48.00-005	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.828709	161	EXECUTED	9:46dbd09ead2298f0e37d28f011b8986e	addColumn tableName=query_execution	Added 0.48.0 - Add query_execution.action_id	\N	4.26.0	\N	\N	4525414792
v48.00-006	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.834915	162	EXECUTED	9:87cb5019893ddcb08ce06856825f1e6a	createIndex indexName=idx_query_execution_action_id, tableName=query_execution	Added 0.48.0 - Index query_execution.action_id	\N	4.26.0	\N	\N	4525414792
v48.00-007	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.841354	163	EXECUTED	9:efa5dcca04d3887bca0eafc95754b9ee	addColumn tableName=revision	Added 0.48.0 - Add revision.most_recent	\N	4.26.0	\N	\N	4525414792
v48.00-008	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.848437	164	EXECUTED	9:ad3f69be24960003ce545c16ac7922eb	sql; sql	Set revision.most_recent = true for latest revisions	\N	4.26.0	\N	\N	4525414792
v48.00-009	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.861798	165	EXECUTED	9:4243d81311d2dc265d687e4b665215dc	createTable tableName=table_privileges	Added 0.48.0 - Create table_privileges table	\N	4.26.0	\N	\N	4525414792
v48.00-010	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.864824	166	MARK_RAN	9:79908afdc739c3e9dbdddd1e29a20e5d	sql	Remove ON UPDATE for revision.timestamp on mysql, mariadb	\N	4.26.0	\N	\N	4525414792
v48.00-011	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.87237	167	EXECUTED	9:2da4950057f3a912cd044bd95a189087	createIndex indexName=idx_revision_most_recent, tableName=revision	Index revision.most_recent	\N	4.26.0	\N	\N	4525414792
v48.00-013	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.911177	168	EXECUTED	9:9478b5f507bc34df51aaa4d719fc1c37	sql	Index unindexed FKs for postgres	\N	4.26.0	\N	\N	4525414792
v48.00-014	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.918398	169	EXECUTED	9:f22e8ba6b47eaa27344835a6f5069c7f	createIndex indexName=idx_table_privileges_table_id, tableName=table_privileges	Added 0.48.0 - Create table_privileges.table_id index	\N	4.26.0	\N	\N	4525414792
v48.00-015	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.925181	170	EXECUTED	9:7ce7965ef94006d568d2298c4e5e007c	createIndex indexName=idx_table_privileges_role, tableName=table_privileges	Added 0.48.0 - Create table_privileges.role index	\N	4.26.0	\N	\N	4525414792
v48.00-016	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.930866	171	EXECUTED	9:99bac12bbd1ff64b35f0c48f5f9bf824	modifyDataType columnName=slug, tableName=collection	Added 0.48.0 - Change the type of collection.slug to varchar(510)	\N	4.26.0	\N	\N	4525414792
v48.00-018	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.939763	172	EXECUTED	9:7e190e044ea31c175d382aa6eb2b80c4	createTable tableName=recent_views	Add new recent_views table	\N	4.26.0	\N	\N	4525414792
v48.00-019	nemanjaglumac	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.944732	173	EXECUTED	9:3af8327e2dab1b5344292966c4e1d8e0	dropColumn columnName=color, tableName=collection	Collection color is removed in 0.48.0	\N	4.26.0	\N	\N	4525414792
v48.00-020	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.950737	174	EXECUTED	9:53aa607fc4b962053bffbca4e4283391	createIndex indexName=idx_recent_views_user_id, tableName=recent_views	Added 0.48.0 - Create recent_views.user_id index	\N	4.26.0	\N	\N	4525414792
v48.00-021	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.956747	175	EXECUTED	9:8fd8b97bfbae458ea7eb91e117cabc33	addColumn tableName=report_card	Cards store Metabase version used to create them	\N	4.26.0	\N	\N	4525414792
v48.00-022	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.965494	176	EXECUTED	9:0f826a4d0f9f512ca63fb667409ad999	customChange	Migrate migrate-click-through to a custom migration	\N	4.26.0	\N	\N	4525414792
v48.00-023	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:41.995666	177	EXECUTED	9:6ee76f86f68f7a2120cf8160cb34fd99	customChange	Data migration migrate-remove-admin-from-group-mapping-if-needed	\N	4.26.0	\N	\N	4525414792
v48.00-024	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.000514	178	EXECUTED	9:87ed320552869766323c1d12f7969b17	dropTable tableName=data_migrations	All data migrations were transferred to custom_migrations!	\N	4.26.0	\N	\N	4525414792
v48.00-025	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.005228	179	EXECUTED	9:0e54628ce18964128e827ad05ab2a448	addColumn tableName=revision	Revisions store Metabase version used to create them	\N	4.26.0	\N	\N	4525414792
v48.00-026	lbrdnk	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.009025	180	EXECUTED	9:d1ce706fe25d39767a77089171859856	update tableName=metabase_field	Set semantic_type with value type/Number to null (#18754)	\N	4.26.0	\N	\N	4525414792
v48.00-027	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.012701	181	EXECUTED	9:0a7ed49c904abc7110aa09324b49f106	sql	No op migration	\N	4.26.0	\N	\N	4525414792
v48.00-028	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.020653	182	EXECUTED	9:9340f3026bae444e9e98bc714a17a2d0	createTable tableName=audit_log	Add new audit_log table	\N	4.26.0	\N	\N	4525414792
v48.00-029	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.034481	183	EXECUTED	9:0ea006a4b23969abbb4574f1e7fc35c0	sqlFile path=instance_analytics_views/audit_log/v1/postgres-audit_log.sql; sqlFile path=instance_analytics_views/audit_log/v1/mysql-audit_log.sql; sqlFile path=instance_analytics_views/audit_log/v1/h2-audit_log.sql	Added 0.48.0 - new view v_audit_log	\N	4.26.0	\N	\N	4525414792
v48.00-060	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.245662	208	EXECUTED	9:97dc864df6ae5bca6e14ff4b1a455030	createIndex indexName=idx_task_history_started_at, tableName=task_history	Added 0.48.0 - task_history.started_at	\N	4.26.0	\N	\N	4525414792
v48.00-030	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.049259	184	EXECUTED	9:d59b20e1ab52d390d4bd9577b9a54439	sqlFile path=instance_analytics_views/content/v1/postgres-content.sql; sqlFile path=instance_analytics_views/content/v1/mysql-content.sql; sqlFile path=instance_analytics_views/content/v1/h2-content.sql	Added 0.48.0 - new view v_content	\N	4.26.0	\N	\N	4525414792
v48.00-031	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.058167	185	EXECUTED	9:4493c1a05ff71a8cf629c2e469e63b29	sqlFile path=instance_analytics_views/dashboardcard/v1/dashboardcard.sql	Added 0.48.0 - new view v_dashboardcard	\N	4.26.0	\N	\N	4525414792
v48.00-032	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.066562	186	EXECUTED	9:c73d37997ac7c32b730b761bd1a7ecc0	sqlFile path=instance_analytics_views/group_members/v1/group_members.sql	Added 0.48.0 - new view v_group_members	\N	4.26.0	\N	\N	4525414792
v48.00-033	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.078139	187	EXECUTED	9:5b0b30fbf86a695d93e04de3131294c4	sqlFile path=instance_analytics_views/subscriptions/v1/postgres-subscriptions.sql; sqlFile path=instance_analytics_views/subscriptions/v1/mysql-subscriptions.sql; sqlFile path=instance_analytics_views/subscriptions/v1/h2-subscriptions.sql	Added 0.48.0 - new view v_subscriptions for postgres	\N	4.26.0	\N	\N	4525414792
v48.00-034	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.086898	188	EXECUTED	9:0e64a610c2a763eb8366d8619b60b6fa	sqlFile path=instance_analytics_views/users/v1/postgres-users.sql; sqlFile path=instance_analytics_views/users/v1/mysql-users.sql; sqlFile path=instance_analytics_views/users/v1/h2-users.sql	Added 0.48.0 - new view v_users	\N	4.26.0	\N	\N	4525414792
v48.00-035	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.0999	189	EXECUTED	9:54569b1677c151e2fd052cef8c9d69cc	sqlFile path=instance_analytics_views/alerts/v1/postgres-alerts.sql; sqlFile path=instance_analytics_views/alerts/v1/mysql-alerts.sql; sqlFile path=instance_analytics_views/alerts/v1/h2-alerts.sql	Added 0.48.0 - new view v_alerts	\N	4.26.0	\N	\N	4525414792
v48.00-036	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.109911	190	EXECUTED	9:4a4b8b9d1d537618546664e041121858	sqlFile path=instance_analytics_views/databases/v1/databases.sql	Added 0.48.0 - new view v_databases	\N	4.26.0	\N	\N	4525414792
v48.00-037	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.118363	191	EXECUTED	9:a304624882c0f8bd2fd4241786376989	sqlFile path=instance_analytics_views/fields/v1/postgres-fields.sql; sqlFile path=instance_analytics_views/fields/v1/mysql-fields.sql; sqlFile path=instance_analytics_views/fields/v1/h2-fields.sql	Added 0.48.0 - new view v_fields	\N	4.26.0	\N	\N	4525414792
v48.00-038	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.12722	192	EXECUTED	9:a305f2ec4549f7d5afb8cd2318e87e4b	sqlFile path=instance_analytics_views/query_log/v1/postgres-query_log.sql; sqlFile path=instance_analytics_views/query_log/v1/mysql-query_log.sql; sqlFile path=instance_analytics_views/query_log/v1/h2-query_log.sql	Added 0.48.0 - new view v_query_log	\N	4.26.0	\N	\N	4525414792
v48.00-039	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.136122	193	EXECUTED	9:71d9d867d7798a728baf858802d6c255	sqlFile path=instance_analytics_views/tables/v1/postgres-tables.sql; sqlFile path=instance_analytics_views/tables/v1/mysql-tables.sql; sqlFile path=instance_analytics_views/tables/v1/h2-tables.sql	Added 0.48.0 - new view v_tables	\N	4.26.0	\N	\N	4525414792
v48.00-040	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.145173	194	EXECUTED	9:8e4eba04e03bb4edb326f7d4389e9dbb	sqlFile path=instance_analytics_views/view_log/v1/postgres-view_log.sql; sqlFile path=instance_analytics_views/view_log/v1/mysql-view_log.sql; sqlFile path=instance_analytics_views/view_log/v1/h2-view_log.sql	Added 0.48.0 - new view v_view_log	\N	4.26.0	\N	\N	4525414792
v48.00-045	qwef	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.15202	195	EXECUTED	9:3a8a23ac9c57ddb43351c8a0d57edbb7	addColumn tableName=query_execution	Added 0.48.0 - add is_sandboxed to query_execution	\N	4.26.0	\N	\N	4525414792
v48.00-046	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.168694	196	EXECUTED	9:6015a45ac465e5430f7482280427b182	sqlFile path=instance_analytics_views/indexes/v1/postgres-indexes.sql; sqlFile path=instance_analytics_views/indexes/v1/mysql-indexes.sql; sqlFile path=instance_analytics_views/indexes/v1/mariadb-indexes.sql; sqlFile path=instance_analytics_views/...	Added 0.48.0 - new indexes to optimize audit v2 queries	\N	4.26.0	\N	\N	4525414792
v48.00-047	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.175717	197	EXECUTED	9:83099e323661cb585639e5ee8d48d7bf	dropForeignKeyConstraint baseTableName=recent_views, constraintName=fk_recent_views_ref_user_id	Drop foreign key on recent_views so that it can be recreated with onDelete policy	\N	4.26.0	\N	\N	4525414792
v48.00-048	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.182337	198	EXECUTED	9:1ccb1544d732d0c6944ee1c4ac998801	addForeignKeyConstraint baseTableName=recent_views, constraintName=fk_recent_views_ref_user_id, referencedTableName=core_user	Add foreign key on recent_views with onDelete CASCADE	\N	4.26.0	\N	\N	4525414792
v48.00-049	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.187518	199	EXECUTED	9:0064304265cd53bb1965e6956bbe410e	sql; sql; sql	Migrate data from activity to audit_log	\N	4.26.0	\N	\N	4525414792
v48.00-050	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.19101	200	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty	Added 0.48.0 - no-op migration to remove audit DB and collection on downgrade	\N	4.26.0	\N	\N	4525414792
v48.00-051	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.197082	201	EXECUTED	9:ed306ef18d2546ccbe84f621fed21f1a	sql; sql	Migrate metabase_field when the fk target field is inactive	\N	4.26.0	\N	\N	4525414792
v48.00-053	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.204461	202	EXECUTED	9:7997563ebc2f57b53a1f19679d89b3b7	modifyDataType columnName=model, tableName=activity	Increase length of `activity.model` to fit longer model names	\N	4.26.0	\N	\N	4525414792
v48.00-054	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.208221	203	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	empty	Added 0.48.0 - no-op migration to remove Internal Metabase User on downgrade	\N	4.26.0	\N	\N	4525414792
v48.00-055	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.217152	204	EXECUTED	9:6c1a8ab293774009e006e0c629513fe5	sqlFile path=instance_analytics_views/tasks/v1/postgres-tasks.sql; sqlFile path=instance_analytics_views/tasks/v1/mysql-tasks.sql; sqlFile path=instance_analytics_views/tasks/v1/h2-tasks.sql	Added 0.48.0 - new view v_tasks	\N	4.26.0	\N	\N	4525414792
v48.00-056	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.224239	205	EXECUTED	9:cd66e7282ad1d92ae91d2694906f8762	addColumn tableName=view_log	Adjust view_log schema for Audit Log v2	\N	4.26.0	\N	\N	4525414792
v48.00-057	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.231729	206	EXECUTED	9:24967224f6153a884f8f588772dfaf7d	addColumn tableName=view_log	Adjust view_log schema for Audit Log v2	\N	4.26.0	\N	\N	4525414792
v48.00-059	qwef	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.237139	207	EXECUTED	9:aac112e35358d50dd099737f32e491bc	sql	Update the namespace of any audit collections that are already loaded	\N	4.26.0	\N	\N	4525414792
v48.00-061	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.251898	209	EXECUTED	9:5afa172dba1d6093b94356463912628b	addColumn tableName=query_execution	Adds query_execution.cache_hash -> query_cache.query_hash	\N	4.26.0	\N	\N	4525414792
v48.00-067	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.261073	210	EXECUTED	9:77853099d1da534596765591803a5d4c	addUniqueConstraint constraintName=idx_databasechangelog_id_author_filename, tableName=databasechangelog	Add unique constraint idx_databasechangelog_id_author_filename	\N	4.26.0	\N	\N	4525414792
v49.00-000	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.266011	211	EXECUTED	9:a6eaedb204bd70b999a7b7ed7524b904	sql	Remove leagcy pulses	\N	4.26.0	\N	\N	4525414792
v49.00-003	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.27341	212	EXECUTED	9:6c49190e041265b22255a447302236b8	addColumn tableName=core_user	Add a `type` to users	\N	4.26.0	\N	\N	4525414792
v49.00-004	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.287381	213	EXECUTED	9:d3d62eb2ff5b27040c5e4d1f5a263b4c	createTable tableName=api_key	Add a table for API keys	\N	4.26.0	\N	\N	4525414792
v49.00-005	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.294139	214	EXECUTED	9:790e75675265f53ca11f32994b9d1d12	createIndex indexName=idx_api_key_created_by, tableName=api_key	Add an index on `api_key.created_by`	\N	4.26.0	\N	\N	4525414792
v49.00-006	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.300085	215	EXECUTED	9:46cfb5a9bab696272d0211d7f34870ef	createIndex indexName=idx_api_key_user_id, tableName=api_key	Add an index on `api_key.user_id`	\N	4.26.0	\N	\N	4525414792
v49.00-007	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.304743	216	EXECUTED	9:638a7394870315abd52742b739ee49ff	sql	Set the `type` of the internal user	\N	4.26.0	\N	\N	4525414792
v49.00-008	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.313224	217	EXECUTED	9:381669dee234455e2d6e975afb9e95b0	addColumn tableName=metabase_field	Add metabase_field.database_indexed	\N	4.26.0	\N	\N	4525414792
v49.00-009	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.319373	218	EXECUTED	9:20b6791390f852c195f25bfcfb9a77a2	sql; sql	Migrate pulse_card.include_csv to 'true' when the joined card.display is 'table'	\N	4.26.0	\N	\N	4525414792
v49.00-010	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.328253	219	EXECUTED	9:c618fafea8561e66c97ac5d9a56106f3	addColumn tableName=api_key	Add a name to API Keys	\N	4.26.0	\N	\N	4525414792
v49.00-011	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.334892	220	EXECUTED	9:9dae0a3606d63cc6c47ec94f181d203c	addColumn tableName=metabase_table	Add metabase_table.database_require_filter	\N	4.26.0	\N	\N	4525414792
v49.00-012	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.341116	221	EXECUTED	9:129b215b73fec358adbd3cf9ba478515	addColumn tableName=metabase_field	Add metabase_field.database_partitioned	\N	4.26.0	\N	\N	4525414792
v49.00-013	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.348817	222	EXECUTED	9:fd99fac43bba1d45dfa8f17cd635e55b	addColumn tableName=api_key	Add `api_key.updated_by_id`	\N	4.26.0	\N	\N	4525414792
v49.00-014	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.354348	223	EXECUTED	9:ab6ff0fa8e1088222e01466c38295012	createIndex indexName=idx_api_key_updated_by_id, tableName=api_key	Add an index on `api_key.updated_by_id`	\N	4.26.0	\N	\N	4525414792
v49.00-015	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.359608	224	EXECUTED	9:85e3063c4b008044fe6729789af4d2d0	renameColumn newColumnName=creator_id, oldColumnName=created_by, tableName=api_key	Rename `created_by` to `creator_id`	\N	4.26.0	\N	\N	4525414792
v49.00-017	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.362439	225	MARK_RAN	9:add3e47d69b3c7c7a407a186bba06564	addNotNullConstraint columnName=archived, tableName=action	Add NOT NULL constraint to action.archived	\N	4.26.0	\N	\N	4525414792
v49.00-018	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.365431	226	MARK_RAN	9:dfa7799dd05f439f01c646f35810d37a	addDefaultValue columnName=archived, tableName=action	Add default value to action.archived	\N	4.26.0	\N	\N	4525414792
v49.00-020	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.369079	227	MARK_RAN	9:3ed2c593b8e803a416caa3f66c791c18	addNotNullConstraint columnName=json_unfolding, tableName=metabase_field	Add NOT NULL constraint to metabase_field.json_unfolding	\N	4.26.0	\N	\N	4525414792
v49.00-021	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.372129	228	MARK_RAN	9:eda3e041b4def2f0c9188b131330a743	addDefaultValue columnName=json_unfolding, tableName=metabase_field	Add default value to metabase_field.json_unfolding	\N	4.26.0	\N	\N	4525414792
v49.00-023	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.37582	229	MARK_RAN	9:8a8187fb01a8e5e2e23be4d64a068f54	addNotNullConstraint columnName=database_is_auto_increment, tableName=metabase_field	Add NOT NULL constraint to metabase_field.database_is_auto_increment	\N	4.26.0	\N	\N	4525414792
v49.00-024	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.379748	230	MARK_RAN	9:438a77b956692c7e3703d96b913e5566	addDefaultValue columnName=database_is_auto_increment, tableName=metabase_field	Add default value to metabase_field.database_is_auto_increment	\N	4.26.0	\N	\N	4525414792
v49.00-026	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.383565	231	MARK_RAN	9:7432b8bccc366fdeb6611b7899140ee7	addNotNullConstraint columnName=auto_apply_filters, tableName=report_dashboard	Add NOT NULL constraint to report_dashboard.auto_apply_filters	\N	4.26.0	\N	\N	4525414792
v49.00-027	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.387269	232	MARK_RAN	9:e8e27cec1e1cb5801ddfca828e3404a2	addDefaultValue columnName=auto_apply_filters, tableName=report_dashboard	Add default value to report_dashboard.auto_apply_filters	\N	4.26.0	\N	\N	4525414792
v49.00-029	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.391113	233	MARK_RAN	9:69f4b29b93422535b22df7ceb4c9dfb5	addNotNullConstraint columnName=is_audit, tableName=metabase_database	Add NOT NULL constraint to metabase_database.is_audit	\N	4.26.0	\N	\N	4525414792
v49.00-030	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.395654	234	MARK_RAN	9:93140751149cec3fdf7a186e6bac564a	addDefaultValue columnName=is_audit, tableName=metabase_database	Add default value to metabase_database.is_audit	\N	4.26.0	\N	\N	4525414792
v49.00-032	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.399256	235	MARK_RAN	9:bd9098a5361f7ab1aa631615e39e7eea	addNotNullConstraint columnName=is_upload, tableName=metabase_table	Add NOT NULL constraint to metabase_table.is_upload	\N	4.26.0	\N	\N	4525414792
v49.00-033	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.403153	236	MARK_RAN	9:75f535cee2ac99c5eabfd8d23007cec5	addDefaultValue columnName=is_upload, tableName=metabase_table	Add default value to metabase_table.is_upload	\N	4.26.0	\N	\N	4525414792
v49.00-036	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.406623	237	MARK_RAN	9:e2f3bc795300e8cba1ce4f594624eb98	addNotNullConstraint columnName=most_recent, tableName=revision	Add NOT NULL constraint to revision.most_recent	\N	4.26.0	\N	\N	4525414792
v49.00-037	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.410997	238	MARK_RAN	9:ddaf7704e565f42c3599823018f7f0cd	addDefaultValue columnName=most_recent, tableName=revision	Add default value to revision.most_recent	\N	4.26.0	\N	\N	4525414792
v49.00-039	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.414811	239	MARK_RAN	9:e085f675a04674caa7eefae9555faa98	addNotNullConstraint columnName=select, tableName=table_privileges	Add NOT NULL constraint to table_privileges.select	\N	4.26.0	\N	\N	4525414792
v49.00-040	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.41846	240	MARK_RAN	9:a429c76f53ca1f6e40cb97e10f5bbb13	addDefaultValue columnName=select, tableName=table_privileges	Add default value to table_privileges.select	\N	4.26.0	\N	\N	4525414792
v49.00-042	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.421502	241	MARK_RAN	9:a2a53332a9e16f2510537f27694f177f	addNotNullConstraint columnName=update, tableName=table_privileges	Add NOT NULL constraint to table_privileges.update	\N	4.26.0	\N	\N	4525414792
v49.00-043	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.425262	242	MARK_RAN	9:1a18955a2d01bb8fb1b7edfc74f5d976	addDefaultValue columnName=update, tableName=table_privileges	Add default value to table_privileges.update	\N	4.26.0	\N	\N	4525414792
v49.00-045	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.430307	243	MARK_RAN	9:9ecb48a04626476919f49615614a1166	addNotNullConstraint columnName=insert, tableName=table_privileges	Add NOT NULL constraint to table_privileges.insert	\N	4.26.0	\N	\N	4525414792
v49.00-046	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.434034	244	MARK_RAN	9:32c3a206904e45e4d6b3d639a2477d4e	addDefaultValue columnName=insert, tableName=table_privileges	Add default value to table_privileges.insert	\N	4.26.0	\N	\N	4525414792
v49.00-048	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.437809	245	MARK_RAN	9:8f313a8ba8b16a19466d75d93df683f2	addNotNullConstraint columnName=delete, tableName=table_privileges	Add NOT NULL constraint to table_privileges.delete	\N	4.26.0	\N	\N	4525414792
v49.00-049	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.441296	246	MARK_RAN	9:fa6e7cafdbbf7880ddd8eef9b1cd33c9	addDefaultValue columnName=delete, tableName=table_privileges	Add default value to table_privileges.delete	\N	4.26.0	\N	\N	4525414792
v49.00-059	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.482059	247	EXECUTED	9:4046506923db48fd7a7c11021b58a4b5	customChange	Added 0.49.0 - unify type of time columns	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:01	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.668133	273	EXECUTED	9:d6304a91e487a31da1203b115487d740	addColumn tableName=metabase_field	Add metabase_field.is_defective_duplicate	\N	4.26.0	\N	\N	4525414792
v49.2023-01-24T12:00:00	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.489684	248	EXECUTED	9:6f381d427bef9022f3ac00618af2112b	createIndex indexName=idx_field_name_lower, tableName=metabase_field	This significantly speeds up api.database/autocomplete-fields query and is an improvement for issue 30588. H2 does not support this: https://github.com/h2database/h2database/issues/3535 Mariadb does not support this. Mysql says it does, but report...	\N	4.26.0	\N	\N	4525414792
v49.2024-01-22T11:50:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.498005	249	EXECUTED	9:643a028e650ad7fcd6789a702249a179	addColumn tableName=report_card	Add `report_card.type`	\N	4.26.0	\N	\N	4525414792
v49.2024-01-22T11:51:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.50463	250	EXECUTED	9:6e53593c40c63e38d6c1ffd0331753c5	sql	Backfill `report_card.type`	\N	4.26.0	\N	\N	4525414792
v49.2024-01-22T11:52:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.513086	251	EXECUTED	9:7d260ed302016469ea5950bba09cb471	customChange	Backfill `report_card.type`	\N	4.26.0	\N	\N	4525414792
v49.2024-01-29T19:26:40	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.520671	252	EXECUTED	9:04671d8b09ff919ab5154604377ba247	addColumn tableName=report_dashboard	Add width setting to Dashboards	\N	4.26.0	\N	\N	4525414792
v49.2024-01-29T19:30:00	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.527265	253	EXECUTED	9:856b864c837cd25b3de595691f2b5712	update tableName=report_dashboard	Update existing report_dashboard width values to full	\N	4.26.0	\N	\N	4525414792
v49.2024-01-29T19:56:40	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.535071	254	EXECUTED	9:c092ab859ee6994fcd3b4719872abb97	addNotNullConstraint columnName=width, tableName=report_dashboard	Dashboard width setting must have a value	\N	4.26.0	\N	\N	4525414792
v49.2024-01-29T19:59:12	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.537745	255	MARK_RAN	9:663770b688f1ec9aee90d067d789ddbe	addDefaultValue columnName=width, tableName=report_dashboard	Add default value to report_dashboard.width for mysql and mariadb	\N	4.26.0	\N	\N	4525414792
v49.2024-02-02T11:27:49	oisincoveney	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.548086	256	EXECUTED	9:b98d0471c408e0c13d3e6760275a7252	addColumn tableName=report_card	Add report_card.initially_published_at	\N	4.26.0	\N	\N	4525414792
v49.2024-02-02T11:28:36	oisincoveney	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.556176	257	EXECUTED	9:749dba47625d9fdb89d366e3c43dc510	addColumn tableName=report_dashboard	Add report_dashboard.initially_published_at	\N	4.26.0	\N	\N	4525414792
v49.2024-02-07T21:52:01	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.565871	258	EXECUTED	9:147145d4f57327ceeddf6c0e64605488	sqlFile path=instance_analytics_views/view_log/v2/postgres-view_log.sql; sqlFile path=instance_analytics_views/view_log/v2/mysql-view_log.sql; sqlFile path=instance_analytics_views/view_log/v2/h2-view_log.sql	Added 0.49.0 - updated view v_view_log	\N	4.26.0	\N	\N	4525414792
v49.2024-02-07T21:52:02	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.574004	259	EXECUTED	9:ad858cd4bea316258d9a3894f2ef27d3	sqlFile path=instance_analytics_views/audit_log/v2/postgres-audit_log.sql; sqlFile path=instance_analytics_views/audit_log/v2/mysql-audit_log.sql; sqlFile path=instance_analytics_views/audit_log/v2/h2-audit_log.sql	Added 0.49.0 - updated view v_audit_log	\N	4.26.0	\N	\N	4525414792
v49.2024-02-07T21:52:03	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.581939	260	EXECUTED	9:9072a2d1352e44778ba6ecda18ba2177	sqlFile path=instance_analytics_views/group_members/v2/group_members.sql	Added 0.49.0 - updated view v_group_members	\N	4.26.0	\N	\N	4525414792
v49.2024-02-07T21:52:04	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.588471	261	EXECUTED	9:f89937596b5e1dc112bdd6f142dbce78	sqlFile path=instance_analytics_views/query_log/v2/postgres-query_log.sql; sqlFile path=instance_analytics_views/query_log/v2/mysql-query_log.sql; sqlFile path=instance_analytics_views/query_log/v2/h2-query_log.sql	Added 0.49.0 - updated view v_query_log	\N	4.26.0	\N	\N	4525414792
v49.2024-02-07T21:52:05	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.597542	262	EXECUTED	9:55199a2ff1141c96910ba3e171da5d34	sqlFile path=instance_analytics_views/users/v2/postgres-users.sql; sqlFile path=instance_analytics_views/users/v2/mysql-users.sql; sqlFile path=instance_analytics_views/users/v2/h2-users.sql	Added 0.49.0 - updated view v_users	\N	4.26.0	\N	\N	4525414792
v49.2024-02-09T13:55:26	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.600462	263	MARK_RAN	9:d6f29528c18573873a35c84be228238a	sql; sql; sql	Set default value for enable-public-sharing to `false` for existing instances with users, if not already set	\N	4.26.0	\N	\N	4525414792
v49.2024-03-26T10:23:12	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.60653	264	EXECUTED	9:32218014a4cff780ad4c8e042fc98f23	addColumn tableName=pulse_card	Add pulse_card.format_rows	\N	4.26.0	\N	\N	4525414792
v49.2024-04-09T10:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.612347	265	EXECUTED	9:0584ae323d98a60f80b433bedab2a0a2	dropNotNullConstraint columnName=cache_field_values_schedule, tableName=metabase_database	Drop not null constraint on metabase_database.cache_field_values_schedule	\N	4.26.0	\N	\N	4525414792
v49.2024-04-09T10:00:01	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.616693	266	EXECUTED	9:68341c448ecdca425eae019974b64c09	dropDefaultValue columnName=cache_field_values_schedule, tableName=metabase_database	Drop default value on metabase_database.cache_field_values_schedule	\N	4.26.0	\N	\N	4525414792
v49.2024-04-09T10:00:02	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.621454	267	EXECUTED	9:adb15f2d80ea2b037b44d1eb2dbcb3c5	addDefaultValue columnName=cache_field_values_schedule, tableName=metabase_database	Add null as default value for metabase_database.cache_field_values_schedule	\N	4.26.0	\N	\N	4525414792
v49.2024-04-09T10:00:03	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.647644	268	EXECUTED	9:fb84fa8ea82ea520edae45164aa167d9	customChange	This clears the schedule for caching field values for databases with period scanning disabled.	\N	4.26.0	\N	\N	4525414792
v49.2024-05-07T10:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.650133	269	MARK_RAN	9:d41d8cd98f00b204e9800998ecf8427e	sql	Set revision.most_recent = true to latest revision and false to others. A redo of v48.00-008 for mysql	\N	4.26.0	\N	\N	4525414792
v49.2024-05-20T20:37:55	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.653541	270	MARK_RAN	9:99f4a155e5f4eb4debf6af01cdf68b8e	addNotNullConstraint columnName=collection_preview, tableName=report_card	Add NOT NULL constraint to report_card.collection_preview	\N	4.26.0	\N	\N	4525414792
v49.2024-05-20T20:38:34	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.657818	271	MARK_RAN	9:4915c63aed5f55151a7fe470a040862f	addDefaultValue columnName=collection_preview, tableName=report_card	Add default value to report_card.collection_preview	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:00	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.661885	272	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	sql	Make metabase_field.name use case-sensitive collation for MySQL	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:02	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.673291	274	EXECUTED	9:9d3b1c2007b08d7402efe98271fbcaef	sql	Populate metabase_field.is_defective_duplicate	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:03	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.679791	275	EXECUTED	9:d166164210dfba735d35cf1cf6a71d85	dropForeignKeyConstraint baseTableName=metabase_field, constraintName=fk_field_parent_ref_field_id	Drop fk_field_parent_ref_field_id constraint with ON DELETE CASCADE	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:04	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:42.684759	276	EXECUTED	9:56cfef6f3dddd565bd73be1070aa3921	addForeignKeyConstraint baseTableName=metabase_field, constraintName=fk_field_parent_ref_field_id, referencedTableName=metabase_field	Add fk_field_parent_ref_field_id constraint with ON DELETE RESTRICT	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:05	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.26998	277	EXECUTED	9:cee4715af87ae02cb79994fc3a7ad40c	dropUniqueConstraint constraintName=idx_uniq_field_table_id_parent_id_name, tableName=metabase_field	Remove idx_uniq_field_table_id_parent_id_name because it is redundant with idx_unique_field	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:06	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.274918	278	EXECUTED	9:54c39fde929354f0989f34cc990ba949	sql	Remove the idx_uniq_field_table_id_parent_id_name_2col unique index because it blocks load-from-h2	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:07	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.283767	279	EXECUTED	9:5f40eed249599100ec3b9f3ec5d9bc4e	sql; sql; sql	Add unique_field_helper column to metabase_field	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:08	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.293188	280	EXECUTED	9:0efceff63ef2b44d93a3fcfb711eb98c	addUniqueConstraint constraintName=idx_unique_field, tableName=metabase_field	Add unique constraint on metabase_field's (name, table_id, unique_field_helper)	\N	4.26.0	\N	\N	4525414792
v49.2024-06-27T00:00:09	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.297651	281	EXECUTED	9:d66ae3a729bdd398b10aa7be445cadd9	sql	Set is_defective_duplicate=TRUE fields that shouldn't exist to have active=FALSE	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:06	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.305357	282	EXECUTED	9:35745c7f87264b09ec446c0d4f3dd46a	addColumn tableName=permissions	Add permissions.perm_value	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:07	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.31364	283	EXECUTED	9:1e7b54f510eee51883629cfe9e760797	addColumn tableName=permissions	Add permissions.perm_type	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:08	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:43.320811	284	EXECUTED	9:53e92d719e8b8fc966f44c363fe27824	addColumn tableName=permissions	Add permissions.collection_id	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:09	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.535772	285	EXECUTED	9:a4c48a8ffd78b6da4bbb04ab5c851164	addForeignKeyConstraint baseTableName=permissions, constraintName=fk_permissions_ref_collection_id, referencedTableName=collection	Add `permissions.collection_id` foreign key constraint	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:10	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.54699	286	EXECUTED	9:f96705cfe0ae98ac06823f273fa4c92d	sqlFile path=permissions/collection-access.sql; sqlFile path=permissions/collection-access-mariadb.sql; sqlFile path=permissions/collection-access-h2.sql	Populate `perm_value`, `perm_type`, and `collection_id` on permissions	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:11	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.558929	287	EXECUTED	9:1e2373045bcce712290f2dcf59401058	createIndex indexName=idx_permissions_collection_id, tableName=permissions	Create index on `permissions.collection_id`	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:12	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.571006	288	EXECUTED	9:5c4358566479a8281ba0b85f4469e748	createIndex indexName=idx_permissions_perm_type, tableName=permissions	Index on `permissions.perm_type`	\N	4.26.0	\N	\N	4525414792
v49.2024-08-21T08:33:13	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.581425	289	EXECUTED	9:19a96d64a8a5018e8de14f4bc7cc9484	createIndex indexName=idx_permissions_perm_value, tableName=permissions	Index on `permissions.perm_value`	\N	4.26.0	\N	\N	4525414792
v50.2024-01-09T13:52:21	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.596679	291	EXECUTED	9:3c438c9a400361ed3dedc2818c7ed4b8	createIndex indexName=idx_data_permissions_table_id, tableName=data_permissions	Index on data_permissions.table_id	\N	4.26.0	\N	\N	4525414792
v50.2024-01-09T13:53:50	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.601057	292	EXECUTED	9:21ad67aa43df73593d4e86492afdfb4e	createIndex indexName=idx_data_permissions_db_id, tableName=data_permissions	Index on data_permissions.db_id	\N	4.26.0	\N	\N	4525414792
v50.2024-01-09T13:53:54	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.606395	293	EXECUTED	9:34a2e61c8298c84b18f7a7c7bf5d2119	createIndex indexName=idx_data_permissions_group_id, tableName=data_permissions	Index on data_permissions.group_id	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:20	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.610844	294	EXECUTED	9:909c89fbd147bf973aedb3e2750d536c	sql; sql	Analyze permissions table in preparation for subsequent migrations	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:29	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.61541	295	EXECUTED	9:a8c8b1c823344ea148826e9772c2b9b7	dropForeignKeyConstraint baseTableName=sandboxes, constraintName=fk_sandboxes_ref_permissions	Drop foreign key constraint on sandboxes.permissions_id	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:30	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.628561	296	EXECUTED	9:1c99fe56b1020ed7001194f0cd2210a0	sqlFile path=permissions/data_access.sql; sqlFile path=permissions/h2_data_access.sql; sqlFile path=permissions/mysql_data_access.sql	Migrate data-access permissions from `permissions` to `data_permissions`	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:31	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.637744	297	EXECUTED	9:4ea632c5ef082ebf005d923bd5527be3	sqlFile path=permissions/native_query_editing.sql	Migrate native-query-editing permissions from `permissions` to `data_permissions`	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:32	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.656494	298	EXECUTED	9:4a5f46105cb916d1c0da003000fc89d5	sqlFile path=permissions/download_results.sql; sqlFile path=permissions/h2_download_results.sql; sqlFile path=permissions/mysql_download_results.sql	Migrate download-results permissions from `permissions` to `data_permissions`	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T01:04:07	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.026446	327	EXECUTED	9:8380c81746dd65909faceeef3461133e	customChange	Delete InitSendPulseTriggers Job on downgrade	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:33	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.672802	299	EXECUTED	9:89063d2b2f45375a598fed11a810cd16	sqlFile path=permissions/manage_table_metadata.sql; sqlFile path=permissions/h2_manage_table_metadata.sql; sqlFile path=permissions/mysql_manage_table_metadata.sql	Migrate manage-data-metadata permissions from `permissions` to `data_permissions`	\N	4.26.0	\N	\N	4525414792
v50.2024-01-10T03:27:34	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.681928	300	EXECUTED	9:9c37edf4ba12133ce298fb806af1a9cb	sqlFile path=permissions/manage_database.sql	Migrate manage-database permissions from `permissions` to `data_permissions`	\N	4.26.0	\N	\N	4525414792
v50.2024-02-19T21:32:04	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.686814	301	EXECUTED	9:2a02ffb8f60532c88e645d2cd9053d95	sql	Clear data permission paths	\N	4.26.0	\N	\N	4525414792
v50.2024-02-20T19:21:04	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.693563	302	EXECUTED	9:32e06eedee74b10b4f03aa0c64e5f19c	sql	Drop v1 version of v_content view since it references report_card.dataset which we are dropping in next migration	\N	4.26.0	\N	\N	4525414792
v50.2024-02-20T19:25:40	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.699403	303	EXECUTED	9:1a0d14160b0a4e346ffe38d0e1009b7e	dropColumn columnName=dataset, tableName=report_card	Remove report_card.dataset (indicated whether Card was a Model; migrated to report_card.type in 49)	\N	4.26.0	\N	\N	4525414792
v50.2024-02-20T19:26:38	camsaul	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.713695	304	EXECUTED	9:ba2590be4f62444dd99d688ffff286ba	sqlFile path=instance_analytics_views/content/v2/postgres-content.sql; sqlFile path=instance_analytics_views/content/v2/mysql-content.sql; sqlFile path=instance_analytics_views/content/v2/h2-content.sql	Add new v2 version of v_content view which uses report_card.type instead of report_card.dataset (removed in previous migration)	\N	4.26.0	\N	\N	4525414792
v50.2024-02-26T22:15:52	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.726544	305	EXECUTED	9:0dd3ee7f997da7aade6eb65457498940	createIndex indexName=idx_data_permissions_group_id_db_id_perm_value, tableName=data_permissions	Add index on data_permissions(group_id, db_id, perm_value)	\N	4.26.0	\N	\N	4525414792
v50.2024-02-26T22:15:53	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.737034	306	EXECUTED	9:7889e4fa3befded2340d040eebbf664e	createIndex indexName=idx_data_permissions_group_id_db_id_table_id_perm_value, tableName=data_permissions	Add index on data_permissions(group_id, db_id, table_id, perm_value)	\N	4.26.0	\N	\N	4525414792
v50.2024-02-26T22:15:54	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.798861	307	EXECUTED	9:a5a873a455454c920ad8604606198bad	sqlFile path=permissions/view_data.sql; sqlFile path=permissions/mysql_view_data.sql	New `view-data` permission	\N	4.26.0	\N	\N	4525414792
v50.2024-02-26T22:15:55	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.808876	308	EXECUTED	9:b1f5769daebdad03a65681cc8c1d0475	sqlFile path=permissions/create_queries.sql	New `create_queries` permission	\N	4.26.0	\N	\N	4525414792
v50.2024-02-29T15:06:43	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.816941	309	EXECUTED	9:bf61f630cb8d21a16ef6566d842a8b46	createTable tableName=query_field	Add the query_field join table	\N	4.26.0	\N	\N	4525414792
v50.2024-02-29T15:07:43	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.8234	310	EXECUTED	9:0abc329e07ca6746b3e3da79a1bb4fdb	createIndex indexName=idx_query_field_card_id, tableName=query_field	Index query_field.card_id	\N	4.26.0	\N	\N	4525414792
v50.2024-02-29T15:08:43	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.829211	311	EXECUTED	9:27ce36c055a2b252a6c6e52d5f5f1d76	createIndex indexName=idx_query_field_field_id, tableName=query_field	Index query_field.field_id	\N	4.26.0	\N	\N	4525414792
v50.2024-03-12T17:16:38	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.835671	312	EXECUTED	9:ee42f814c124ba84636b9b5fd1c34bdf	dropTable tableName=activity	Drops the `activity` table which is now unused	\N	4.26.0	\N	\N	4525414792
v50.2024-03-18T16:00:00	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.845813	313	EXECUTED	9:f0cd082514b5a1ffdc432034df0d837e	createTable tableName=cache_config	Effective caching #36847	\N	4.26.0	\N	\N	4525414792
v50.2024-03-18T16:00:01	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.851252	314	EXECUTED	9:5007337d4de322587ce6056e0b9eac9b	addUniqueConstraint constraintName=idx_cache_config_unique_model, tableName=cache_config	Effective caching #36847	\N	4.26.0	\N	\N	4525414792
v50.2024-03-21T17:41:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.856849	315	EXECUTED	9:ecace972ee38bae5dd02e23ff91e2794	addColumn tableName=metabase_table	Add metabase_table.estimated_row_count	\N	4.26.0	\N	\N	4525414792
v50.2024-03-22T00:39:28	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.880297	317	EXECUTED	9:c94534b092f89579385156f18faee569	createIndex indexName=idx_field_usage_field_id, tableName=field_usage	Index field_usage.field_id	\N	4.26.0	\N	\N	4525414792
v50.2024-03-24T19:34:11	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.886057	318	EXECUTED	9:ceac2712d4c61fbbafa21b905ee7cf35	sql	Clean up deprecated view-data and native-query-editing permissions	\N	4.26.0	\N	\N	4525414792
v50.2024-03-25T14:53:00	tsmacdonald	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.893989	319	EXECUTED	9:86d60ff7f9ab572c53887c13e96e4315	addColumn tableName=query_field	Add query_field.direct_reference	\N	4.26.0	\N	\N	4525414792
v50.2024-03-28T16:30:35	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.974045	320	EXECUTED	9:db68375fac0a9fe40f0caf475dd1fd92	customChange	Create internal user	\N	4.26.0	\N	\N	4525414792
v50.2024-03-29T10:00:00	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.98036	321	EXECUTED	9:5b64f09469c0d093e147cc93dbaa94e5	addColumn tableName=report_card	Granular cache invalidation	\N	4.26.0	\N	\N	4525414792
v50.2024-04-09T15:55:19	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.986081	322	EXECUTED	9:3af4d0d7b06784b822eed6b5b7c525f3	addColumn tableName=collection	Add collection.is_sample column	\N	4.26.0	\N	\N	4525414792
v50.2024-04-15T16:30:35	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.990934	323	EXECUTED	9:7f083cce96c96c2b5d9b21cc6ad91ef8	addColumn tableName=report_card	Add report_card.last_used_at	\N	4.26.0	\N	\N	4525414792
v50.2024-04-19T17:04:04	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:48.994808	324	EXECUTED	9:ceac2712d4c61fbbafa21b905ee7cf35	sql	Clean up deprecated view-data and native-query-editing permissions (again)	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T01:04:05	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.017485	325	EXECUTED	9:61c4fc54c2c8ab0ea6b072ec1409fa48	customChange	Delete the old SendPulses job and trigger	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T01:04:06	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.021931	326	EXECUTED	9:ca85ee4382798cec047044ab394061c0	customChange	Delete SendPulse Job on downgrade	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T03:15:01	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.033759	328	EXECUTED	9:669daa77b4a7c048fbb8bfb4fee54df0	addColumn tableName=core_user	Add entity_id to core_user	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T03:15:02	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.03917	329	EXECUTED	9:477fd6e94e5b5bcd818b811928af19ff	addColumn tableName=permissions_group	Add entity_id to permissions_group	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T16:29:31	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.044069	330	EXECUTED	9:8241c6c3caca2f4eeccfdd157063da58	addColumn tableName=report_card	Add report_card.view_count	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T16:29:32	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.048498	331	EXECUTED	9:807983e5cff6386bb21e3cd2197c076d	sql; sql	Populate report_card.view_count	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T16:29:33	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.054812	332	EXECUTED	9:c443c22fa32cc1e0dbee3669ef0398ee	addColumn tableName=report_dashboard	Add report_dashboard.view_count	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T16:29:34	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.060195	333	EXECUTED	9:a0eef6561d9759a96d72b22c16b29f1e	sql; sql	Populate report_dashboard.view_count	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T16:29:35	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.067145	334	EXECUTED	9:5873cdd28eb07ce7ea60ab44e9646338	addColumn tableName=metabase_table	Add metabase_table.view_count	\N	4.26.0	\N	\N	4525414792
v50.2024-04-25T16:29:36	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.071549	335	EXECUTED	9:b55ed9c3e59124df25d78d191c165508	sql; sql	Populate metabase_table.view_count	\N	4.26.0	\N	\N	4525414792
v50.2024-04-26T09:19:00	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.082129	336	EXECUTED	9:713beca44f427ff4832de85b1e88320b	createTable tableName=user_parameter_value	Added 0.50.0 - Per-user Dashboard Parameter values table	\N	4.26.0	\N	\N	4525414792
v50.2024-04-26T09:25:00	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.08928	337	EXECUTED	9:2af6f33e022984b2abd41fb0a6820b92	createIndex indexName=idx_user_parameter_value_user_id, tableName=user_parameter_value	Index user_parameter_value.user_id	\N	4.26.0	\N	\N	4525414792
v50.2024-04-30T23:57:23	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.097339	338	EXECUTED	9:19d659847dc567d1abd78734b8672ea9	addColumn tableName=api_key	Add `scope` column to api_key to support SCIM authentication	\N	4.26.0	\N	\N	4525414792
v50.2024-04-30T23:58:24	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.158131	339	EXECUTED	9:a6914c25365739b16b573067fae3a383	dropNotNullConstraint columnName=user_id, tableName=api_key	Drop NOT NULL constraint on api_key.user_id to support SCIM-scoped API keys	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.167073	340	EXECUTED	9:e28d26db534e046b411c8fe176c1c0e0	addColumn tableName=task_history	Add task_history.status	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:01	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.174131	341	EXECUTED	9:c8df0ec666d8c736f83bdb85e446fed1	dropDefaultValue columnName=status, tableName=task_history	Drop default value task_history.status	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:02	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.179781	342	EXECUTED	9:c9cd34125a3c9445f4d7076527b95589	addDefaultValue columnName=status, tableName=task_history	Add "started" as default value for task_history.status, now that backfill is done.	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:03	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.185645	343	EXECUTED	9:9a753f9d1a43011f20be4eff7634cd33	dropNotNullConstraint columnName=ended_at, tableName=task_history	Drop not null constraint for task_history.ended_at	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:04	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.19113	344	EXECUTED	9:20c322e8ee6d62c43ae49d8891f81f89	dropNotNullConstraint columnName=duration, tableName=task_history	Drop not null constraint for task_history.duration	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:05	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.197447	345	EXECUTED	9:b02406ab39b905df65acccf4bdc82ee1	dropDefaultValue columnName=ended_at, tableName=task_history	Drop default value task_history.ended_at	\N	4.26.0	\N	\N	4525414792
v50.2024-05-08T09:00:06	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.201979	346	EXECUTED	9:7ab667ce198a98ccb03ec77b2f1b3655	addDefaultValue columnName=ended_at, tableName=task_history	Add null as default value for task_history.ended_at	\N	4.26.0	\N	\N	4525414792
v50.2024-05-13T16:00:00	filipesilva	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.213153	347	EXECUTED	9:5a355ae0134f6b643ff3b5d4814a15f2	createTable tableName=cloud_migration	Create cloud migration	\N	4.26.0	\N	\N	4525414792
v50.2024-05-15T13:13:13	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.229233	349	EXECUTED	9:a7f15cd934779ad0d52c634c3fdca04f	customChange	Fix visualization settings for stacked area/bar/combo displays	\N	4.26.0	\N	\N	4525414792
v50.2024-05-17T19:54:23	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.235784	350	EXECUTED	9:a3525795c74bd10591b66a2b9138aec3	addColumn tableName=metabase_database	Add metabase_database.uploads_enabled column	\N	4.26.0	\N	\N	4525414792
v50.2024-05-17T19:54:24	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.241273	351	EXECUTED	9:76516d4fd0f8a99a1232d999e5f834a8	addColumn tableName=metabase_database	Add metabase_database.uploads_schema_name column	\N	4.26.0	\N	\N	4525414792
v50.2024-05-17T19:54:25	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.246671	352	EXECUTED	9:9df4d358f294a0541342ceeb9a43c12a	addColumn tableName=metabase_database	Add metabase_database.uploads_table_prefix column	\N	4.26.0	\N	\N	4525414792
v50.2024-05-17T19:54:26	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.254008	353	EXECUTED	9:2ba2a860ad40c70381cddf179a766d08	customChange	Update metabase_database.uploads_enabled value	\N	4.26.0	\N	\N	4525414792
v50.2024-05-27T15:55:22	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.257493	354	EXECUTED	9:47cab1070db15a6d225dcf467747120a	customChange	Create sample content	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T14:04:47	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.263262	355	EXECUTED	9:b1e8cecfb1cc4910386b923fa0d378c1	addColumn tableName=report_dashboard	Add `report_dashboard.archived_directly`	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T14:04:53	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.268184	356	EXECUTED	9:b624046cf124d2d2e938f01a01a638f6	addColumn tableName=report_card	Add `report_card.archived_directly`	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T14:04:58	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.27489	357	EXECUTED	9:cf08bbe2e766f4c5cb1ed3f4ece92691	addColumn tableName=collection	Add `collection.archive_operation_id`	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T14:05:01	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.28143	358	EXECUTED	9:1f8007b4d172a264f0aa54338f7e9ea1	addColumn tableName=collection	Add `collection.archived_directly`	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T14:05:03	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.29101	359	EXECUTED	9:6ec466eb8f51c144100c6d09c15ce78b	sqlFile path=trash/postgres.sql	Populate `archived_directly` and `archive_operation_id` (Postgres)	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T18:42:13	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.294242	360	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	sqlFile path=trash/h2.sql	Populate `archived_directly` and `archive_operation_id` (H2)	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T18:42:14	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.29691	361	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	sqlFile path=trash/mysql.sql	Populate `archived_directly` and `archive_operation_id` (MySQL)	\N	4.26.0	\N	\N	4525414792
v50.2024-05-29T18:42:15	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.299237	362	EXECUTED	9:d41d8cd98f00b204e9800998ecf8427e	sqlFile path=trash/mariadb.sql	Populate `archived_directly` and `archive_operation_id` (MariaDB)	\N	4.26.0	\N	\N	4525414792
v50.2024-05-30T16:04:20	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.305224	363	EXECUTED	9:fffd69cbe22b3b1188733113096c8587	addColumn tableName=recent_views	Add context to recent views table	\N	4.26.0	\N	\N	4525414792
v50.2024-06-12T12:33:07	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.326202	364	EXECUTED	9:6d76b0bddae5c21628ed0e2c3600e5ce	customChange	Decrypt some settings so the next migration runs well	\N	4.26.0	\N	\N	4525414792
v50.2024-06-12T12:33:08	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.335482	365	EXECUTED	9:79f015a062530713a478c385e9e99f71	sqlFile path=custom_sql/fill_cache_config.pg.sql; sqlFile path=custom_sql/fill_cache_config.my.sql; sqlFile path=custom_sql/fill_cache_config.h2.sql	Copy old cache configurations to cache_config table	\N	4.26.0	\N	\N	4525414792
v50.2024-06-20T13:21:30	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.340912	366	EXECUTED	9:701f958ad945cb61470a790b6ad9481e	dropColumn columnName=permission_id, tableName=sandboxes	Drop permission_id column on sandboxes table to fix down migrations	\N	4.26.0	\N	\N	4525414792
v50.2024-06-28T12:35:50	piranha	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.345327	367	EXECUTED	9:6e2b3f793dbc79f13d45321c37e37d29	sql	Clean databasechangelog table of migration that was once deleted	\N	4.26.0	\N	\N	4525414792
v50.2024-07-02T16:48:21	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.350455	368	EXECUTED	9:28ce5b6d202041ef717ac5947bc4fb35	delete tableName=user_parameter_value	Remove existing user_parameter_value entries as we want to add dashboard_id, and can't easily backfill	\N	4.26.0	\N	\N	4525414792
v50.2024-07-02T16:49:29	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.356599	369	EXECUTED	9:cc1bfd2b0ce61840000e0e0bad08611b	addColumn tableName=user_parameter_value	Add dashboard_id column to user_parameter_value to keep values unique per dashboard	\N	4.26.0	\N	\N	4525414792
v50.2024-07-02T16:55:42	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.363321	370	EXECUTED	9:6238ea514bbc0857c6b48275c43d5247	addForeignKeyConstraint baseTableName=user_parameter_value, constraintName=fk_user_parameter_value_dashboard_id, referencedTableName=report_dashboard	Add fk constraint to user_parameter_value.dashboard_id	\N	4.26.0	\N	\N	4525414792
v50.2024-07-02T17:07:15	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.369139	371	EXECUTED	9:c38bc08b0a03785a33f0276843295750	createIndex indexName=idx_user_parameter_value_dashboard_id, tableName=user_parameter_value	Index user_parameter_value.dashboard_id	\N	4.26.0	\N	\N	4525414792
v50.2024-07-09T20:04:00	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.373257	372	EXECUTED	9:f2facd84bc264990ba214829927027c2	sql	Populate default value for report_card.last_used_at	\N	4.26.0	\N	\N	4525414792
v50.2024-07-09T20:04:02	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.377991	373	EXECUTED	9:30da31d19109ff29f6a4386baa36db09	addNotNullConstraint columnName=last_used_at, tableName=report_card	Add not null constraint for report_card.last_used_at	\N	4.26.0	\N	\N	4525414792
v50.2024-07-09T20:04:03	calherries	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.382672	374	EXECUTED	9:338e08c6b1d29ddc94646955b4871fbb	sql; sql	Set default for report_card.last_used_at	\N	4.26.0	\N	\N	4525414792
v50.2024-08-08T20:04:03	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.387697	375	EXECUTED	9:fcb72fa663833a502c30715c318ac51d	createIndex indexName=idx_user_parameter_value_user_id_dashboard_id_parameter_id, tableName=user_parameter_value	Added 0.50.0 - Add index on user_parameter_value(user_id, parameter_id, dashboard_id)	\N	4.26.0	\N	\N	4525414792
v50.2024-08-27T00:00:00	devurandom	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.395556	376	EXECUTED	9:a1bd3fa8820da8be79a14a89e6492617	addColumn tableName=metabase_database	Add is_attached_dwh to metabase_database	\N	4.26.0	\N	\N	4525414792
v51.2024-05-13T15:30:57	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.401448	377	EXECUTED	9:61c7acd0a24b70f54cb19297b2f6a327	addColumn tableName=report_card	Backup of dataset_query rewritten by the metrics v2 migration	\N	4.26.0	\N	\N	4525414792
v51.2024-05-13T16:00:00	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.415842	378	EXECUTED	9:92b3ef3c975e4ae2efa2329bb4b7c7b8	customChange	Migrate v1 metrics to v2 metrics	\N	4.26.0	\N	\N	4525414792
v51.2024-06-07T12:37:36	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.421199	379	EXECUTED	9:925ec052d1478040aeb04805cce81c04	renameColumn newColumnName=explicit_reference, oldColumnName=direct_reference, tableName=query_field	Rename query_field.direct_reference to query_field.indirect_reference	\N	4.26.0	\N	\N	4525414792
v51.2024-06-12T18:53:02	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.428084	380	EXECUTED	9:127d78800f11c155afc7e849e3f61947	dropIndex indexName=idx_user_id_device_id, tableName=login_history	Drop incorrect index on login_history	\N	4.26.0	\N	\N	4525414792
v51.2024-06-12T18:53:03	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.434488	381	EXECUTED	9:5354a54455609ea9c038f050004fa33d	createIndex indexName=idx_user_id_device_id, tableName=login_history	Create index on login_history (user_id, device_id)	\N	4.26.0	\N	\N	4525414792
v51.2024-07-08T10:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.462825	382	EXECUTED	9:d4292cf6065756c5b3bd0f836d701ccc	createTable tableName=channel	Create channel table	\N	4.26.0	\N	\N	4525414792
v51.2024-07-08T10:00:01	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.469673	383	EXECUTED	9:0d1902196f3e7a14a203f7715d118a23	addColumn tableName=pulse_channel	Create pulse_channel.channel_id	\N	4.26.0	\N	\N	4525414792
v51.2024-07-08T10:00:02	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.550982	384	EXECUTED	9:36ee221d5275e40b776c1fa7cc497b6a	addForeignKeyConstraint baseTableName=pulse_channel, constraintName=fk_pulse_channel_channel_id, referencedTableName=channel	Add fk constraint to pulse_channel.channel_id	\N	4.26.0	\N	\N	4525414792
v51.2024-07-10T12:28:10	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.558535	385	EXECUTED	9:e25864756ca17ef36181bddaf0c5cdc8	addColumn tableName=report_dashboard	Add `last_viewed_at` to dashboards	\N	4.26.0	\N	\N	4525414792
v51.2024-07-22T15:49:37	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.565187	386	EXECUTED	9:efa16c248d4954850f0d21e5a0956bb3	addColumn tableName=query_execution	Add embedding_client column to query_execution for metabase embedding SDK analytics	\N	4.26.0	\N	\N	4525414792
v51.2024-07-22T15:49:38	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.572491	387	EXECUTED	9:2c2159b9f26d2309efe17af96e5fb0ca	addColumn tableName=query_execution	Add embedding_version column to query_execution for metabase embedding SDK analytics	\N	4.26.0	\N	\N	4525414792
v51.2024-07-22T15:49:39	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.580054	388	EXECUTED	9:faf798a97e07f5dd56fe0da0d20e482d	addColumn tableName=view_log	Add embedding_client column to view_log for metabase embedding SDK analytics	\N	4.26.0	\N	\N	4525414792
v51.2024-07-22T15:49:40	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.587033	389	EXECUTED	9:d0eadbcc223aecbeb1392f14655b278d	addColumn tableName=view_log	Add embedding_version column to view_log for metabase embedding SDK analytics	\N	4.26.0	\N	\N	4525414792
v51.2024-07-25T11:56:27	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.59101	390	EXECUTED	9:93c9e40363e38834bb416e220528f79c	delete tableName=query_field	Wipe stale query fields, so we can add new non-nullable columns	\N	4.26.0	\N	\N	4525414792
v51.2024-07-25T11:57:27	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.597102	391	EXECUTED	9:98a60b35940430bad5de2a4530c6289f	addColumn tableName=query_field	Add `column` column to query fields	\N	4.26.0	\N	\N	4525414792
v51.2024-07-25T11:58:27	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.603466	392	EXECUTED	9:902020d5c41e4129ef80b8a0e3a9022e	addColumn tableName=query_field	Add `table` column to query fields	\N	4.26.0	\N	\N	4525414792
v51.2024-07-25T12:02:21	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.607966	393	EXECUTED	9:2a2843719eda91b32dfdac226874fe70	dropNotNullConstraint columnName=field_id, tableName=query_field	Make `field_id` nullable on query fields	\N	4.26.0	\N	\N	4525414792
v51.2024-07-26T11:56:27	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.615409	394	EXECUTED	9:ee8dd764f89b82a1363f22fcab6b5a30	addColumn tableName=query_field	Add `table_id` column to query fields	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T09:22:12	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.646149	395	EXECUTED	9:f8942a3c70c58c9273eb92f064cab046	createTable tableName=query_analysis	Add the query_analysis table	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T09:23:12	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.651394	396	EXECUTED	9:fc67e2d6e3a63df08b50ac7883a75f9d	createIndex indexName=idx_query_analysis_card_id, tableName=query_analysis	Index query_analysis.card_id	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T09:24:13	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.683728	397	EXECUTED	9:afe0238f708b1c60269b7f454048180d	createTable tableName=query_table	Add the query_table join table	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T09:25:13	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.68884	398	EXECUTED	9:19ea369d0ed744e15e35b59144135847	createIndex indexName=idx_query_table_card_id, tableName=query_table	Index query_table.card_id	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T09:25:14	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.69529	399	EXECUTED	9:9fc98c5d14def60d9534c00385b2c2d6	createIndex indexName=idx_query_table_analysis_id, tableName=query_table	Index query_table.analysis_id	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T09:25:15	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.701622	400	EXECUTED	9:4e4a1f16e79095dc5876acb214ab3f02	createIndex indexName=idx_query_table_table_id, tableName=query_table	Index query_table.table_id	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T10:03:27	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.706448	401	EXECUTED	9:93c9e40363e38834bb416e220528f79c	delete tableName=query_field	Wipe stale query fields, so we can add new non-nullable columns	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T10:04:13	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.716675	402	EXECUTED	9:d09cafce1250670b401e787667c80b24	addColumn tableName=query_field	Put Query Fields under a parent Query Analysis record	\N	4.26.0	\N	\N	4525414792
v51.2024-07-29T11:25:13	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.722509	403	EXECUTED	9:381fece783b9009b1fb444a912c63146	createIndex indexName=idx_query_field_analysis_id, tableName=query_field	Index query_field.analysis_id	\N	4.26.0	\N	\N	4525414792
v51.2024-08-02T11:56:27	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.730577	404	EXECUTED	9:d2ae89beeb0a9d68d763b6c50a6c997d	addColumn tableName=query_field	Add `schema` column to query fields	\N	4.26.0	\N	\N	4525414792
v51.2024-08-02T12:02:21	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.734673	405	EXECUTED	9:43aed92161d42e1046f0f239f35a6fb2	dropNotNullConstraint columnName=table, tableName=query_field	Make `table` nullable on query fields	\N	4.26.0	\N	\N	4525414792
v51.2024-08-05T16:00:00	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.740608	406	EXECUTED	9:9f6b8171972d8edc7d2595d2b1f0b32d	addColumn tableName=report_card	Add source card reference to report_card to support metrics based models and questions	\N	4.26.0	\N	\N	4525414792
v51.2024-08-05T16:00:01	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.746725	407	EXECUTED	9:a53d92e2841fb100bbe0209d2e3d1fd2	addForeignKeyConstraint baseTableName=report_card, constraintName=fk_report_card_source_card_id_ref_report_card_id, referencedTableName=report_card	Add FK constraint to report_card.source_card_id	\N	4.26.0	\N	\N	4525414792
v51.2024-08-05T16:00:02	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.757376	408	EXECUTED	9:925fbff8568f735824d8e8911d0322a4	createIndex indexName=idx_report_card_source_card_id, tableName=report_card	Index report_card.source_card_id	\N	4.26.0	\N	\N	4525414792
v51.2024-08-07T10:00:00	ranquild	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.764734	409	EXECUTED	9:9bfca360709e5d9ef70f2d83d7be6977	customChange	Remove field refs from report_card.visualization_settings.column_settings	\N	4.26.0	\N	\N	4525414792
v51.2024-08-07T11:00:00	ranquild	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.770685	410	EXECUTED	9:728004ac9b928318fb5569d4111fea82	customChange	Remove field refs from report_dashboardcard.visualization_settings.column_settings	\N	4.26.0	\N	\N	4525414792
v51.2024-08-26T08:53:46	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.77865	411	EXECUTED	9:e716134142aa624db03b2f524201a0d2	addColumn tableName=query_analysis	Add a status column to track the progress and outcome of query analysis	\N	4.26.0	\N	\N	4525414792
v51.2024-09-03T16:54:18	adam-james	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.785306	412	EXECUTED	9:774ce6de02302239d576ea422e73f761	addColumn tableName=pulse_card	Add pivot_results to pulse_card	\N	4.26.0	\N	\N	4525414792
v51.2024-09-09T15:11:16	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.794375	413	EXECUTED	9:b4758407319ab0bef2ba3af47429ca8e	createIndex indexName=idx_collection_type, tableName=collection	add an index for `collection.type`	\N	4.26.0	\N	\N	4525414792
v51.2024-09-26T03:01:00	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.79794	414	MARK_RAN	9:5663cad194148327fabb35496f62f1f1	sql; sql; sql	iff enable-embedding is set, copy -> enable-embedding-interactive	\N	4.26.0	\N	\N	4525414792
v51.2024-09-26T03:02:00	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.802227	415	MARK_RAN	9:13d6045ee11a3f87d2136e1664838157	sql; sql; sql	iff enable-embedding is set, copy -> enable-embedding-static	\N	4.26.0	\N	\N	4525414792
v51.2024-09-26T03:03:00	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.805877	416	MARK_RAN	9:8451de7d5a5400fe21ffbb1ed10afe69	sql; sql; sql	iff enable-embedding is set, copy -> enable-embedding-sdk	\N	4.26.0	\N	\N	4525414792
v51.2024-09-26T03:04:00	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.809385	417	MARK_RAN	9:1ff234c24e0d2135f405e2e9e17fe2e5	sql; sql; sql	iff embedding-app-origin is set, copy -> embedding-app-origins-interactive	\N	4.26.0	\N	\N	4525414792
v51.2024-10-24T14:23:58	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:49.815223	418	EXECUTED	9:c2b9f73b0862da7aceb35aa91e448c46	dropNotNullConstraint columnName=card_id, tableName=persisted_info	Drop not null constraint on persisted_info.card_id	\N	4.26.0	\N	\N	4525414792
v51.2024-10-24T14:24:59	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:50.816428	419	EXECUTED	9:86f699ca7caabe7a10761877e331e9b5	dropForeignKeyConstraint baseTableName=persisted_info, constraintName=fk_persisted_info_card_id	Drop foreign key constraint on persisted_info.card_id	\N	4.26.0	\N	\N	4525414792
v51.2024-10-24T14:25:01	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:23:56.967489	420	EXECUTED	9:4bee13ab60d88e862ae23154dea0ce80	addForeignKeyConstraint baseTableName=persisted_info, constraintName=fk_persisted_info_card_id, referencedTableName=report_card	Re-add nullable foreign key constraint on persisted_info.card_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:56.985474	421	EXECUTED	9:b272c85ca71fc9e1b07811496ea981a5	createTable tableName=notification	Create the notification table	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:01	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.022279	422	EXECUTED	9:33287f1a758b4141cb6c1f7e4e53a324	createTable tableName=notification_subscription	Create the notification_subscription table	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:02	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.032241	423	EXECUTED	9:ec33277caacf1d2169f935848e6db2fd	createIndex indexName=idx_notification_subscription_notification_id, tableName=notification_subscription	index on notification_subscription.notification_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:03	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.056888	424	EXECUTED	9:d4fcb44f2e334982381f9a7861083bfb	createTable tableName=channel_template	Create the channel_template table	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:04	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.091171	425	EXECUTED	9:ed28a0c8a57a1202f9316b8903ef8b3d	createTable tableName=notification_handler	Create the notification_handler table	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:05	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.181661	426	EXECUTED	9:22d1753b254670c9194b59d6314f6da8	addForeignKeyConstraint baseTableName=notification_handler, constraintName=fk_notification_handler_template_id, referencedTableName=channel_template	Add fk constraint to notification_handler.template_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:06	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.191591	427	EXECUTED	9:cd9a572043786add50c230f4d300bb1d	createIndex indexName=idx_notification_handler_notification_id, tableName=notification_handler	index on notification_handler.notification_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:07	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.200498	428	EXECUTED	9:62b43ed093079d842b5699f3d8c63952	createIndex indexName=idx_notification_handler_channel_id, tableName=notification_handler	index on notification_handler.channel_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:08	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.210191	429	EXECUTED	9:940d1263fed6ffcb1e2425c6aa5f4a53	createIndex indexName=idx_notification_handler_template_id, tableName=notification_handler	index on notification_handler.template_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:09	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.232755	430	EXECUTED	9:b9d2b1cd23c2f030def82062a07cd8f8	createTable tableName=notification_recipient	Create the notification_recipient table	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:10	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.242407	431	EXECUTED	9:f398c5f6b9fcc91f4363fdc0cfad4a88	createIndex indexName=idx_notification_recipient_notification_handler_id, tableName=notification_recipient	index on notification_recipient.notification_handler_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:11	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.252254	432	EXECUTED	9:bb183e39f47f13a9d27499bd23372f9f	createIndex indexName=idx_notification_recipient_user_id, tableName=notification_recipient	index on notification_recipient.user_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:12	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.262283	433	EXECUTED	9:3debeaec6c6e36018ce89946621783bf	createIndex indexName=idx_notification_recipient_permissions_group_id, tableName=notification_recipient	index on notification_recipient.permissions_group_id	\N	4.26.0	\N	\N	4525414792
v52.2024-09-05T08:00:13	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.269653	434	EXECUTED	9:d513d9216f89c0f91e9ad50c27010743	dropColumn columnName=entity_id, tableName=channel_template	Drop the channel_template.entity_id column	\N	4.26.0	\N	\N	4525414792
v52.2024-10-15T08:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.276269	435	EXECUTED	9:643d70bfb0eeeb2ad4cc9434e815b65e	addColumn tableName=notification_subscription	add notification_subscription.cron_schedule	\N	4.26.0	\N	\N	4525414792
v52.2024-10-26T18:42:42	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.286584	436	EXECUTED	9:5efa1c2d6153e9739f795f39c52ce63c	customChange	Add stage-number to dimension targets in parameter_mappings	\N	4.26.0	\N	\N	4525414792
v52.2024-11-12T15:13:18	metamben	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.293788	437	EXECUTED	9:4ec96ef4aaabfbfeb72a5dc7f333eb2e	customChange	Add stage-number to dimension targets in visualization_settings	\N	4.26.0	\N	\N	4525414792
v52.2024-12-03T15:55:22	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.416008	438	EXECUTED	9:56adcfb4d12d7f5e189a453a2d94fd75	customChange	Create New and improved Sample Content	\N	4.26.0	\N	\N	4525414792
v52.2024-12-10T10:28:16	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:23:57.425233	439	EXECUTED	9:4e17559a6aac1024e20978f1fa1f3847	addColumn tableName=report_card	Add `report_card.dashboard_id`	\N	4.26.0	\N	\N	4525414792
v52.2024-12-10T10:28:21	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.900264	440	EXECUTED	9:d47b7e9ec18a27f5adf6e9aa2e615bbc	addForeignKeyConstraint baseTableName=report_card, constraintName=fk_report_card_ref_dashboard_id, referencedTableName=report_dashboard	Make `report_card.dashboard_id` a foreign key	\N	4.26.0	\N	\N	4525414792
v52.2024-12-10T10:28:24	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.913616	441	EXECUTED	9:393772bdd87d63f2651329e244807da9	createIndex indexName=idx_report_card_dashboard_id, tableName=report_card	Add an index for `report_card.dashboard_id`	\N	4.26.0	\N	\N	4525414792
v52.2024-12-16T09:19:00	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.947031	442	EXECUTED	9:bafeeae859ed79ed0403fca966f62be1	createTable tableName=search_index_metadata	Metadata about search indexes	\N	4.26.0	\N	\N	4525414792
v52.2024-12-16T09:20:00	crisptrutski	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.963134	443	EXECUTED	9:38a17ebc2e74dc51a5b91b9a5670ca26	addUniqueConstraint constraintName=idx_search_index_metadata_unique_status, tableName=search_index_metadata	Protection against concurrent creation or promotion of indexes.	\N	4.26.0	\N	\N	4525414792
v52.2025-01-05T00:00:01	escherize	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.968718	444	EXECUTED	9:690ec2fcdf7a4d8b56f444c9f8723ed2	sql; sql; sql	set enable-embedding-sdk false when embedding-app-origins-sdk value exists	\N	4.26.0	\N	\N	4525414792
v53.2024-12-02T16:21:15	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.976526	445	EXECUTED	9:45c9c7af167de4c16571bbb01a4ece5c	addColumn tableName=cache_config	Add cache_config.refresh_automatically column	\N	4.26.0	\N	\N	4525414792
v53.2024-12-02T17:21:16	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.982292	446	EXECUTED	9:abe1692619474c9968bbbdcae2e02603	addColumn tableName=query_execution	Add query_execution.parameterized column	\N	4.26.0	\N	\N	4525414792
v53.2024-12-10T10:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:03.989047	447	EXECUTED	9:58b191cde441ea1ad86a0095903cd98e	addColumn tableName=notification	add notification.internal_id	\N	4.26.0	\N	\N	4525414792
v53.2024-12-10T10:00:10	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.012067	448	EXECUTED	9:dafaf59d768eb099b31b98f41f301774	sql; sql; sql	Truncate the notification tables	\N	4.26.0	\N	\N	4525414792
v53.2024-12-20T19:53:50	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.036761	449	EXECUTED	9:a325c409a4f7cee951e593b451ea7ca1	createTable tableName=user_key_value	add a table for user-level KV. This is intended for use as a lightweight mechanism for the frontend to be able to mark things as seen, unseen, dismissed, etc	\N	4.26.0	\N	\N	4525414792
v53.2024-12-20T19:53:59	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.044021	450	EXECUTED	9:cc1413844fe926c3f05ca62713b9a6eb	addUniqueConstraint constraintName=unique_user_key_value_user_id_namespace_key, tableName=user_key_value	Add a unique constraint for user_id,namespace,key	\N	4.26.0	\N	\N	4525414792
v53.2024-12-27T17:33:54	nvoxland	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.0503	451	EXECUTED	9:1c1cbbe3f486a5e516c51b782e374c91	insert tableName=setting	Adds encryption-check setting to encryption management	\N	4.26.0	\N	\N	4525414792
v53.2024-12-27T20:17:23	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.055886	452	EXECUTED	9:44a1e7ed80a74be1c9982b2a168dae8d	dropNotNullConstraint columnName=refresh_automatically, tableName=cache_config	Drop unnecessary NOT NULL constraint from cache_config.refresh_automatically column	\N	4.26.0	\N	\N	4525414792
v53.2025-01-03T19:07:39	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.064224	453	EXECUTED	9:44e23c24462bbc410c1ea0e9683ff0ff	addColumn tableName=core_user	Add `deactivated_at` column to the `core_user` table	\N	4.26.0	\N	\N	4525414792
v53.2025-02-20T04:49:39	johnswanson	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.069856	454	EXECUTED	9:2b33f5f97c46f5e536426a48f8dcd420	sql	remove unused cards in usage analytics	\N	4.26.0	\N	\N	4525414792
v53.2025-04-02T15:25:04	edpaget	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.098484	455	EXECUTED	9:d7ad7846a452a25134dc4fce0c5a1327	createTable tableName=metabase_cluster_lock	create new cluster lock table for instance coordination	\N	4.26.0	\N	\N	4525414792
v54.2025-01-30T16:10:55	bshepherdson	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.108015	456	EXECUTED	9:db7dd5074e0f15b84cacf099d6267f0c	addColumn tableName=metabase_database	Add `entity_id` column to the `metabase_database` table	\N	4.26.0	\N	\N	4525414792
v54.2025-01-30T16:13:20	bshepherdson	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.117289	457	EXECUTED	9:50e186623b989b1f1c88f179350e6649	addColumn tableName=metabase_table	Add `entity_id` column to the `metabase_table` table	\N	4.26.0	\N	\N	4525414792
v54.2025-01-30T16:14:02	bshepherdson	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.124395	458	EXECUTED	9:64c5d7cc3bc5205bdcc6db30e65c2058	addColumn tableName=metabase_field	Add `entity_id` column to the `metabase_field` table	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.130498	459	EXECUTED	9:fcba2955c00cabca7f67fa984b599ce3	addColumn tableName=notification	add notification.payload_id	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:01:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.154154	460	EXECUTED	9:06721281b936568103442a0587852283	createTable tableName=notification_card	create the notification_card table	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:03:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.159608	461	EXECUTED	9:7ec312ee313b1190369789d35e3680db	addColumn tableName=notification	add notification.creator_id	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:04:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.242456	462	EXECUTED	9:20c5b43f69fdfdc236915d69d6a4c150	addForeignKeyConstraint baseTableName=notification, constraintName=fk_notification_creator_id, referencedTableName=core_user	add fk constraint to notification.creator_id	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:04:01	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.252618	463	EXECUTED	9:5cf267bfb5965a7ccd84c3dc23032131	createIndex indexName=idx_notification_creator_id, tableName=notification	Add an index for `notification.creator_id`	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:04:02	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.262646	464	EXECUTED	9:6936e3e0c7dba6dea935d1f89487dd8d	createIndex indexName=idx_notification_card_card_id, tableName=notification_card	Add an index for `notification_card.card_id`	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:05:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.270309	465	EXECUTED	9:b62a79014c05b1eb2d9fd0ed90667691	customChange	Migrate alert to notification	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:06:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.274022	466	EXECUTED	9:a7ca957848b7a2d82c733ec390529b49	sql	Delete all the migrated alerts from notification table	\N	4.26.0	\N	\N	4525414792
v54.2025-02-14T08:07:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.286397	467	EXECUTED	9:2b02cf3fa99d1acd162297528b855d27	sqlFile path=instance_analytics_views/alerts/v2/postgres-alerts.sql; sqlFile path=instance_analytics_views/alerts/v2/mysql-alerts.sql; sqlFile path=instance_analytics_views/alerts/v2/h2-alerts.sql	Update view v_alerts to read from notification tables	\N	4.26.0	\N	\N	4525414792
v54.2025-03-06T16:55:15	nvoxland	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.293098	468	EXECUTED	9:76ee2395577d79f70d04289d61f3eea1	addColumn tableName=core_session	Replacing storing the session key in the "id" column in favor of storing a new hashed version	\N	4.26.0	\N	\N	4525414792
v54.2025-03-06T16:55:16	nvoxland	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.298188	469	EXECUTED	9:806a5600ea3a191b80ba2e4442ec8e95	createIndex indexName=idx_core_session_key_hashed, tableName=core_session	Creating index on the hashed session key	\N	4.26.0	\N	\N	4525414792
v54.2025-03-11T16:00:00	qnkhuat	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.303925	470	EXECUTED	9:12484ad947fcd07ae4a8f31da05e4e51	addColumn tableName=notification_subscription	add notification_subscription.ui_display_type	\N	4.26.0	\N	\N	4525414792
v54.2025-03-17T18:52:44	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.307654	471	EXECUTED	9:0bd98bc8c58e53c9a962696e360d7077	sql; sql; sql	Migrating zh site locales to zh_CN	\N	4.26.0	\N	\N	4525414792
v54.2025-03-17T18:52:59	noahmoss	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.311655	472	EXECUTED	9:b75be105a2d1deb4795aa4debaffd3e0	sql	Migrating zh user locales to zh_CN	\N	4.26.0	\N	\N	4525414792
v54.2025-03-25T16:34:12	edpaget	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.319646	473	EXECUTED	9:cbdb4ba2a61b2b8de60b1b27f12b4202	createIndex indexName=idx_field_usage_query_execution_id, tableName=field_usage	Add index to field_usage query_execution_id column to support faster deletes	\N	4.26.0	\N	\N	4525414792
v54.2025-03-27T17:52:01	luizarakaki	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.32684	474	EXECUTED	9:a5e0dab0cf7c4d21bf7d6d4a63cbc62e	sqlFile path=instance_analytics_views/tasks/v2/postgres-tasks.sql; sqlFile path=instance_analytics_views/tasks/v2/mysql-tasks.sql; sqlFile path=instance_analytics_views/tasks/v2/h2-tasks.sql	updating v_tasks to add new `status` field	\N	4.26.0	\N	\N	4525414792
v54.2025-03-28T11:22:01	luizarakaki	migrations/001_update_migrations.yaml	2025-04-13 06:24:04.344274	475	EXECUTED	9:a1cb8f1ff8fcb7d814f6f0a07a1f729d	sqlFile path=instance_analytics_views/content/v3/postgres-content.sql; sqlFile path=instance_analytics_views/content/v3/mysql-content.sql; sqlFile path=instance_analytics_views/content/v3/h2-content.sql	updating v_content to add new `is_verified` field	\N	4.26.0	\N	\N	4525414792
\.


--
-- Data for Name: dependency; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.dependency (id, model, model_id, dependent_on_model, dependent_on_id, created_at) FROM stdin;
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.dimension (id, field_id, name, type, human_readable_field_id, created_at, updated_at, entity_id) FROM stdin;
\.


--
-- Data for Name: field_usage; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.field_usage (id, field_id, query_execution_id, used_in, filter_op, aggregation_function, breakout_temporal_unit, breakout_binning_strategy, breakout_binning_num_bins, breakout_binning_bin_width, created_at) FROM stdin;
\.


--
-- Data for Name: http_action; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.http_action (action_id, template, response_handle, error_handle) FROM stdin;
\.


--
-- Data for Name: implicit_action; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.implicit_action (action_id, kind) FROM stdin;
\.


--
-- Data for Name: label; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.label (id, name, slug, icon) FROM stdin;
\.


--
-- Data for Name: login_history; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.login_history (id, "timestamp", user_id, session_id, device_id, device_description, ip_address) FROM stdin;
1	2025-04-13 06:25:18.553483+00	1	kfBRTpaKiZ5L	fab04d77-dd40-4e19-aaf1-74adbb311585	Mozilla/5.0 (X11; Linux x86_64; rv:137.0) Gecko/20100101 Firefox/137.0	172.30.0.1
\.


--
-- Data for Name: metabase_cluster_lock; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metabase_cluster_lock (lock_name) FROM stdin;
\.


--
-- Data for Name: metabase_database; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metabase_database (id, created_at, updated_at, name, description, details, engine, is_sample, is_full_sync, points_of_interest, caveats, metadata_sync_schedule, cache_field_values_schedule, timezone, is_on_demand, auto_run_queries, refingerprint, cache_ttl, initial_sync_status, creator_id, settings, dbms_version, is_audit, uploads_enabled, uploads_schema_name, uploads_table_prefix, is_attached_dwh, entity_id) FROM stdin;
1	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:07.521743+00	Sample Database	Some example data for you to play around with.	{"db":"file:/plugins/sample-database.db;USER=GUEST;PASSWORD=guest"}	h2	t	t	You can find all sorts of different joinable tables ranging from products to people to reviews here.	You probably don't want to use this for your business-critical analyses, but hey, it's your world, we're just living in it.	0 43 * * * ? *	0 0 14 * * ? *	GMT	f	t	\N	\N	complete	\N	\N	{"flavor":"H2","version":"2.1.214 (2022-06-13)","semantic-version":[2,1]}	f	f	\N	\N	f	p8weUD-jtvrY7aMOToMk2
2	2025-04-13 06:25:40.549937+00	2025-04-13 06:59:46.602113+00	Customer Support	\N	{"ssl":false,"password":"mysecretpassword","port":null,"advanced-options":false,"schema-filters-type":"all","dbname":"customer_support","host":"postgres","tunnel-enabled":false,"user":"metabase"}	postgres	f	t	\N	\N	0 45 * * * ? *	0 0 11 * * ? *	GMT	f	t	\N	\N	complete	1	\N	{"flavor":"PostgreSQL","version":"17.0 (Debian 17.0-1.pgdg120+1)","semantic-version":[17,0]}	f	f	\N	\N	f	NodLyX0OC3jFSnSxuObIy
\.


--
-- Data for Name: metabase_field; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metabase_field (id, created_at, updated_at, name, base_type, semantic_type, active, description, preview_display, "position", table_id, parent_id, display_name, visibility_type, fk_target_field_id, last_analyzed, points_of_interest, caveats, fingerprint, fingerprint_version, database_type, has_field_values, settings, database_position, custom_position, effective_type, coercion_strategy, nfc_path, database_required, json_unfolding, database_is_auto_increment, database_indexed, database_partitioned, is_defective_duplicate, entity_id) FROM stdin;
20	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ID	type/BigInteger	type/PK	t	\N	t	0	5	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	t	f	f	t	\N	f	L0667_XF2mtJj6nvEQJw6
21	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	LONGITUDE	type/Float	type/Longitude	t	\N	t	14	6	\N	Longitude	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2484,"nil%":4.008016032064128E-4},"type":{"type/Number":{"min":-175.06667,"q1":-55.495929410727236,"q3":28.627359769389155,"max":176.21667,"sd":68.51011002740533,"avg":2.6042336031796345}}}	5	DOUBLE PRECISION	\N	\N	14	0	type/Float	\N	\N	f	f	f	f	\N	f	yuteozXeBusGUOo0ggCQg
4	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ID	type/BigInteger	type/PK	t	A unique identifier given to each user.	t	0	1	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	f	f	t	t	\N	f	tY1QPDSA_QxG8PLpBP7hS
22	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	RATING	type/Integer	type/Score	t	\N	t	4	5	\N	Rating	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":5,"nil%":0.0},"type":{"type/Number":{"min":1.0,"q1":2.7545289729206877,"q3":4.004191340512663,"max":5.0,"sd":0.8137255616667736,"avg":3.3629283489096573}}}	5	SMALLINT	auto-list	\N	4	0	type/Integer	\N	\N	f	f	f	f	\N	f	h_NlUcHpuQfzr7fM1RJrB
45	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ACCOUNT_ID	type/BigInteger	type/FK	t	\N	t	1	7	\N	Account ID	normal	24	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":589,"nil%":0.0}}	5	BIGINT	\N	\N	1	0	type/BigInteger	\N	\N	f	f	f	t	\N	f	BAwxNnpjOJNRFuqE85sP8
46	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	PLAN	type/Text	type/Category	t	\N	t	4	8	\N	Plan	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":3,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.2931}}}	5	CHARACTER VARYING	auto-list	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	b6UDJLle_aO-KMOsAI4nM
66	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	ACCOUNT_ID	type/BigInteger	type/FK	t	\N	t	1	8	\N	Account ID	normal	24	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1449,"nil%":0.0}}	5	BIGINT	\N	\N	1	0	type/BigInteger	\N	\N	f	f	f	t	\N	f	UbSxVyqwpdz3Lz0nM0C28
54	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	PASSWORD	type/Text	\N	t	This is the salted password of the user. It should not be visible	t	3	1	\N	Password	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2500,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":36.0}}}	5	CHARACTER VARYING	\N	\N	3	0	type/Text	\N	\N	f	f	f	f	\N	f	dEWcPacYJCbQq0IcnZdIv
48	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	NAME	type/Text	type/Name	t	The name of the user who owns an account	t	4	1	\N	Name	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2499,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":13.532}}}	5	CHARACTER VARYING	\N	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	7KBwlOliFSVY8uO5_fISQ
53	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	CITY	type/Text	type/City	t	The city of the account’s billing address	t	5	1	\N	City	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1966,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.002,"average-length":8.284}}}	5	CHARACTER VARYING	\N	\N	5	0	type/Text	\N	\N	f	f	f	f	\N	f	HwSC-sAEaqY18l8YPbtlM
58	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	LONGITUDE	type/Float	type/Longitude	t	This is the longitude of the user on sign-up. It might be updated in the future to the last seen location.	t	6	1	\N	Longitude	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2491,"nil%":0.0},"type":{"type/Number":{"min":-166.5425726,"q1":-101.58350792373135,"q3":-84.65289348288829,"max":-67.96735199999999,"sd":15.399698968175663,"avg":-95.18741780363999}}}	5	DOUBLE PRECISION	\N	\N	6	0	type/Float	\N	\N	f	f	f	f	\N	f	uNyCfll8KLzDjc82NLp0U
52	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	LATITUDE	type/Float	type/Latitude	t	This is the latitude of the user on sign-up. It might be updated in the future to the last seen location.	t	11	1	\N	Latitude	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2491,"nil%":0.0},"type":{"type/Number":{"min":25.775827,"q1":35.302705923023126,"q3":43.773802584662,"max":70.6355001,"sd":6.390832341883712,"avg":39.87934670484002}}}	5	DOUBLE PRECISION	\N	\N	11	0	type/Float	\N	\N	f	f	f	f	\N	f	SB_B7ymQJTJ3diKQgbYYU
59	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	ID	type/BigInteger	type/PK	t	A unique internal identifier for the review. Should not be used externally.	t	0	4	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	f	f	t	t	\N	f	HllBWjDrwn4GZpyvoc7Y-
7	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	EMAIL	type/Text	type/Email	t	The contact email for the account.	t	2	1	\N	Email	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2500,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":1.0,"percent-state":0.0,"average-length":24.1824}}}	5	CHARACTER VARYING	\N	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	ptBVqedxVteTpnuaC40n4
6	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	TAX	type/Float	\N	t	This is the amount of local and federal taxes that are collected on the purchase. Note that other governmental fees on some products are not included here, but instead are accounted for in the subtotal.	t	4	2	\N	Tax	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":797,"nil%":0.0},"type":{"type/Number":{"min":0.0,"q1":2.273340386603857,"q3":5.337275338216307,"max":11.12,"sd":2.3206651358900316,"avg":3.8722100000000004}}}	5	DOUBLE PRECISION	\N	\N	4	0	type/Float	\N	\N	f	f	f	f	\N	f	Fu_WiIfciI7K22bPlep3r
5	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	TOTAL	type/Float	\N	t	The total billed amount.	t	5	2	\N	Total	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":4426,"nil%":0.0},"type":{"type/Number":{"min":8.93914247937167,"q1":51.34535490743823,"q3":110.29428389265787,"max":159.34900526552292,"sd":34.26469575709948,"avg":80.35871658771228}}}	5	DOUBLE PRECISION	\N	\N	5	0	type/Float	\N	\N	f	f	f	f	\N	f	FpB3Sg7Nry4VByPz-1AkD
9	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ID	type/BigInteger	type/PK	t	This is a unique ID for the product. It is also called the “Invoice number” or “Confirmation number” in customer facing emails and screens.	t	0	2	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	f	f	t	t	\N	f	RG__IdeXqS0Noa796xCaZ
11	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	USER_ID	type/Integer	type/FK	t	The id of the user who made this order. Note that in some cases where an order was created on behalf of a customer who phoned the order in, this might be the employee who handled the request.	t	1	2	\N	User ID	normal	4	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":929,"nil%":0.0}}	5	INTEGER	\N	\N	1	0	type/Integer	\N	\N	f	f	f	t	\N	f	Ch_n7rD9cMOCfsni6jqar
2	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	QUANTITY	type/Integer	type/Quantity	t	Number of products bought.	t	8	2	\N	Quantity	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":62,"nil%":0.0},"type":{"type/Number":{"min":0.0,"q1":1.755882607764982,"q3":4.882654507928044,"max":100.0,"sd":4.214258386403798,"avg":3.7015}}}	5	INTEGER	auto-list	\N	8	0	type/Integer	\N	\N	f	f	f	f	\N	f	_0jbKkfDf_6GRXC-88Rz5
3	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	DISCOUNT	type/Float	type/Discount	t	Discount amount.	t	6	2	\N	Discount	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":701,"nil%":0.898},"type":{"type/Number":{"min":0.17088996672584322,"q1":2.9786226681458743,"q3":7.338187788658235,"max":61.69684269960571,"sd":3.053663125001991,"avg":5.161255547580326}}}	5	DOUBLE PRECISION	\N	\N	6	0	type/Float	\N	\N	f	f	f	f	\N	f	pCvywXjlx_d5O4i2DKoM-
13	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	CREATED_AT	type/DateTime	type/CreationTimestamp	t	The date and time an order was submitted.	t	7	2	\N	Created At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":10001,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2022-04-30T18:56:13.352Z","latest":"2026-04-19T14:07:15.657Z"}}}	5	TIMESTAMP	\N	\N	7	0	type/DateTime	\N	\N	f	f	f	f	\N	f	xfUVI6ZAWVVZK81RZMJr-
1	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	STATE	type/Text	type/State	t	The state or province of the account’s billing address	t	7	1	\N	State	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":49,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":1.0,"average-length":2.0}}}	5	CHARACTER	auto-list	\N	7	0	type/Text	\N	\N	f	f	f	f	\N	f	Kgkogzn0LmGIlki-M775r
12	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	BIRTH_DATE	type/Date	\N	t	The date of birth of the user	t	9	1	\N	Birth Date	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2308,"nil%":0.0},"type":{"type/DateTime":{"earliest":"1958-04-26","latest":"2000-04-03"}}}	5	DATE	\N	\N	9	0	type/Date	\N	\N	f	f	f	f	\N	f	IIDQETHtQ6wifcsljYcDY
18	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	CATEGORY	type/Text	type/Category	t	The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget	t	3	3	\N	Category	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":6.375}}}	5	CHARACTER VARYING	auto-list	\N	3	0	type/Text	\N	\N	f	f	f	f	\N	f	fP30AXezCvSj8dIVjkEHA
15	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	EAN	type/Text	\N	t	The international article number. A 13 digit number uniquely identifying the product.	t	1	3	\N	Ean	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":200,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":13.0}}}	5	CHARACTER	auto-list	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	967WhbYIpEyR0bzgLd0qG
8	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ID	type/BigInteger	type/PK	t	The numerical product number. Only used internally. All external communication should use the title or EAN.	t	0	3	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	f	f	t	t	\N	f	7bzEVBCsGXmZncPkch5R_
16	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	RATING	type/Float	type/Score	t	The average rating users have given the product. This ranges from 1 - 5	t	6	3	\N	Rating	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":23,"nil%":0.0},"type":{"type/Number":{"min":0.0,"q1":3.5120465053408525,"q3":4.216124969497314,"max":5.0,"sd":1.3605488657451452,"avg":3.4715}}}	5	DOUBLE PRECISION	\N	\N	6	0	type/Float	\N	\N	f	f	f	f	\N	f	L_Vw7HzJlif1D2BIj_MzR
17	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	TITLE	type/Text	type/Title	t	The name of the product as it should be displayed to customers.	t	2	3	\N	Title	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":199,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":21.495}}}	5	CHARACTER VARYING	auto-list	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	SCniZJAitRBR9B86Vh0P4
19	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	RATING	type/Integer	type/Score	t	The rating (on a scale of 1-5) the user left.	t	3	4	\N	Rating	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":5,"nil%":0.0},"type":{"type/Number":{"min":1.0,"q1":3.54744353181696,"q3":4.764807071650455,"max":5.0,"sd":1.0443899855660577,"avg":3.987410071942446}}}	5	SMALLINT	auto-list	\N	3	0	type/Integer	\N	\N	f	f	f	f	\N	f	8KS6LYg2ftOit-QvWVGLW
23	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	RATING_MAPPED	type/Text	type/Category	t	\N	t	5	5	\N	Rating Mapped	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":5,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":6.453271028037383}}}	5	CHARACTER VARYING	auto-list	\N	5	0	type/Text	\N	\N	f	f	f	f	\N	f	vQLXTN6c9cn_AqbITtlDp
24	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ID	type/BigInteger	type/PK	t	\N	t	0	6	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	t	f	f	t	\N	f	c_N5ijehoi-H3M4HdHqcl
25	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ACCOUNT_ID	type/BigInteger	type/FK	t	\N	t	1	5	\N	Account ID	normal	24	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":642,"nil%":0.0}}	5	BIGINT	\N	\N	1	0	type/BigInteger	\N	\N	f	f	f	t	\N	f	UtnAGIT9Vgj9JOnpFjx2k
26	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	EMAIL	type/Text	type/Email	t	\N	t	2	5	\N	Email	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":642,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":1.0,"percent-state":0.0,"average-length":28.327102803738317}}}	5	CHARACTER VARYING	auto-list	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	X1HsfCGkx6Zd7h1FMkcwv
27	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	DATE_RECEIVED	type/DateTime	\N	t	\N	t	3	5	\N	Date Received	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":576,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2020-11-20T00:00:00Z","latest":"2031-12-01T00:00:00Z"}}}	5	TIMESTAMP	\N	\N	3	0	type/DateTime	\N	\N	f	f	f	f	\N	f	kEQYEG0_-sFcO9tHiSIRt
28	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	BODY	type/Text	\N	t	\N	f	6	5	\N	Body	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":642,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":438.15264797507785}}}	5	CHARACTER LARGE OBJECT	auto-list	\N	6	0	type/Text	\N	\N	f	f	f	f	\N	f	ESN3KBzj55e8D5YMAu6xM
29	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	BUTTON_LABEL	type/Text	type/Category	t	\N	t	5	7	\N	Button Label	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":6,"nil%":0.8698},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":1.0552}}}	5	CHARACTER VARYING	auto-list	\N	5	0	type/Text	\N	\N	f	f	f	f	\N	f	nExkS8To_Tv_CBeEqsgcy
31	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	CREATED_AT	type/DateTime	type/CreationTimestamp	t	\N	t	7	6	\N	Created At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2495,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2020-09-15T16:11:50Z","latest":"2031-10-10T19:14:48Z"}}}	5	TIMESTAMP	\N	\N	7	0	type/DateTime	\N	\N	f	f	f	f	\N	f	eoAK9cB_iv648ESH0MXPk
32	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	EVENT	type/Text	type/Category	t	\N	t	2	7	\N	Event	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":11.3906}}}	5	CHARACTER VARYING	auto-list	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	HX04pFL-VtEATbE2irzrF
33	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	SEATS	type/Integer	\N	t	\N	t	6	6	\N	Seats	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":102,"nil%":0.0},"type":{"type/Number":{"min":1.0,"q1":2.4309856865966593,"q3":10.553778422458695,"max":1325.0,"sd":51.198301031505444,"avg":16.21763527054108}}}	5	INTEGER	auto-list	\N	6	0	type/Integer	\N	\N	f	f	f	f	\N	f	iAFlxzUKvNjDDPUqWRbF3
35	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	TIMESTAMP	type/DateTime	\N	t	\N	t	3	7	\N	Timestamp	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":8576,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2022-03-15T00:18:25Z","latest":"2022-04-11T20:24:02Z"}}}	5	TIMESTAMP	\N	\N	3	0	type/DateTime	\N	\N	f	f	f	f	\N	f	JFfEFdO9JBn7dLyUCYgPi
36	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	LAST_NAME	type/Text	type/Name	t	\N	t	3	6	\N	Last Name	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":473,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":6.536673346693386}}}	5	CHARACTER VARYING	auto-list	\N	3	0	type/Text	\N	\N	f	f	f	f	\N	f	wF2cuoIFeDuqgYUdQ1QsQ
37	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	FIRST_NAME	type/Text	type/Name	t	\N	t	2	6	\N	First Name	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1687,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.001603206412825651,"average-length":5.997595190380761}}}	5	CHARACTER VARYING	\N	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	qdeejaMMv8AX1jUMcuc_K
38	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	TRIAL_CONVERTED	type/Boolean	type/Category	t	\N	t	10	6	\N	Trial Converted	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0}}	5	BOOLEAN	auto-list	\N	10	0	type/Boolean	\N	\N	f	f	f	f	\N	f	xGdGHJEv56FO4Wk8d-AMa
39	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	CANCELED_AT	type/DateTime	type/CancelationTimestamp	t	\N	t	9	6	\N	Canceled At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2021,"nil%":0.1859719438877756},"type":{"type/DateTime":{"earliest":"2020-10-01T15:43:40Z","latest":"2032-06-03T14:01:15Z"}}}	5	TIMESTAMP	\N	\N	9	0	type/DateTime	\N	\N	f	f	f	f	\N	f	152zQDckMNba3JkEDpEFz
40	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	TRIAL_ENDS_AT	type/DateTime	\N	t	\N	t	8	6	\N	Trial Ends At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1712,"nil%":0.001202404809619238},"type":{"type/DateTime":{"earliest":"2020-09-30T12:00:00Z","latest":"2031-10-25T12:00:00Z"}}}	5	TIMESTAMP	\N	\N	8	0	type/DateTime	\N	\N	f	f	f	f	\N	f	ZH0sLwdgB4P72Ea5zZznF
41	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	SOURCE	type/Text	type/Source	t	\N	t	5	6	\N	Source	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":5,"nil%":0.3346693386773547},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":4.4705410821643286}}}	5	CHARACTER VARYING	auto-list	\N	5	0	type/Text	\N	\N	f	f	f	f	\N	f	sqSP8DVe0g2REVdRNLjw3
42	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ACTIVE_SUBSCRIPTION	type/Boolean	type/Category	t	\N	t	11	6	\N	Active Subscription	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0}}	5	BOOLEAN	auto-list	\N	11	0	type/Boolean	\N	\N	f	f	f	f	\N	f	3l3tqodE3Sjzg5PZ5mjn1
43	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	PLAN	type/Text	type/Category	t	\N	t	4	6	\N	Plan	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":3,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.1062124248497}}}	5	CHARACTER VARYING	auto-list	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	M1m9VQXh5hFvHpu_jbD9c
44	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	PRICE	type/Float	\N	t	The list price of the product. Note that this is not always the price the product sold for due to discounts, promotions, etc.	t	5	3	\N	Price	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":170,"nil%":0.0},"type":{"type/Number":{"min":15.691943673970439,"q1":37.25154462926434,"q3":75.45898071609447,"max":98.81933684368194,"sd":21.711481557852057,"avg":55.74639966792074}}}	5	DOUBLE PRECISION	\N	\N	5	0	type/Float	\N	\N	f	f	f	f	\N	f	GzVJ3sJkDktFmVMO7QiQY
34	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	VENDOR	type/Text	type/Company	t	The source of the product.	t	4	3	\N	Vendor	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":200,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":20.6}}}	5	CHARACTER VARYING	auto-list	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	ezHvflqhpPUl3G6hH4tIM
47	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	LEGACY_PLAN	type/Boolean	type/Category	t	\N	t	12	6	\N	Legacy Plan	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0}}	5	BOOLEAN	auto-list	\N	12	0	type/Boolean	\N	\N	f	f	f	f	\N	f	oxoF6bonmeisb4TceMqee
49	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	PAGE_URL	type/Text	type/URL	t	\N	t	4	7	\N	Page URL	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":6,"nil%":0.1302},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":22.2674}}}	5	CHARACTER VARYING	auto-list	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	HzIGk1waf9s7kMqdeK5T5
56	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	COUNTRY	type/Text	type/Country	t	\N	t	15	6	\N	Country	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":134,"nil%":8.016032064128256E-4},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.1130260521042084,"average-length":1.9983967935871743}}}	5	CHARACTER	auto-list	\N	15	0	type/Text	\N	\N	f	f	f	f	\N	f	VsNGA7qUAF8npe417fDe9
57	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	LATITUDE	type/Float	type/Latitude	t	\N	t	13	6	\N	Latitude	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2472,"nil%":4.008016032064128E-4},"type":{"type/Number":{"min":-48.75,"q1":19.430679334308675,"q3":47.24585743676113,"max":69.23111,"sd":23.492041679980137,"avg":31.35760681046913}}}	5	DOUBLE PRECISION	\N	\N	13	0	type/Float	\N	\N	f	f	f	f	\N	f	eD-DgcBEYdfqPwVhcafTT
60	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	ID	type/BigInteger	type/PK	t	\N	t	0	7	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	t	f	f	t	\N	f	pR5WRgWK2mapv6t_K0M6v
62	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	EMAIL	type/Text	type/Email	t	\N	t	1	6	\N	Email	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2494,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":1.0,"percent-state":0.0,"average-length":28.185971943887775}}}	5	CHARACTER VARYING	\N	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	PmL0MmHEQ20BrxO6bcivc
64	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:10.706337+00	PAYMENT	type/Float	\N	t	\N	t	2	8	\N	Payment	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":707,"nil%":0.0},"type":{"type/Number":{"min":13.7,"q1":233.1870107122195,"q3":400.5965814842149,"max":33714.6,"sd":763.7961603932441,"avg":519.4153400000004}}}	5	DOUBLE PRECISION	\N	\N	2	0	type/Float	\N	\N	f	f	f	f	\N	f	0PcXTEN7wm4KtFz6Ay9jd
50	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	CREATED_AT	type/DateTime	type/CreationTimestamp	t	The date the user record was created. Also referred to as the user’s "join date"	t	12	1	\N	Created At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2500,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2022-04-19T21:35:18.752Z","latest":"2025-04-19T14:06:27.3Z"}}}	5	TIMESTAMP	\N	\N	12	0	type/DateTime	\N	\N	f	f	f	f	\N	f	By0pg8WxsicPttgo8_z3_
63	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	CREATED_AT	type/DateTime	type/CreationTimestamp	t	The date the product was added to our catalog.	t	7	3	\N	Created At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":200,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2022-04-26T19:29:55.147Z","latest":"2025-04-15T13:34:19.931Z"}}}	5	TIMESTAMP	\N	\N	7	0	type/DateTime	\N	\N	f	f	f	f	\N	f	VWUifN5EbisUz7aRW12O_
55	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	CREATED_AT	type/DateTime	type/CreationTimestamp	t	The day and time a review was written by a user.	t	5	4	\N	Created At	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1112,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2022-06-03T00:37:05.818Z","latest":"2026-04-19T14:15:25.677Z"}}}	5	TIMESTAMP	\N	\N	5	0	type/DateTime	\N	\N	f	f	f	f	\N	f	RcpssjU66tS8uAp2vu6Qv
65	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	PRODUCT_ID	type/Integer	type/FK	t	The product the review was for	t	1	4	\N	Product ID	normal	8	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":176,"nil%":0.0}}	5	INTEGER	\N	\N	1	0	type/Integer	\N	\N	f	f	f	t	\N	f	XS6lNrYuW2ExpaKOz9oE5
61	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	ZIP	type/Text	type/ZipCode	t	The postal code of the account’s billing address	t	10	1	\N	Zip	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2234,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.0}}}	5	CHARACTER	\N	\N	10	0	type/Text	\N	\N	f	f	f	f	\N	f	jjnn4k7bYNoRJo1z_HAR3
68	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	ID	type/BigInteger	type/PK	t	\N	t	0	8	\N	ID	normal	\N	\N	\N	\N	\N	0	BIGINT	\N	\N	0	0	type/BigInteger	\N	\N	t	f	f	t	\N	f	qSfPvNsbEATBlCniF5-3A
70	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	EXPECTED_INVOICE	type/Boolean	type/Category	t	\N	t	3	8	\N	Expected Invoice	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0}}	5	BOOLEAN	auto-list	\N	3	0	type/Boolean	\N	\N	f	f	f	f	\N	f	RnHgD8_Y-sXVn9U7cMGxN
71	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	DATE_RECEIVED	type/DateTime	\N	t	\N	t	5	8	\N	Date Received	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":714,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2020-09-30T00:00:00Z","latest":"2027-05-02T00:00:00Z"}}}	5	TIMESTAMP	\N	\N	5	0	type/DateTime	\N	\N	f	f	f	f	\N	f	gYEMuvCA17BeU8gtGObAW
14	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	PRODUCT_ID	type/Integer	type/FK	t	The product ID. This is an internal identifier for the product, NOT the SKU.	t	2	2	\N	Product ID	normal	8	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":200,"nil%":0.0}}	5	INTEGER	\N	\N	2	0	type/Integer	\N	\N	f	f	f	t	\N	f	BF9eOajnH1szV7maBeqYS
10	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	SUBTOTAL	type/Float	\N	t	The raw, pre-tax cost of the order. Note that this might be different in the future from the product price due to promotions, credits, etc.	t	3	2	\N	Subtotal	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":340,"nil%":0.0},"type":{"type/Number":{"min":15.691943673970439,"q1":49.74894519060184,"q3":105.42965746993103,"max":148.22900526552291,"sd":32.53705013056317,"avg":77.01295465356547}}}	5	DOUBLE PRECISION	\N	\N	3	0	type/Float	\N	\N	f	f	f	f	\N	f	ufuV-MUgdnn0d68b6llTg
51	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	ADDRESS	type/Text	\N	t	The street address of the account’s billing address	t	1	1	\N	Address	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":2490,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":20.85}}}	5	CHARACTER VARYING	\N	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	qtI01L_FrGxN93D5Vrb23
30	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	SOURCE	type/Text	type/Source	t	The channel through which we acquired this user. Valid values include: Affiliate, Facebook, Google, Organic and Twitter	t	8	1	\N	Source	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":5,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":7.4084}}}	5	CHARACTER VARYING	auto-list	\N	8	0	type/Text	\N	\N	f	f	f	f	\N	f	KBhAD3AND8jvX0nJf4Ksq
67	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	REVIEWER	type/Text	\N	t	The user who left the review	t	2	4	\N	Reviewer	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1076,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.001798561151079137,"average-length":9.972122302158274}}}	5	CHARACTER VARYING	\N	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	RIP_4y0y5AxKIsv2PUtB_
69	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:12.702687+00	BODY	type/Text	type/Description	t	The review the user left. Limited to 2000 characters.	t	4	4	\N	Body	normal	\N	2025-04-13 06:23:57.296644+00	\N	\N	{"global":{"distinct-count":1112,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":177.41996402877697}}}	5	CHARACTER VARYING	\N	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	xs9WF-awo7JBOkRtoa_dq
95	2025-04-13 06:25:41.383407+00	2025-04-13 06:59:52.159256+00	total_tickets	type/BigInteger	type/Category	t	\N	t	1	16	\N	Total Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/Number":{"min":175.0,"q1":175.0,"q3":5475.0,"max":5475.0,"sd":3747.6659402887017,"avg":2825.0}}}	5	int8	auto-list	\N	1	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	EJlmJ2cH23N5EdLWwKvr1
94	2025-04-13 06:25:41.383407+00	2025-04-13 06:59:52.159256+00	month	type/DateTime	\N	t	\N	t	0	16	\N	Month	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2023-05-01T00:00:00Z","latest":"2023-06-01T00:00:00Z"}}}	5	timestamp	\N	\N	0	0	type/DateTime	\N	\N	f	f	f	f	\N	f	7MKz2mUSKEgQ3PxOtTQD2
93	2025-04-13 06:25:41.383407+00	2025-04-13 06:59:52.159256+00	unique_customers	type/BigInteger	type/Category	t	\N	t	4	16	\N	Unique Customers	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/Number":{"min":175.0,"q1":175.0,"q3":5418.0,"max":5418.0,"sd":3707.3608537610685,"avg":2796.5}}}	5	int8	auto-list	\N	4	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	CZB7jm50PTmquXP1_nfsc
97	2025-04-13 06:25:41.383407+00	2025-04-13 06:59:52.159256+00	closed_tickets	type/BigInteger	type/Category	t	\N	t	2	16	\N	Closed Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/Number":{"min":80.0,"q1":80.0,"q3":2689.0,"max":2689.0,"sd":1844.8415921157025,"avg":1384.5}}}	5	int8	auto-list	\N	2	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	nDqvbK9w9ASarZLL0whH7
96	2025-04-13 06:25:41.383407+00	2025-04-13 06:59:52.159256+00	avg_satisfaction	type/Float	\N	t	\N	t	3	16	\N	Avg Satisfaction	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/Number":{"min":2.9899590925994795,"q1":2.9899590925994795,"q3":3.0375,"max":3.0375,"sd":0.03361649800666986,"avg":3.0137295462997398}}}	5	float8	\N	\N	3	0	type/Float	\N	\N	f	f	f	f	\N	f	zkh4HBCxBTo0zc-HSPTyR
120	2025-04-13 06:25:41.493721+00	2025-04-13 06:59:52.159256+00	ticket_count	type/BigInteger	type/Quantity	t	\N	t	1	17	\N	Ticket Count	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":2063.0,"q1":2074.0,"q3":2160.5,"max":2192.0,"sd":56.88804795385407,"avg":2117.25}}}	5	int8	auto-list	\N	1	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	ZGPjkQzCpbUxopqMBe2o2
119	2025-04-13 06:25:41.493721+00	2025-04-13 06:59:52.159256+00	percentage	type/Decimal	type/Share	t	\N	t	2	17	\N	Percentage	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":24.36,"q1":24.490000000000002,"q3":25.509999999999998,"max":25.88,"sd":0.6703233050799687,"avg":25.0}}}	5	numeric	\N	\N	2	0	type/Decimal	\N	\N	f	f	f	f	\N	f	_t-g94IETI4w4IN5mU-9J
86	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_id	type/Integer	type/PK	t	\N	t	0	10	\N	Ticket ID	normal	\N	\N	\N	\N	\N	0	int4	\N	\N	0	0	type/Integer	\N	\N	t	f	f	t	\N	f	StQgwmUZ6bAYWvzR6C8EU
77	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	customer_satisfaction_rating	type/Float	type/Score	t	\N	t	16	10	\N	Customer Satisfaction Rating	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":6,"nil%":0.6730428622033298},"type":{"type/Number":{"min":1.0,"q1":1.7538636906476484,"q3":4.226932322026869,"max":5.0,"sd":1.407015861799693,"avg":2.991332611050921}}}	5	float4	\N	\N	16	0	type/Float	\N	\N	f	f	f	f	\N	f	eqBFrh0vlfXft3x5jSAID
102	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	ticket_age	type/*	\N	t	\N	t	7	14	\N	Ticket Age	normal	\N	\N	\N	\N	\N	0	interval	auto-list	\N	7	0	type/*	\N	\N	f	f	f	f	\N	f	UM4scby-KYSfy5WAT3EG8
117	2025-04-13 06:25:41.470702+00	2025-04-13 06:59:50.163007+00	word	type/Text	\N	t	\N	t	0	11	\N	Word	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":50,"nil%":0.0},"type":{"type/Text":{"percent-json":0.06,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":7.0}}}	5	text	auto-list	\N	0	0	type/Text	\N	\N	f	f	f	f	\N	f	dA6hFh-ozMa4F7aQEZLmR
129	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	rated_tickets	type/BigInteger	type/Category	t	\N	t	6	9	\N	Rated Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":26,"nil%":0.0},"type":{"type/Number":{"min":47.0,"q1":60.732050807568875,"q3":72.0,"max":83.0,"sd":8.915300241562958,"avg":65.92857142857143}}}	5	int8	auto-list	\N	6	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	7vyQ9BdI3skSvTuNtj2eY
90	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	time_to_resolution	type/DateTime	\N	t	\N	t	15	10	\N	Time To Resolution	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2729,"nil%":0.6730428622033298},"type":{"type/DateTime":{"earliest":"2023-05-31T21:53:30Z","latest":"2023-06-02T00:55:33Z"}}}	5	timestamp	\N	\N	15	0	type/DateTime	\N	\N	f	f	f	f	\N	f	7uSfah_ICDLNZgexNhTAN
118	2025-04-13 06:25:41.470702+00	2025-04-13 06:59:50.163007+00	frequency	type/BigInteger	\N	t	\N	t	1	11	\N	Frequency	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":49,"nil%":0.0},"type":{"type/Number":{"min":619.0,"q1":708.0,"q3":1351.0,"max":10455.0,"sd":2306.359383026303,"avg":1793.22}}}	5	int8	auto-list	\N	1	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	XCt6Okm6_v08iA-_imlaW
79	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_status	type/Text	type/Category	t	\N	t	10	10	\N	Ticket Status	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":3,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":11.79773290825363}}}	5	varchar	auto-list	\N	10	0	type/Text	\N	\N	f	f	f	f	\N	f	Bnjax2Ezl7Ff5mUekthLi
80	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	customer_email	type/Text	type/Email	t	\N	t	2	10	\N	Customer Email	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":8319,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":1.0,"percent-state":0.0,"average-length":21.80186562758295}}}	5	varchar	auto-list	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	WQwTgvxQ_sujtOKOq4_xZ
78	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	date_of_purchase	type/Date	\N	t	\N	t	6	10	\N	Date Of Purchase	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":730,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2020-01-01","latest":"2021-12-30"}}}	5	date	\N	\N	6	0	type/Date	\N	\N	f	f	f	f	\N	f	ECh9yHzrudetrE8HgE11Q
85	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_description	type/Text	type/Description	t	\N	t	9	10	\N	Ticket Description	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":8078,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":289.82205691344905}}}	5	text	auto-list	\N	9	0	type/Text	\N	\N	f	f	f	f	\N	f	KzIxSJO244J1DfcMdeAKZ
89	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_type	type/Text	type/Category	t	\N	t	7	10	\N	Ticket Type	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":5,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":15.79383634431456}}}	5	varchar	auto-list	\N	7	0	type/Text	\N	\N	f	f	f	f	\N	f	8bjwScRKe_bv-_VWNbJ9A
81	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	product_purchased	type/Text	\N	t	\N	t	5	10	\N	Product Purchased	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":42,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":14.256464753808006}}}	5	varchar	auto-list	\N	5	0	type/Text	\N	\N	f	f	f	f	\N	f	YmTSTpT6AcQdHrVEyRRi_
82	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	first_response_time	type/DateTime	\N	t	\N	t	14	10	\N	First Response Time	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":5471,"nil%":0.3328610225528398},"type":{"type/DateTime":{"earliest":"2023-05-31T21:55:39Z","latest":"2023-06-02T00:54:21Z"}}}	5	timestamp	\N	\N	14	0	type/DateTime	\N	\N	f	f	f	f	\N	f	S2Fg6dBzUcD5CqzxnUYXM
83	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	customer_age	type/Integer	\N	t	\N	t	3	10	\N	Customer Age	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":53,"nil%":0.0},"type":{"type/Number":{"min":18.0,"q1":30.698453813633357,"q3":57.15715519367756,"max":70.0,"sd":15.296112498882382,"avg":44.02680363679301}}}	5	int4	auto-list	\N	3	0	type/Integer	\N	\N	f	f	f	f	\N	f	aU-ezpIYuvT7RDjXv_7yp
84	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	resolution	type/Text	\N	t	\N	t	11	10	\N	Resolution	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2770,"nil%":0.6730428622033298},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":11.704451529106151}}}	5	text	auto-list	\N	11	0	type/Text	\N	\N	f	f	f	f	\N	f	7VkXTEwq-AjSl20Y2fnTO
91	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_subject	type/Text	type/Category	t	\N	t	8	10	\N	Ticket Subject	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":16,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":15.724878970362498}}}	5	varchar	auto-list	\N	8	0	type/Text	\N	\N	f	f	f	f	\N	f	X5CRA01BVsHYdRsIexu4r
87	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	customer_name	type/Text	\N	t	\N	t	1	10	\N	Customer Name	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":8028,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":13.209469831148896}}}	5	varchar	auto-list	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	aroYOwTYsRlGaWa3DCMy2
88	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_channel	type/Text	type/Source	t	\N	t	13	10	\N	Ticket Channel	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":6.508324477506199}}}	5	varchar	auto-list	\N	13	0	type/Text	\N	\N	f	f	f	f	\N	f	CMSiKvqydpKV8uqAsaAuI
92	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	customer_gender	type/Text	type/Category	t	\N	t	4	10	\N	Customer Gender	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":3,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":4.998937300743889}}}	5	varchar	auto-list	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	D6GMlB5AYtWaVuyY_ufAD
76	2025-04-13 06:25:41.355852+00	2025-04-13 06:59:50.163007+00	ticket_priority	type/Text	type/Category	t	\N	t	12	10	\N	Ticket Priority	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.27960798205219}}}	5	varchar	auto-list	\N	12	0	type/Text	\N	\N	f	f	f	f	\N	f	HO5vlCxElcv2yQ70ZZEBk
127	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	product_purchased	type/Text	\N	t	\N	t	0	9	\N	Product Purchased	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":42,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":14.30952380952381}}}	5	varchar	auto-list	\N	0	0	type/Text	\N	\N	f	f	f	f	\N	f	f-SYIs66VdWgYKT82Dag0
132	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	pending_tickets	type/BigInteger	type/Category	t	\N	t	4	9	\N	Pending Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":19,"nil%":0.0},"type":{"type/Number":{"min":56.0,"q1":64.30574582323392,"q3":72.25,"max":87.0,"sd":6.796912942776602,"avg":68.5952380952381}}}	5	int8	auto-list	\N	4	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	6CrqtAZLFH402oOVEhUDK
131	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	avg_satisfaction	type/Float	\N	t	\N	t	5	9	\N	Avg Satisfaction	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":40,"nil%":0.0},"type":{"type/Number":{"min":2.5396825396825395,"q1":2.8870967741935485,"q3":3.1296296296296298,"max":3.2203389830508473,"sd":0.16471687941451232,"avg":2.9888697878607213}}}	5	float8	\N	\N	5	0	type/Float	\N	\N	f	f	f	f	\N	f	qCgy_K2pjAMzXwVhXCaKA
128	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	open_tickets	type/BigInteger	type/Category	t	\N	t	3	9	\N	Open Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":21,"nil%":0.0},"type":{"type/Number":{"min":49.0,"q1":61.56155281280883,"q3":72.0,"max":90.0,"sd":8.169551980289539,"avg":67.1190476190476}}}	5	int8	auto-list	\N	3	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	UYDTAo4EQ1hWORauZFQHe
133	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	closed_tickets	type/BigInteger	type/Category	t	\N	t	2	9	\N	Closed Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":26,"nil%":0.0},"type":{"type/Number":{"min":47.0,"q1":60.732050807568875,"q3":72.0,"max":83.0,"sd":8.915300241562958,"avg":65.92857142857143}}}	5	int8	auto-list	\N	2	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	f6wdIhguHxNjOh2yy4NBs
130	2025-04-13 06:25:41.552239+00	2025-04-13 06:59:50.163007+00	total_tickets	type/BigInteger	type/Category	t	\N	t	1	9	\N	Total Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":30,"nil%":0.0},"type":{"type/Number":{"min":178.0,"q1":190.26794919243113,"q3":212.0,"max":240.0,"sd":14.169395788229092,"avg":201.64285714285714}}}	5	int8	auto-list	\N	1	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	DwctDu_C00bq91tgY3jR0
107	2025-04-13 06:25:41.425331+00	2025-04-13 06:59:50.163007+00	ticket_date	type/Date	\N	t	\N	t	3	12	\N	Ticket Date	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":3,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2023-05-31","latest":"2023-06-02"}}}	5	date	\N	\N	3	0	type/Date	\N	\N	f	f	f	f	\N	f	lwJ1jHIAFJ0S4eqcO487k
109	2025-04-13 06:25:41.425331+00	2025-04-13 06:59:50.163007+00	date_of_purchase	type/Date	\N	t	\N	t	2	12	\N	Date Of Purchase	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":730,"nil%":0.0},"type":{"type/DateTime":{"earliest":"2020-01-01","latest":"2021-12-30"}}}	5	date	\N	\N	2	0	type/Date	\N	\N	f	f	f	f	\N	f	p7HLkNXt0B-Fv08w8wvhG
111	2025-04-13 06:25:41.425331+00	2025-04-13 06:59:50.163007+00	ticket_id	type/Integer	\N	t	\N	t	0	12	\N	Ticket ID	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":5650,"nil%":0.0},"type":{"type/Number":{"min":1.0,"q1":2131.421174377931,"q3":6345.118602644449,"max":8468.0,"sd":2447.013813424222,"avg":4230.895752212389}}}	5	int4	auto-list	\N	0	0	type/Integer	\N	\N	f	f	f	f	\N	f	dbbyQWnqSKZPdiTJ0XrRK
108	2025-04-13 06:25:41.425331+00	2025-04-13 06:59:50.163007+00	days_since_purchase	type/Integer	\N	t	\N	t	4	12	\N	Days Since Purchase	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":730,"nil%":0.0},"type":{"type/Number":{"min":518.0,"q1":700.6128511876647,"q3":1068.115001325447,"max":1247.0,"sd":211.85739756175943,"avg":884.2051327433628}}}	5	int4	auto-list	\N	4	0	type/Integer	\N	\N	f	f	f	f	\N	f	3CuEYj8tyRdV_v5OoNdqC
110	2025-04-13 06:25:41.425331+00	2025-04-13 06:59:50.163007+00	product_purchased	type/Text	\N	t	\N	t	1	12	\N	Product Purchased	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":42,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":14.147256637168141}}}	5	varchar	auto-list	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	IepiweRO7sKn7Nq9vuLaQ
115	2025-04-13 06:25:41.448364+00	2025-04-13 06:59:50.163007+00	avg_hours_to_resolve	type/Decimal	\N	t	\N	t	2	13	\N	Avg Hours To Resolve	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":-0.3078530259365994,"q1":-0.2542708655853796,"q3":0.1582023001923557,"max":0.3852225672877847,"sd":0.30493311378435906,"avg":-0.04803428269651194}}}	5	numeric	\N	\N	2	0	type/Decimal	\N	\N	f	f	f	f	\N	f	o7JrmkRi18hCj3PZ6hEuZ
114	2025-04-13 06:25:41.448364+00	2025-04-13 06:59:50.163007+00	min_hours_to_resolve	type/Decimal	\N	t	\N	t	3	13	\N	Min Hours To Resolve	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":-23.233333333333334,"q1":-22.96666666666667,"q3":-22.483333333333334,"max":-22.3,"sd":0.3842983023449171,"avg":-22.725}}}	5	numeric	\N	\N	3	0	type/Decimal	\N	\N	f	f	f	f	\N	f	gepLU3NbF4nXpipEn2ZIH
116	2025-04-13 06:25:41.448364+00	2025-04-13 06:59:50.163007+00	max_hours_to_resolve	type/Decimal	\N	t	\N	t	4	13	\N	Max Hours To Resolve	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":22.616666666666667,"q1":22.741666666666667,"q3":23.291666666666664,"max":23.466666666666665,"sd":0.36285901761795314,"avg":23.016666666666666}}}	5	numeric	\N	\N	4	0	type/Decimal	\N	\N	f	f	f	f	\N	f	PwVVeomkc3hnl4bKTsjow
112	2025-04-13 06:25:41.448364+00	2025-04-13 06:59:50.163007+00	closed_tickets	type/BigInteger	type/Category	t	\N	t	1	13	\N	Closed Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":644.0,"q1":669.0,"q3":715.5,"max":726.0,"sd":34.79822792423009,"avg":692.25}}}	5	int8	auto-list	\N	1	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	am-FpElOpih6tQL3jnSGk
113	2025-04-13 06:25:41.448364+00	2025-04-13 06:59:50.163007+00	ticket_priority	type/Text	type/Category	t	\N	t	0	13	\N	Ticket Priority	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.25}}}	5	varchar	auto-list	\N	0	0	type/Text	\N	\N	f	f	f	f	\N	f	syqDCL2Ku2dqUt-iDrC1y
98	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	customer_name	type/Text	\N	t	\N	t	1	14	\N	Customer Name	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":5488,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":13.178070175438597}}}	5	varchar	auto-list	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	gT58_kQU-UOGsy52EBjp4
100	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	product_purchased	type/Text	\N	t	\N	t	2	14	\N	Product Purchased	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":42,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":14.32859649122807}}}	5	varchar	auto-list	\N	2	0	type/Text	\N	\N	f	f	f	f	\N	f	_YCqWShTMN1fG2dnqIHfu
105	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	ticket_status	type/Text	type/Category	t	\N	t	8	14	\N	Ticket Status	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":14.614210526315789}}}	5	varchar	auto-list	\N	8	0	type/Text	\N	\N	f	f	f	f	\N	f	af56sogO8sJjCxGP-p78Z
99	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	first_response_time	type/DateTime	\N	t	\N	t	6	14	\N	First Response Time	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":2829,"nil%":0.4945614035087719},"type":{"type/DateTime":{"earliest":"2023-05-31T22:01:53Z","latest":"2023-06-02T00:51:07Z"}}}	5	timestamp	\N	\N	6	0	type/DateTime	\N	\N	f	f	f	f	\N	f	-m4UJlnx-y9qvT0l44Ehk
101	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	ticket_id	type/Integer	\N	t	\N	t	0	14	\N	Ticket ID	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":5700,"nil%":0.0},"type":{"type/Number":{"min":1.0,"q1":2102.183169947527,"q3":6369.13369314407,"max":8469.0,"sd":2443.896883984718,"avg":4233.948947368421}}}	5	int4	auto-list	\N	0	0	type/Integer	\N	\N	f	f	f	f	\N	f	_ZZ6xB3IMLPZTX99IsQ93
106	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	ticket_priority	type/Text	type/Category	t	\N	t	4	14	\N	Ticket Priority	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.261228070175439}}}	5	varchar	auto-list	\N	4	0	type/Text	\N	\N	f	f	f	f	\N	f	BRvAnnJ6rPYiCm80pt8Gq
103	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	ticket_channel	type/Text	type/Source	t	\N	t	5	14	\N	Ticket Channel	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":6.519298245614035}}}	5	varchar	auto-list	\N	5	0	type/Text	\N	\N	f	f	f	f	\N	f	QBoZTXi3E-34Z6nwN9OTg
104	2025-04-13 06:25:41.405402+00	2025-04-13 06:59:50.163007+00	ticket_subject	type/Text	type/Category	t	\N	t	3	14	\N	Ticket Subject	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":16,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":15.71140350877193}}}	5	varchar	auto-list	\N	3	0	type/Text	\N	\N	f	f	f	f	\N	f	rETx06UrUwEGYpRzf1DKO
122	2025-04-13 06:25:41.522814+00	2025-04-13 06:59:50.163007+00	avg_satisfaction	type/Float	\N	t	\N	t	4	15	\N	Avg Satisfaction	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":2.952243125904486,"q1":2.9580660073966873,"q3":3.026192149513249,"max":3.083086053412463,"sd":0.06105411735833596,"avg":2.9921290784549686}}}	5	float8	\N	\N	4	0	type/Float	\N	\N	f	f	f	f	\N	f	T0Ki_gYnOoqCh-vohylMG
125	2025-04-13 06:25:41.522814+00	2025-04-13 06:59:50.163007+00	ticket_channel	type/Text	type/Source	t	\N	t	0	15	\N	Ticket Channel	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":6.5}}}	5	varchar	auto-list	\N	0	0	type/Text	\N	\N	f	f	f	f	\N	f	BUbSCeTNbgAQOoBtYHCo_
123	2025-04-13 06:25:41.522814+00	2025-04-13 06:59:50.163007+00	total_tickets	type/BigInteger	type/Category	t	\N	t	1	15	\N	Total Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":2073.0,"q1":2097.0,"q3":2137.5,"max":2143.0,"sd":30.836936726378426,"avg":2117.25}}}	5	int8	auto-list	\N	1	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	bLDMOMX-sVMrdSpMBJ52r
124	2025-04-13 06:25:41.522814+00	2025-04-13 06:59:50.163007+00	unique_customers	type/BigInteger	type/Category	t	\N	t	2	15	\N	Unique Customers	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":2062.0,"q1":2088.5,"q3":2126.5,"max":2134.0,"sd":31.416556144810016,"avg":2107.5}}}	5	int8	auto-list	\N	2	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	O3xMVuJkWzkVjnZHPPcan
126	2025-04-13 06:25:41.522814+00	2025-04-13 06:59:50.163007+00	closed_tickets	type/BigInteger	type/Category	t	\N	t	3	15	\N	Closed Tickets	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Number":{"min":674.0,"q1":679.0,"q3":705.5,"max":720.0,"sd":19.771612647092464,"avg":692.25}}}	5	int8	auto-list	\N	3	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	KwA1F2Xu7ZYiKaLSofk5W
121	2025-04-13 06:25:41.493721+00	2025-04-13 06:59:52.159256+00	ticket_priority	type/Text	type/Category	t	\N	t	0	17	\N	Ticket Priority	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":4,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.25}}}	5	varchar	auto-list	\N	0	0	type/Text	\N	\N	f	f	f	f	\N	f	tJALfCKu_z5odOLaAYF4d
72	2025-04-13 06:25:41.323992+00	2025-04-13 06:59:52.159256+00	customer_gender	type/Text	type/Category	t	\N	t	1	18	\N	Customer Gender	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":3,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":5.0}}}	5	varchar	auto-list	\N	1	0	type/Text	\N	\N	f	f	f	f	\N	f	m-YkFI6Zetn84NWtCJ6sx
73	2025-04-13 06:25:41.323992+00	2025-04-13 06:59:52.159256+00	age_group	type/Text	type/Category	t	\N	t	0	18	\N	Age Group	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":6,"nil%":0.0},"type":{"type/Text":{"percent-json":0.0,"percent-url":0.0,"percent-email":0.0,"percent-state":0.0,"average-length":4.666666666666667}}}	5	text	auto-list	\N	0	0	type/Text	\N	\N	f	f	f	f	\N	f	A7bus1HODx8Hh_c6EbdsP
74	2025-04-13 06:25:41.323992+00	2025-04-13 06:59:52.159256+00	customer_count	type/BigInteger	type/Quantity	t	\N	t	2	18	\N	Customer Count	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":16,"nil%":0.0},"type":{"type/Number":{"min":306.0,"q1":382.0,"q3":545.5,"max":564.0,"sd":94.91311816603645,"avg":470.5}}}	5	int8	auto-list	\N	2	0	type/BigInteger	\N	\N	f	f	f	f	\N	f	E4VFKWE7cwe46vic_sTPA
75	2025-04-13 06:25:41.323992+00	2025-04-13 06:59:52.159256+00	avg_satisfaction	type/Float	\N	t	\N	t	3	18	\N	Avg Satisfaction	normal	\N	2025-04-13 06:25:43.889867+00	\N	\N	{"global":{"distinct-count":18,"nil%":0.0},"type":{"type/Number":{"min":2.77,"q1":2.9448818897637796,"q3":3.036842105263158,"max":3.175925925925926,"sd":0.10124851563217349,"avg":2.986749012410535}}}	5	float8	\N	\N	3	0	type/Float	\N	\N	f	f	f	f	\N	f	NMfCwanGDMoRHwmmq5a33
\.


--
-- Data for Name: metabase_fieldvalues; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metabase_fieldvalues (id, created_at, updated_at, "values", human_readable_values, field_id, has_more_values, type, hash_key, last_used_at) FROM stdin;
\.


--
-- Data for Name: metabase_table; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metabase_table (id, created_at, updated_at, name, description, entity_type, active, db_id, display_name, visibility_type, schema, points_of_interest, caveats, show_in_getting_started, field_order, initial_sync_status, is_upload, database_require_filter, estimated_row_count, view_count, entity_id) FROM stdin;
8	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	INVOICES	Confirmed payments from Piespace’s customers. Most accounts pay for their pie subscription on a monthly basis.	entity/GenericTable	t	1	Invoices	\N	PUBLIC	Is it? We’ll let you be the judge of that.	You can group by “Account ID” to see all the payments from an account and unveil information like total amount paid to date.	f	database	complete	f	\N	\N	0	X7X-614d1rZLwsJwsBCDq
6	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	ACCOUNTS	Information on customer accounts registered with Piespace. Each account represents a new organization signing up for on-demand pies.	entity/UserTable	t	1	Accounts	\N	PUBLIC	Is it? We’ll let you be the judge of that.	Piespace’s business operates with a two week trial period. If you see that “Canceled At” is null then that account is still happily paying for their pies.	f	database	complete	f	\N	\N	0	lq5O4PSCQOudlilZp-7BF
7	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	ANALYTIC_EVENTS	Piespace does some anonymous analytics tracking on how users interact with their platform. They’ve only had time to implement a few events, but you know how it is. Pies come first.	entity/EventTable	t	1	Analytic Events	\N	PUBLIC	Is it? We’ll let you be the judge of that.	Piespace has cracked time travel, so keep in mind that some events may have already happened in the future.	f	database	complete	f	\N	\N	0	aaXginMuYtidP-nue_hya
5	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	FEEDBACK	With each order of pies sent out, Piespace includes a place for customers to submit feedback and review their order.	entity/GenericTable	t	1	Feedback	\N	PUBLIC	Is it? We’ll let you be the judge of that.	Not every account feels inclined to submit feedback. That’s cool. There’s still quite a few responses here.	f	database	complete	f	\N	\N	0	uaSri_JcDWanWvvq8YvOz
3	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	PRODUCTS	Includes a catalog of all the products ever sold by the famed Sample Company.	entity/ProductTable	t	1	Products	\N	PUBLIC	Is it? You tell us!	The rating column is an integer from 1-5 where 1 is dreadful and 5 is the best thing ever.	f	database	complete	f	\N	\N	0	AtInDz5nnYYKEcy55J9hu
2	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	ORDERS	Confirmed Sample Company orders for a product, from a user.	entity/TransactionTable	t	1	Orders	\N	PUBLIC	Is it? You tell us!	You can join this on the Products and Orders table using the ID fields. Discount is left null if not applicable.	f	database	complete	f	\N	\N	0	USIEms7WZPOnUVkhp8vNj
1	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	PEOPLE	Information on the user accounts registered with Sample Company.	entity/UserTable	t	1	People	\N	PUBLIC	Is it? You tell us!	Note that employees and customer support staff will have accounts.	f	database	complete	f	\N	\N	0	VyRfJ_FhWPeQRhr-mDU1j
4	2025-04-13 06:23:57.296644+00	2025-04-13 06:24:08.677389+00	REVIEWS	Reviews that Sample Company customers have left on our products.	entity/GenericTable	t	1	Reviews	\N	PUBLIC	Is it? You tell us!	These reviews aren't tied to orders so it is possible people have reviewed products they did not purchase from us.	f	database	complete	f	\N	\N	0	PPMvQ6oP2bF2httFxH_B1
13	2025-04-13 06:25:41.079206+00	2025-04-13 06:59:48.127517+00	resolution_time_stats	\N	entity/GenericTable	t	2	Resolution Time Stats	\N	public	\N	\N	f	database	complete	f	\N	\N	0	Mndpo4uTn0mSmz1eAZIe0
9	2025-04-13 06:25:40.933654+00	2025-04-13 06:59:48.127517+00	ticket_stats_by_product	\N	entity/ProductTable	t	2	Ticket Stats By Product	\N	public	\N	\N	f	database	complete	f	\N	\N	0	mm9dbFJYxvwl9GYFiMuEe
11	2025-04-13 06:25:41.023019+00	2025-04-13 06:59:48.127517+00	ticket_description_keywords	\N	entity/GenericTable	t	2	Ticket Description Keywords	\N	public	\N	\N	f	database	complete	f	\N	\N	0	SuWI-je8NHXm1Gx7jElSe
12	2025-04-13 06:25:41.051749+00	2025-04-13 06:59:48.127517+00	product_age_at_ticket	\N	entity/ProductTable	t	2	Product Age At Ticket	\N	public	\N	\N	f	database	complete	f	\N	\N	0	SG5CMR7P5iZVBYbeosOar
14	2025-04-13 06:25:41.106619+00	2025-04-13 06:59:48.127517+00	open_ticket_age	\N	entity/GenericTable	t	2	Open Ticket Age	\N	public	\N	\N	f	database	complete	f	\N	\N	0	rVLc0WsIpsf7WtyMx4LEE
15	2025-04-13 06:25:41.133448+00	2025-04-13 06:59:48.127517+00	ticket_stats_by_channel	\N	entity/GenericTable	t	2	Ticket Stats By Channel	\N	public	\N	\N	f	database	complete	f	\N	\N	0	dLDR9iUHgYH4MlMn_Xj3J
16	2025-04-13 06:25:41.161109+00	2025-04-13 06:59:48.127517+00	monthly_ticket_trends	\N	entity/GenericTable	t	2	Monthly Ticket Trends	\N	public	\N	\N	f	database	complete	f	\N	\N	0	spHVbDhlbufKwTKq3Sg69
17	2025-04-13 06:25:41.188138+00	2025-04-13 06:59:48.127517+00	ticket_priority_distribution	\N	entity/GenericTable	t	2	Ticket Priority Distribution	\N	public	\N	\N	f	database	complete	f	\N	\N	0	np-cFuSkmjX4Dj6JPRn0y
18	2025-04-13 06:25:41.217473+00	2025-04-13 06:59:48.127517+00	customer_demographics	\N	entity/GenericTable	t	2	Customer Demographics	\N	public	\N	\N	f	database	complete	f	\N	\N	0	iIf7DZVZ_TIZVQo5e-GAO
10	2025-04-13 06:25:40.995373+00	2025-04-13 06:59:48.127517+00	customer_tickets	\N	entity/GenericTable	t	2	Customer Tickets	\N	public	\N	\N	f	database	complete	f	\N	16938	0	ZUvOFzPJ1vpcLprAZ_fQv
\.


--
-- Data for Name: metric; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metric (id, table_id, creator_id, name, description, archived, definition, created_at, updated_at, points_of_interest, caveats, how_is_this_calculated, show_in_getting_started, entity_id) FROM stdin;
\.


--
-- Data for Name: metric_important_field; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.metric_important_field (id, metric_id, field_id) FROM stdin;
\.


--
-- Data for Name: model_index; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.model_index (id, model_id, pk_ref, value_ref, schedule, state, indexed_at, error, created_at, creator_id) FROM stdin;
\.


--
-- Data for Name: model_index_value; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.model_index_value (model_index_id, model_pk, name) FROM stdin;
\.


--
-- Data for Name: moderation_review; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.moderation_review (id, updated_at, created_at, status, text, moderated_item_id, moderated_item_type, moderator_id, most_recent) FROM stdin;
\.


--
-- Data for Name: native_query_snippet; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.native_query_snippet (id, name, description, content, creator_id, archived, created_at, updated_at, collection_id, entity_id) FROM stdin;
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.notification (id, payload_type, active, created_at, updated_at, internal_id, payload_id, creator_id) FROM stdin;
1	notification/system-event	t	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00	system-event/user-invited	\N	\N
2	notification/system-event	t	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00	system-event/alert-new-confirmation	\N	\N
3	notification/system-event	t	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00	system-event/slack-token-error	\N	\N
\.


--
-- Data for Name: notification_card; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.notification_card (id, card_id, send_once, send_condition, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_handler; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.notification_handler (id, channel_type, notification_id, channel_id, template_id, active, created_at, updated_at) FROM stdin;
1	channel/email	1	\N	1	t	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
2	channel/email	2	\N	2	t	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
3	channel/email	3	\N	3	t	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
\.


--
-- Data for Name: notification_recipient; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.notification_recipient (id, notification_handler_id, type, user_id, permissions_group_id, details, created_at, updated_at) FROM stdin;
1	1	notification-recipient/template	\N	\N	{"pattern":"{{payload.event_info.object.email}}"}	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
2	2	notification-recipient/template	\N	\N	{"pattern":"{{payload.event_info.object.creator.email}}"}	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
3	3	notification-recipient/template	\N	\N	{"pattern":"{{context.admin_email}}","is_optional":true}	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
4	3	notification-recipient/group	\N	2	\N	2025-04-13 06:24:07.246716+00	2025-04-13 06:24:07.246716+00
\.


--
-- Data for Name: notification_subscription; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.notification_subscription (id, notification_id, type, event_name, created_at, cron_schedule, ui_display_type) FROM stdin;
1	1	notification-subscription/system-event	event/user-invited	2025-04-13 06:24:07.246716+00	\N	\N
2	2	notification-subscription/system-event	event/notification-create	2025-04-13 06:24:07.246716+00	\N	\N
3	3	notification-subscription/system-event	event/slack-token-invalid	2025-04-13 06:24:07.246716+00	\N	\N
\.


--
-- Data for Name: parameter_card; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.parameter_card (id, updated_at, created_at, card_id, parameterized_object_type, parameterized_object_id, parameter_id) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.permissions (id, object, group_id, perm_value, perm_type, collection_id) FROM stdin;
1	/	2	\N	\N	\N
2	/collection/root/	1	\N	\N	\N
3	/application/subscription/	1	\N	\N	\N
4	/collection/namespace/snippets/root/	1	\N	\N	\N
5	/collection/1/	1	\N	\N	\N
6	/collection/2/	1	read-and-write	perms/collection-access	2
\.


--
-- Data for Name: permissions_group; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.permissions_group (id, name, entity_id) FROM stdin;
1	All Users	\N
2	Administrators	\N
\.


--
-- Data for Name: permissions_group_membership; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.permissions_group_membership (id, user_id, group_id, is_group_manager) FROM stdin;
1	13371338	1	f
2	1	1	f
3	1	2	f
\.


--
-- Data for Name: permissions_revision; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.permissions_revision (id, before, after, user_id, created_at, remark) FROM stdin;
\.


--
-- Data for Name: persisted_info; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.persisted_info (id, database_id, card_id, question_slug, table_name, definition, query_hash, active, state, refresh_begin, refresh_end, state_change_at, error, created_at, creator_id) FROM stdin;
\.


--
-- Data for Name: pulse; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.pulse (id, creator_id, name, created_at, updated_at, skip_if_empty, alert_condition, alert_first_only, alert_above_goal, collection_id, collection_position, archived, dashboard_id, parameters, entity_id) FROM stdin;
\.


--
-- Data for Name: pulse_card; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.pulse_card (id, pulse_id, card_id, "position", include_csv, include_xls, dashboard_card_id, entity_id, format_rows, pivot_results) FROM stdin;
\.


--
-- Data for Name: pulse_channel; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.pulse_channel (id, pulse_id, channel_type, details, schedule_type, schedule_hour, schedule_day, created_at, updated_at, schedule_frame, enabled, entity_id, channel_id) FROM stdin;
\.


--
-- Data for Name: pulse_channel_recipient; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.pulse_channel_recipient (id, pulse_channel_id, user_id) FROM stdin;
\.


--
-- Data for Name: qrtz_blob_triggers; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_blob_triggers (sched_name, trigger_name, trigger_group, blob_data) FROM stdin;
\.


--
-- Data for Name: qrtz_calendars; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_calendars (sched_name, calendar_name, calendar) FROM stdin;
\.


--
-- Data for Name: qrtz_cron_triggers; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_cron_triggers (sched_name, trigger_name, trigger_group, cron_expression, time_zone_id) FROM stdin;
MetabaseScheduler	metabase.task.update-field-values.trigger.1	DEFAULT	0 0 14 * * ? *	GMT
MetabaseScheduler	metabase.task.update-field-values.trigger.2	DEFAULT	0 0 11 * * ? *	GMT
MetabaseScheduler	metabase.task.upgrade-checks.trigger	DEFAULT	0 15 6,18 * * ? *	GMT
MetabaseScheduler	metabase.task.anonymous-stats.trigger	DEFAULT	0 4 1 * * ? *	GMT
MetabaseScheduler	metabase.task.refresh-channel-cache.trigger	DEFAULT	0 5 0/4 1/1 * ? *	GMT
MetabaseScheduler	metabase.task.truncate-audit-tables.trigger	DEFAULT	0 0 */12 * * ? *	GMT
MetabaseScheduler	metabase.task.session-cleanup.trigger	DEFAULT	0 0 2 * * ? *	GMT
MetabaseScheduler	metabase.task.follow-up-emails.trigger	DEFAULT	0 0 12 * * ? *	GMT
MetabaseScheduler	metabase.task.creator-sentiment-emails.trigger	DEFAULT	0 0 2 ? * 7	GMT
MetabaseScheduler	metabase.task.task-history-cleanup.trigger	DEFAULT	0 0 0 * * ? *	GMT
MetabaseScheduler	metabase.task.backfill-query-fields.trigger	DEFAULT	0 44 0/4 1/1 * ? *	GMT
MetabaseScheduler	metabase.task.sync-and-analyze.trigger.1	DEFAULT	0 43 * * * ? *	GMT
MetabaseScheduler	metabase.task.sync-and-analyze.trigger.2	DEFAULT	0 45 * * * ? *	GMT
\.


--
-- Data for Name: qrtz_fired_triggers; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_fired_triggers (sched_name, entry_id, trigger_name, trigger_group, instance_name, fired_time, sched_time, priority, state, job_name, job_group, is_nonconcurrent, requests_recovery) FROM stdin;
MetabaseScheduler	metabase17445275857041744527585694	metabase.task.analyze-queries.trigger	DEFAULT	metabase1744527585704	1744527586498	1744527585903	5	EXECUTING	metabase.task.analyze-queries.job	DEFAULT	t	f
\.


--
-- Data for Name: qrtz_job_details; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_job_details (sched_name, job_name, job_group, description, job_class_name, is_durable, is_nonconcurrent, is_update_data, requests_recovery, job_data) FROM stdin;
MetabaseScheduler	metabase.task.upgrade-checks.job	DEFAULT	\N	metabase.task.upgrade_checks.CheckForNewVersions	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.search-index.reindex.job	DEFAULT	\N	metabase.search.task.search_index.SearchIndexReindex	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.anonymous-stats.job	DEFAULT	\N	metabase.task.send_anonymous_stats.SendAnonymousUsageStats	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.refresh-channel-cache.job	DEFAULT	\N	metabase.task.refresh_slack_channel_user_cache.RefreshCache	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.analyze-queries.job	DEFAULT	\N	metabase.query_analysis.task.analyze_queries.QueryAnalyzer	f	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.truncate-audit-tables.job	DEFAULT	\N	metabase.task.truncate_audit_tables.TruncateAuditTables	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.send-pulses.init-send-pulse-triggers.job	DEFAULT	\N	metabase.pulse.task.send_pulses.InitSendPulseTriggers	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.notification.init-notification-triggers.job	DEFAULT	\N	metabase.notification.task.send.InitNotificationTriggers	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.email-remove-legacy-pulse.job	DEFAULT	\N	metabase.pulse.task.email_remove_legacy_pulse.EmailRemoveLegacyPulse	t	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.session-cleanup.job	DEFAULT	\N	metabase.session.task.session_cleanup.SessionCleanup	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.sync-and-analyze.job	DEFAULT	sync-and-analyze for all databases	metabase.sync.task.sync_databases.SyncAndAnalyzeDatabase	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.update-field-values.job	DEFAULT	update-field-values for all databases	metabase.sync.task.sync_databases.UpdateFieldValues	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.IndexValues.job	DEFAULT	Indexed Value Refresh task	metabase.indexed_entities.task.index_values.ModelIndexRefresh	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.send-pulses.send-pulse.job	DEFAULT	Send Pulse	metabase.pulse.task.send_pulses.SendPulse	t	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.PersistenceRefresh.job	DEFAULT	Persisted Model refresh task	metabase.model_persistence.task.persist_refresh.PersistenceRefresh	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.notification.send.job	DEFAULT	Send Notification	metabase.notification.task.send.SendNotification	t	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.search-index.init.job	DEFAULT	\N	metabase.search.task.search_index.SearchIndexInit	t	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.follow-up-emails.job	DEFAULT	\N	metabase.task.follow_up_emails.FollowUpEmail	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.creator-sentiment-emails.job	DEFAULT	\N	metabase.task.creator_sentiment_emails.CreatorSentimentEmail	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.task-history-cleanup.job	DEFAULT	\N	metabase.task.task_history_cleanup.TaskHistoryCleanup	f	f	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.backfill-query-fields.job	DEFAULT	\N	metabase.query_analysis.task.sweep_query_analysis.SweepQueryAnalysis	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
MetabaseScheduler	metabase.task.PersistencePrune.job	DEFAULT	Persisted Model prune task	metabase.model_persistence.task.persist_refresh.PersistencePrune	t	t	f	f	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f40000000000010770800000010000000007800
\.


--
-- Data for Name: qrtz_locks; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_locks (sched_name, lock_name) FROM stdin;
MetabaseScheduler	STATE_ACCESS
MetabaseScheduler	TRIGGER_ACCESS
\.


--
-- Data for Name: qrtz_paused_trigger_grps; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_paused_trigger_grps (sched_name, trigger_group) FROM stdin;
\.


--
-- Data for Name: qrtz_scheduler_state; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_scheduler_state (sched_name, instance_name, last_checkin_time, checkin_interval) FROM stdin;
MetabaseScheduler	metabase1744527585704	1744527743935	7500
\.


--
-- Data for Name: qrtz_simple_triggers; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_simple_triggers (sched_name, trigger_name, trigger_group, repeat_count, repeat_interval, times_triggered) FROM stdin;
MetabaseScheduler	metabase.task.search-index.reindex.trigger	DEFAULT	-1	3600000	0
MetabaseScheduler	metabase.task.analyze-queries.trigger	DEFAULT	0	60000	1
\.


--
-- Data for Name: qrtz_simprop_triggers; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_simprop_triggers (sched_name, trigger_name, trigger_group, str_prop_1, str_prop_2, str_prop_3, int_prop_1, int_prop_2, long_prop_1, long_prop_2, dec_prop_1, dec_prop_2, bool_prop_1, bool_prop_2) FROM stdin;
\.


--
-- Data for Name: qrtz_triggers; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.qrtz_triggers (sched_name, trigger_name, trigger_group, job_name, job_group, description, next_fire_time, prev_fire_time, priority, trigger_state, trigger_type, start_time, end_time, calendar_name, misfire_instr, job_data) FROM stdin;
MetabaseScheduler	metabase.task.update-field-values.trigger.2	DEFAULT	metabase.task.update-field-values.job	DEFAULT	update-field-values Database 2	1744542000000	-1	5	WAITING	CRON	1744525540000	0	\N	2	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f4000000000000c7708000000100000000174000564622d6964737200116a6176612e6c616e672e496e746567657212e2a0a4f781873802000149000576616c7565787200106a6176612e6c616e672e4e756d62657286ac951d0b94e08b0200007870000000027800
MetabaseScheduler	metabase.task.update-field-values.trigger.1	DEFAULT	metabase.task.update-field-values.job	DEFAULT	update-field-values Database 1	1744552800000	-1	5	WAITING	CRON	1744525444000	0	\N	2	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f4000000000000c7708000000100000000174000564622d6964737200116a6176612e6c616e672e496e746567657212e2a0a4f781873802000149000576616c7565787200106a6176612e6c616e672e4e756d62657286ac951d0b94e08b0200007870000000017800
MetabaseScheduler	metabase.task.upgrade-checks.trigger	DEFAULT	metabase.task.upgrade-checks.job	DEFAULT	\N	1744568100000	-1	5	WAITING	CRON	1744527585000	0	\N	0	\\x
MetabaseScheduler	metabase.task.search-index.reindex.trigger	DEFAULT	metabase.task.search-index.reindex.job	DEFAULT	\N	1744531185834	-1	5	WAITING	SIMPLE	1744531185834	0	\N	0	\\x
MetabaseScheduler	metabase.task.anonymous-stats.trigger	DEFAULT	metabase.task.anonymous-stats.job	DEFAULT	\N	1744592640000	-1	5	WAITING	CRON	1744527585000	0	\N	0	\\x
MetabaseScheduler	metabase.task.refresh-channel-cache.trigger	DEFAULT	metabase.task.refresh-channel-cache.job	DEFAULT	\N	1744531500000	-1	5	WAITING	CRON	1744527585000	0	\N	2	\\x
MetabaseScheduler	metabase.task.truncate-audit-tables.trigger	DEFAULT	metabase.task.truncate-audit-tables.job	DEFAULT	\N	1744545600000	-1	5	WAITING	CRON	1744527585000	0	\N	2	\\x
MetabaseScheduler	metabase.task.session-cleanup.trigger	DEFAULT	metabase.task.session-cleanup.job	DEFAULT	\N	1744596000000	-1	5	WAITING	CRON	1744527586000	0	\N	0	\\x
MetabaseScheduler	metabase.task.follow-up-emails.trigger	DEFAULT	metabase.task.follow-up-emails.job	DEFAULT	\N	1744545600000	-1	5	WAITING	CRON	1744527586000	0	\N	0	\\x
MetabaseScheduler	metabase.task.creator-sentiment-emails.trigger	DEFAULT	metabase.task.creator-sentiment-emails.job	DEFAULT	\N	1745028000000	-1	5	WAITING	CRON	1744527586000	0	\N	0	\\x
MetabaseScheduler	metabase.task.task-history-cleanup.trigger	DEFAULT	metabase.task.task-history-cleanup.job	DEFAULT	\N	1744588800000	-1	5	WAITING	CRON	1744527586000	0	\N	0	\\x
MetabaseScheduler	metabase.task.analyze-queries.trigger	DEFAULT	metabase.task.analyze-queries.job	DEFAULT	\N	-1	1744527585903	5	COMPLETE	SIMPLE	1744527585903	0	\N	0	\\x
MetabaseScheduler	metabase.task.backfill-query-fields.trigger	DEFAULT	metabase.task.backfill-query-fields.job	DEFAULT	\N	1744533840000	-1	5	WAITING	CRON	1744527586000	0	\N	2	\\x
MetabaseScheduler	metabase.task.sync-and-analyze.trigger.1	DEFAULT	metabase.task.sync-and-analyze.job	DEFAULT	sync-and-analyze Database 1	1744530180000	-1	5	WAITING	CRON	1744525444000	0	\N	2	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f4000000000000c7708000000100000000174000564622d6964737200116a6176612e6c616e672e496e746567657212e2a0a4f781873802000149000576616c7565787200106a6176612e6c616e672e4e756d62657286ac951d0b94e08b0200007870000000017800
MetabaseScheduler	metabase.task.sync-and-analyze.trigger.2	DEFAULT	metabase.task.sync-and-analyze.job	DEFAULT	sync-and-analyze Database 2	1744530300000	1744526700000	5	WAITING	CRON	1744525540000	0	\N	2	\\xaced0005737200156f72672e71756172747a2e4a6f62446174614d61709fb083e8bfa9b0cb020000787200266f72672e71756172747a2e7574696c732e537472696e674b65794469727479466c61674d61708208e8c3fbc55d280200015a0013616c6c6f77735472616e7369656e74446174617872001d6f72672e71756172747a2e7574696c732e4469727479466c61674d617013e62ead28760ace0200025a000564697274794c00036d617074000f4c6a6176612f7574696c2f4d61703b787000737200116a6176612e7574696c2e486173684d61700507dac1c31660d103000246000a6c6f6164466163746f724900097468726573686f6c6478703f4000000000000c7708000000100000000174000564622d6964737200116a6176612e6c616e672e496e746567657212e2a0a4f781873802000149000576616c7565787200106a6176612e6c616e672e4e756d62657286ac951d0b94e08b0200007870000000027800
\.


--
-- Data for Name: query; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query (query_hash, average_execution_time, query) FROM stdin;
\.


--
-- Data for Name: query_action; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query_action (action_id, database_id, dataset_query) FROM stdin;
\.


--
-- Data for Name: query_analysis; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query_analysis (id, card_id, created_at, updated_at, status) FROM stdin;
\.


--
-- Data for Name: query_cache; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query_cache (query_hash, updated_at, results) FROM stdin;
\.


--
-- Data for Name: query_execution; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query_execution (id, hash, started_at, running_time, result_rows, native, context, error, executor_id, card_id, dashboard_id, pulse_id, database_id, cache_hit, action_id, is_sandboxed, cache_hash, embedding_client, embedding_version, parameterized) FROM stdin;
\.


--
-- Data for Name: query_field; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query_field (id, card_id, field_id, explicit_reference, "column", "table", table_id, analysis_id, schema) FROM stdin;
\.


--
-- Data for Name: query_table; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.query_table (id, card_id, analysis_id, table_id, schema, "table") FROM stdin;
\.


--
-- Data for Name: recent_views; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.recent_views (id, user_id, model, model_id, "timestamp", context) FROM stdin;
\.


--
-- Data for Name: report_card; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.report_card (id, created_at, updated_at, name, description, display, dataset_query, visualization_settings, creator_id, database_id, table_id, query_type, archived, collection_id, public_uuid, made_public_by_id, enable_embedding, embedding_params, cache_ttl, result_metadata, collection_position, entity_id, parameters, parameter_mappings, collection_preview, metabase_version, type, initially_published_at, cache_invalidated_at, last_used_at, view_count, archived_directly, dataset_query_metrics_v2_migration_backup, source_card_id, dashboard_id) FROM stdin;
1	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Orders + People	Sample orders joined with products	table	{"database":1,"query":{"expressions":{"Age":["datetime-diff",["field",12,{"base-type":"type/Date","join-alias":"People - User"}],["now"],"year"]},"joins":[{"alias":"People - User","condition":["=",["field",11,{"base-type":"type/Integer"}],["field",4,{"base-type":"type/BigInteger","join-alias":"People - User"}]],"fields":[["field",7,{"base-type":"type/Text","join-alias":"People - User"}],["field",1,{"base-type":"type/Text","join-alias":"People - User"}]],"source-table":1,"strategy":"left-join"}],"source-table":2},"type":"query"}	{"column_settings":null,"table.cell_column":"SUBTOTAL","table.columns":[{"enabled":true,"name":"ID"},{"enabled":true,"name":"USER_ID"},{"enabled":true,"name":"PRODUCT_ID"},{"enabled":true,"name":"SUBTOTAL"},{"enabled":true,"name":"TAX"},{"enabled":true,"name":"TOTAL"},{"enabled":true,"name":"DISCOUNT"},{"enabled":true,"name":"CREATED_AT"},{"enabled":true,"name":"QUANTITY"},{"enabled":true,"name":"EMAIL"},{"enabled":true,"name":"Age"},{"enabled":true,"name":"STATE"}],"table.pivot_column":"SOURCE"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","coercion_strategy":null,"description":"This is a unique ID for the product. It is also called the “Invoice number” or “Confirmation number” in customer facing emails and screens.","display_name":"ID","effective_type":"type/BigInteger","field_ref":["field",9,null],"fk_target_field_id":null,"id":9,"name":"ID","semantic_type":"type/PK","settings":null,"visibility_type":"normal"},{"base_type":"type/Integer","coercion_strategy":null,"description":"The id of the user who made this order. Note that in some cases where an order was created on behalf of a customer who phoned the order in, this might be the employee who handled the request.","display_name":"User ID","effective_type":"type/Integer","field_ref":["field",11,null],"fk_target_field_id":4,"id":11,"name":"USER_ID","semantic_type":"type/FK","settings":null,"visibility_type":"normal"},{"base_type":"type/Integer","coercion_strategy":null,"description":"The product ID. This is an internal identifier for the product, NOT the SKU.","display_name":"Product ID","effective_type":"type/Integer","field_ref":["field",14,null],"fk_target_field_id":8,"id":14,"name":"PRODUCT_ID","semantic_type":"type/FK","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"The raw, pre-tax cost of the order. Note that this might be different in the future from the product price due to promotions, credits, etc.","display_name":"Subtotal","effective_type":"type/Float","field_ref":["field",10,null],"fk_target_field_id":null,"id":10,"name":"SUBTOTAL","semantic_type":"type/Currency","settings":{"view_as":null},"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"This is the amount of local and federal taxes that are collected on the purchase. Note that other governmental fees on some products are not included here, but instead are accounted for in the subtotal.","display_name":"Tax","effective_type":"type/Float","field_ref":["field",6,null],"fk_target_field_id":null,"id":6,"name":"TAX","semantic_type":"type/Currency","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"The total billed amount.","display_name":"Total","effective_type":"type/Float","field_ref":["field",5,null],"fk_target_field_id":null,"id":5,"name":"TOTAL","semantic_type":"type/Currency","settings":{"currency":"USD"},"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"Discount amount.","display_name":"Discount","effective_type":"type/Float","field_ref":["field",3,null],"fk_target_field_id":null,"id":3,"name":"DISCOUNT","semantic_type":"type/Discount","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At","effective_type":"type/DateTime","field_ref":["field",13,null],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"visibility_type":"normal"},{"base_type":"type/Integer","coercion_strategy":null,"description":"Number of products bought.","display_name":"Quantity","effective_type":"type/Integer","field_ref":["field",2,null],"fk_target_field_id":null,"id":2,"name":"QUANTITY","semantic_type":"type/Quantity","settings":{"show_mini_bar":false},"visibility_type":"normal"},{"base_type":"type/BigInteger","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/BigInteger","field_ref":["field","Age",{"base-type":"type/BigInteger"}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Text","coercion_strategy":null,"description":"The contact email for the account.","display_name":"Customer Email","effective_type":"type/Text","field_ref":["field",7,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":7,"name":"EMAIL","semantic_type":"type/Email","settings":{"link_text":""},"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The state or province of the account’s billing address.","display_name":"State","effective_type":"type/Text","field_ref":["field",1,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":1,"name":"STATE","semantic_type":"type/State","settings":null,"visibility_type":"normal"}]	1	_GiVL6zYmsnBb1oqLCp4u	[]	[]	t	\N	model	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
2	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue by state	Revenue in the US broken down by state	map	{"database":1,"query":{"aggregation":[["sum",["field","TOTAL",{"base-type":"type/Float"}]]],"breakout":[["field","STATE",{"base-type":"type/Text"}]],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"map.colors":["rgb(229, 229, 241)","rgb(192, 192, 218)","rgb(155, 155, 194)","rgb(118, 119, 171)","hsl(239, 29.5%, 39.3%)"],"map.region":"us_states","map.type":"region"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","description":"The state or province of the account’s billing address.","display_name":"State","effective_type":"type/Text","field_ref":["field","STATE",{"base-type":"type/Text"}],"id":1,"name":"STATE","semantic_type":"type/State","visibility_type":"normal"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}}]	\N	jjO5LcBp8qNILJFiYZoVt	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
3	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Customer satisfaction per category	Shows the distribution of the product categories along the scale of customer ratings	bar	{"database":1,"query":{"aggregation":[["count"]],"breakout":[["field",16,{"base-type":"type/Float","source-field":14}],["field",18,{"base-type":"type/Text","source-field":14}]],"filter":["!=",["field",17,{"base-type":"type/Text","source-field":14}],"Incredible Aluminum Knife"],"order-by":[["desc",["field",16,{"base-type":"type/Float","source-field":14,"binning":{"strategy":"default"}}]]],"source-table":2},"type":"query"}	{"column_settings":null,"graph.dimensions":["RATING","CATEGORY"],"graph.label_value_formatting":"compact","graph.metrics":["count"],"graph.show_values":true,"graph.x_axis.scale":"histogram","graph.x_axis.title_text":"","graph.y_axis.title_text":"","series_settings":{"Doohickey":{"color":"#7172AD"},"Gadget":{"color":"#999AC4"},"Gizmo":{"color":"#227FD2"},"Widget":{"color":"#C7EAEA"}},"stackable.stack_type":"stacked"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Float","coercion_strategy":null,"description":"The average rating users have given the product. This ranges from 1 - 5","display_name":"Product → Rating","effective_type":"type/Float","field_ref":["field",16,{"base-type":"type/Float","source-field":14}],"fk_target_field_id":null,"id":16,"name":"RATING","semantic_type":"type/Score","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	OJ-I03ZsQ7IBrzr29B_8o	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
4	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Product category orders per age group	Shows a distribution of orders broken down by product categories across our customers' age groups	bar	{"database":1,"query":{"aggregation":[["count"]],"breakout":[["field","Age",{"base-type":"type/BigInteger","binning":{"strategy":"num-bins","num-bins":10}}],["field",18,{"base-type":"type/Text","join-alias":"Products"}]],"joins":[{"alias":"Products","condition":["=",["field","PRODUCT_ID",{"base-type":"type/Integer"}],["field",8,{"base-type":"type/BigInteger","join-alias":"Products"}]],"source-table":3,"strategy":"left-join"}],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"graph.dimensions":["Age","CATEGORY"],"graph.metrics":["count"],"graph.show_values":true,"graph.x_axis.scale":"linear","stackable.stack_type":"stacked"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Decimal","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/Decimal","field_ref":["field","Age",{"base-type":"type/BigInteger","binning":{"strategy":"num-bins","num-bins":10,"min-value":20,"max-value":70,"bin-width":5}}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Products → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","join-alias":"Products"}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	WMub5k6vo0zGP24qXQFNu	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
5	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Customer survey responses	Feedback on our products via weekly survey	table	{"database":1,"query":{"filter":["time-interval",["field",27,{"base-type":"type/DateTime"}],-12,"month"],"order-by":[["desc",["field",27,{"base-type":"type/DateTime"}]]],"source-table":5},"type":"query"}	{"column_settings":{"[\\"name\\",\\"DATE_RECEIVED\\"]":{"date_abbreviate":true,"date_style":"dddd, MMMM D, YYYY","time_enabled":null}},"table.cell_column":"BODY","table.column_formatting":[{"color":"#F7C4C4","columns":["RATING"],"highlight_row":true,"id":2,"operator":"<","type":"single","value":3},{"color":"#FBE499","columns":["RATING"],"highlight_row":true,"id":1,"operator":"=","type":"single","value":3},{"color":"#A7D07C","colors":["#ED6E6E","#FFFFFF","#84BB4C"],"columns":["RATING"],"highlight_row":true,"id":0,"max_type":null,"max_value":100,"min_type":null,"min_value":0,"operator":">","type":"single","value":3}],"table.columns":[{"enabled":true,"name":"ID"},{"enabled":true,"name":"DATE_RECEIVED"},{"enabled":false,"name":"ACCOUNT_ID"},{"enabled":true,"name":"EMAIL"},{"enabled":true,"name":"RATING"},{"enabled":false,"name":"RATING_MAPPED"},{"enabled":true,"name":"BODY"}],"table.pivot_column":"RATING"}	13371338	1	5	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","coercion_strategy":null,"description":null,"display_name":"ID","effective_type":"type/BigInteger","field_ref":["field",20,null],"fk_target_field_id":null,"id":20,"name":"ID","semantic_type":"type/PK","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","coercion_strategy":null,"description":null,"display_name":"Account ID","effective_type":"type/BigInteger","field_ref":["field",25,null],"fk_target_field_id":24,"id":25,"name":"ACCOUNT_ID","semantic_type":"type/FK","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Email","effective_type":"type/Text","field_ref":["field",26,null],"fk_target_field_id":null,"id":26,"name":"EMAIL","semantic_type":"type/Email","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Date Received","effective_type":"type/DateTime","field_ref":["field",27,null],"fk_target_field_id":null,"id":27,"name":"DATE_RECEIVED","semantic_type":null,"settings":null,"visibility_type":"normal"},{"base_type":"type/Integer","coercion_strategy":null,"description":null,"display_name":"Rating","effective_type":"type/Integer","field_ref":["field",22,null],"fk_target_field_id":null,"id":22,"name":"RATING","semantic_type":"type/Score","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Rating Mapped","effective_type":"type/Text","field_ref":["field",23,null],"fk_target_field_id":null,"id":23,"name":"RATING_MAPPED","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Body","effective_type":"type/Text","field_ref":["field",28,null],"fk_target_field_id":null,"id":28,"name":"BODY","semantic_type":null,"settings":null,"visibility_type":"normal"}]	\N	Jxa0svP68DfXubV_wD3os	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
6	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Checkout funnel	Flow from viewing our website (empty) to checkout and subscribe	funnel	{"database":1,"query":{"filter":["not-empty",["field","BUTTON_LABEL",{"base-type":"type/Text"}]],"source-query":{"aggregation":[["count"]],"breakout":[["field",29,{"base-type":"type/Text"}]],"source-table":7}},"type":"query"}	{"column_settings":null,"funnel.order_dimension":"BUTTON_LABEL","funnel.rows":[{"enabled":true,"key":"Create Item","name":"Create Item"},{"enabled":true,"key":"Invite","name":"Invite"},{"enabled":true,"key":"Subscribe","name":"Subscribe"},{"enabled":true,"key":"Signup","name":"Signup"},{"enabled":true,"key":"Checkout","name":"Checkout"}]}	13371338	1	7	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Button Label","effective_type":"type/Text","field_ref":["field",29,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":29,"name":"BUTTON_LABEL","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["field","count",{"base-type":"type/Integer"}],"name":"count","semantic_type":"type/Quantity"}]	\N	UUZZsw19IuPTqdhho99oc	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
7	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Product breakdown	Orders for each product, grouped by product category	pie	{"database":1,"query":{"filter":[">=",["field","count",{"base-type":"type/Integer"}],105],"source-query":{"aggregation":[["count"]],"breakout":[["field",17,{"base-type":"type/Text","source-field":14}],["field",18,{"base-type":"type/Text","source-field":14}]],"source-table":2}},"type":"query"}	{"column_settings":null,"graph.dimensions":["TITLE"],"graph.metrics":["count"],"graph.series_order":null,"graph.series_order_dimension":null,"graph.show_values":true,"graph.x_axis.title_text":"","graph.y_axis.title_text":"","pie.decimal_places":2,"pie.dimension":["CATEGORY","TITLE","count"],"pie.percent_visibility":"legend","pie.rows":[{"color":"#51528D","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Doohickey","name":"Doohickey","originalName":"Doohickey"},{"color":"#8A5EB0","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Gadget","name":"Gadget","originalName":"Gadget"},{"color":"#69C8C8","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Gizmo","name":"Gizmo","originalName":"Gizmo"},{"color":"#227FD2","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Widget","name":"Widget","originalName":"Widget"}],"pie.slice_threshold":11,"pie.sort_rows":false,"series_settings":{"count":{"color":"#999AC4"}},"stackable.stack_type":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":"The name of the product as it should be displayed to customers.","display_name":"Product → Title","effective_type":"type/Text","field_ref":["field",17,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":17,"name":"TITLE","semantic_type":"type/Title","settings":{"link_url":"","view_as":null},"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["field","count",{"base-type":"type/Integer"}],"name":"count","semantic_type":"type/Quantity"}]	\N	RpKYsFwHfjcckbgj4oBKK	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
8	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Total order amount vs. discount given	Analysis of discounts given vs. the size of the order	scatter	{"database":1,"query":{"aggregation":[["sum",["field",5,{"base-type":"type/Float"}]],["sum",["field",3,{"base-type":"type/Float"}]],["count"]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],["field",2,{"base-type":"type/Integer","binning":{"strategy":"default"}}],["field",18,{"base-type":"type/Text","source-field":14}]],"source-table":2},"type":"query"}	{"column_settings":{"[\\"name\\",\\"sum_2\\"]":{"decimals":0}},"graph.dimensions":["sum","CATEGORY"],"graph.metrics":["sum_2"],"graph.series_order":null,"graph.series_order_dimension":null,"graph.show_trendline":false,"graph.tooltip_columns":["[\\"name\\",\\"count\\"]"],"graph.x_axis.title_text":"Total","graph.y_axis.title_text":"Discount","scatter.bubble":"count","series_settings":{"Doohickey":{"color":"#7172AD"},"Gadget":{"color":"#999AC4"},"Gizmo":{"color":"#C7EAEA"},"Widget":{"color":"#227FD2"},"sum_2":{"color":"#7172AD"}}}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/Decimal","coercion_strategy":null,"description":"Number of products bought.","display_name":"Quantity","effective_type":"type/Decimal","field_ref":["field",2,{"base-type":"type/Integer","binning":{"strategy":"num-bins","min-value":0.0,"max-value":100.0,"num-bins":8,"bin-width":12.5}}],"fk_target_field_id":null,"id":2,"name":"QUANTITY","semantic_type":"type/Quantity","settings":{"show_mini_bar":false},"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}},{"base_type":"type/Float","display_name":"Sum of Discount","effective_type":"type/Float","field_ref":["aggregation",1],"name":"sum_2","semantic_type":"type/Discount","settings":null},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",2],"name":"count","semantic_type":"type/Quantity"}]	\N	X8HNuB_i3j2uNFnsx3vQ0	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
9	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue	Canonical metric for revenue across all product lines	line	{"database":1,"query":{"aggregation":[["sum",["field",5,{"base-type":"type/Float"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-12,"quarter",{"include-current":true}],"source-table":2},"type":"query"}	{"column_settings":null,"graph.dimensions":["CREATED_AT"],"graph.metrics":["sum"]}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"active":true,"base_type":"type/DateTime","coercion_strategy":null,"database_type":"TIMESTAMP","description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","nfc_path":null,"parent_id":null,"position":7,"semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"source":"breakout","table_id":2,"unit":"quarter","visibility_type":"normal"},{"aggregation_index":0,"base_type":"type/Float","display_name":"Sum of Total","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"},"source":"aggregation"}]	\N	skXR69-dlhJST5C7Rd9nR	[]	[]	t	\N	metric	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
14	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Subscription seats over time	Number of seats in an average subscription, showing increase and decrease	waterfall	{"database":1,"query":{"filter":["time-interval",["field","CREATED_AT",{"base-type":"type/DateTime","inherited-temporal-unit":"year"}],-3,"year",{"include-current":true}],"source-query":{"aggregation":[["sum",["field",33,{"base-type":"type/Integer"}]]],"breakout":[["field",31,{"base-type":"type/DateTime","temporal-unit":"year","original-temporal-unit":"month"}]],"source-table":6}},"type":"query"}	{"column_settings":null,"graph.dimensions":["CREATED_AT"],"graph.metrics":["sum"],"graph.show_values":true,"graph.x_axis.title_text":"","graph.y_axis.title_text":""}	13371338	1	6	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Created At: Year","effective_type":"type/DateTime","field_ref":["field",31,{"base-type":"type/DateTime","original-temporal-unit":"month"}],"fk_target_field_id":null,"id":31,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":null,"unit":"year","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Sum of Seats","effective_type":"type/BigInteger","field_ref":["field","sum",{"base-type":"type/Integer"}],"name":"sum","semantic_type":null}]	\N	C8V7Dszig-vuqn9TP0igc	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
10	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Orders according to sources per quarter	Orders placed per quarter broken down by source and formatted to highlight best and worst quarters	pivot	{"database":1,"query":{"aggregation":[["metric",9]],"breakout":[["field",30,{"base-type":"type/Text","source-field":11}],["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-2,"year",{"include-current":true}],"source-table":2},"type":"query"}	{"column_settings":{"[\\"name\\",\\"CREATED_AT\\"]":{"column_title":"Date"}},"pivot_table.column_split":{"columns":["SOURCE"],"rows":["CREATED_AT"],"values":["sum"]},"pivot_table.column_widths":{"leftHeaderWidths":[135],"totalLeftHeaderWidths":135,"valueHeaderWidths":{"0":148,"1":158,"2":159,"3":144,"4":139,"5":124}},"table.column_formatting":[{"color":"#509EE3","colors":["white","#A7D07C"],"columns":["sum"],"highlight_row":false,"id":0,"max_type":null,"max_value":100,"min_type":null,"min_value":0,"operator":"=","type":"range","value":""}]}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Integer","coercion_strategy":null,"description":"The channel through which we acquired this user. Valid values include: Affiliate, Facebook, Google, Organic and Twitter","display_name":"pivot-grouping","effective_type":"type/Text","field_ref":["expression","pivot-grouping"],"fk_target_field_id":null,"id":30,"name":"SOURCE","semantic_type":null,"settings":null,"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Sum of Total","effective_type":"type/DateTime","field_ref":["aggregation",0],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/Currency","settings":{"time_enabled":"milliseconds"},"visibility_type":"normal"}]	\N	km2d9-ZqHrlAM79yPh13G	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
11	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	User flow diagram	Sankey flow from visiting our website to taking an action	sankey	{"database":1,"query":{"expressions":{"Step":["case",[[["is-null",["field","BUTTON_LABEL",{"base-type":"type/Text"}]],"Bounced"]],{"default":["field","BUTTON_LABEL",{"base-type":"type/Text"}]}]},"filter":["!=",["expression","Step",{"base-type":"type/Text"}],"Bounced"],"source-query":{"aggregation":[["count"]],"breakout":[["field",29,{"base-type":"type/Text"}],["field",32,{"base-type":"type/Text"}]],"source-table":7}},"type":"query"}	{"column_settings":null,"sankey.edge_color":"source","sankey.node_align":"right","sankey.show_edge_labels":true,"sankey.source":"EVENT","sankey.target":"Step"}	13371338	1	7	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Button Label","effective_type":"type/Text","field_ref":["field",29,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":29,"name":"BUTTON_LABEL","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Event","effective_type":"type/Text","field_ref":["field",32,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":32,"name":"EVENT","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["field","count",{"base-type":"type/Integer"}],"name":"count","semantic_type":"type/Quantity"},{"base_type":"type/Text","display_name":"Step","effective_type":"type/Text","field_ref":["expression","Step"],"name":"Step","semantic_type":null}]	\N	9VE9Z6tAkyzO3GeQVXtin	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
12	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue and orders over time	Cumulative revenue overlaid with number of orders placed each month	combo	{"database":1,"query":{"aggregation":[["metric",9],["sum",["field",2,{"base-type":"type/Integer"}]],["sum",["field",3,{"base-type":"type/Float"}]],["count"]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],["field",18,{"base-type":"type/Text","source-field":14}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-2,"year",{"include-current":true}],"source-table":2},"type":"query"}	{"column_settings":{},"graph.dimensions":["CREATED_AT"],"graph.label_value_formatting":"compact","graph.label_value_frequency":"fit","graph.metrics":["sum","sum_2"],"graph.series_order":null,"graph.series_order_dimension":null,"graph.show_trendline":false,"graph.show_values":true,"graph.tooltip_columns":["[\\"name\\",\\"count\\"]","[\\"name\\",\\"sum_3\\"]"],"graph.x_axis.title_text":"","graph.y_axis.title_text":"","series_settings":{"sum":{"color":"#88BF4D","line.interpolate":"linear","line.marker_enabled":false,"line.size":"L","line.style":"solid","title":"Revenue"},"sum_2":{"color":"#7172AD","title":"Orders"}},"stackable.stack_type":"stacked"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}},{"base_type":"type/BigInteger","display_name":"Sum of Quantity","effective_type":"type/BigInteger","field_ref":["aggregation",1],"name":"sum_2","semantic_type":"type/Quantity","settings":{"show_mini_bar":false}},{"base_type":"type/Float","display_name":"Sum of Discount","effective_type":"type/Float","field_ref":["aggregation",2],"name":"sum_3","semantic_type":"type/Discount","settings":null},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",3],"name":"count","semantic_type":"type/Quantity"}]	\N	VFCGVYPVtLzCtt4teeoW4	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
13	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue by product category	Monthly revenue broken down by products	bar	{"database":1,"query":{"aggregation":[["metric",9],["avg",["field",5,{"base-type":"type/Float"}]],["max",["field",5,{"base-type":"type/Float"}]],["sum",["field",3,{"base-type":"type/Float"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"month","original-temporal-unit":"quarter"}],["field",18,{"base-type":"type/Text","source-field":14}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-4,"month"],"source-table":2},"type":"query"}	{"column_settings":null,"graph.dimensions":["CREATED_AT","CATEGORY"],"graph.label_value_formatting":"compact","graph.metrics":["sum","avg","max","sum_2"],"graph.show_stack_values":"all","graph.show_values":true,"graph.tooltip_columns":["[\\"name\\",\\"sum_2\\"]","[\\"name\\",\\"avg\\"]","[\\"name\\",\\"max\\"]"],"graph.x_axis.title_text":"","graph.y_axis.title_text":"","series_settings":{"Doohickey":{"color":"#7172AD"},"Gadget":{"color":"#A989C5"},"Gizmo":{"color":"#C7EAEA"},"Widget":{"color":"#227FD2"}},"stackable.stack_type":"stacked"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Month","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"month","original-temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"month","visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}},{"base_type":"type/Float","display_name":"Average of Total","effective_type":"type/Float","field_ref":["aggregation",1],"name":"avg","semantic_type":"type/Currency","settings":{"currency":"USD"}},{"base_type":"type/Float","display_name":"Max of Total","effective_type":"type/Float","field_ref":["aggregation",2],"name":"max","semantic_type":"type/Currency","settings":{"currency":"USD"}},{"base_type":"type/Float","display_name":"Sum of Discount","effective_type":"type/Float","field_ref":["aggregation",3],"name":"sum_2","semantic_type":"type/Discount","settings":null}]	\N	-6yAP_G1UZ7xZc4E65Tvy	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
15	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue per quarter	Total revenue last quarter compared to the previous	smartscalar	{"database":1,"query":{"aggregation":[["metric",9]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}]],"source-table":2},"type":"query"}	{"column_settings":null,"scalar.comparisons":[{"id":"a8d008d4-d8f1-cbc1-b0ad-f4ab30791b9e","type":"previousPeriod"},{"id":"e7fa0d15-867c-2628-dbea-9f9a41e3ca38","type":"periodsAgo","value":4}]}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}}]	\N	D4o8cCTOY-SnxoYDRVWcO	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
16	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Number of subscriptions	Customers that signed up for our monthly subscription	area	{"database":1,"query":{"filter":["=",["field","BUTTON_LABEL",{"base-type":"type/Text"}],"Subscribe"],"source-query":{"aggregation":[["count"]],"breakout":[["field",29,{"base-type":"type/Text"}],["field",35,{"base-type":"type/DateTime","temporal-unit":"month"}]],"source-table":7}},"type":"query"}	{"column_settings":null,"graph.dimensions":["TIMESTAMP"],"graph.metrics":["count"],"graph.series_order":null,"graph.series_order_dimension":null,"graph.show_trendline":true,"graph.show_values":true,"graph.x_axis.title_text":"","graph.y_axis.title_text":"","scalar.field":"count","series_settings":{"Subscribe":{"color":"#7172AD","line.interpolate":"linear","title":"Subscriptions"},"count":{"color":"#7172AD"}}}	13371338	1	7	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Button Label","effective_type":"type/Text","field_ref":["field",29,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":29,"name":"BUTTON_LABEL","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Timestamp: Month","effective_type":"type/DateTime","field_ref":["field",35,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":35,"name":"TIMESTAMP","semantic_type":"type/CreationDate","settings":null,"unit":"month","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["field","count",{"base-type":"type/Integer"}],"name":"count","semantic_type":"type/Quantity"}]	\N	qQ3JGGOxVC8mrOLwxpcR6	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
17	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue goal for this quarter	Compares total revenue this quarter to our goal	progress	{"database":1,"query":{"aggregation":[["metric",9]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],"current","quarter"],"source-table":2},"type":"query"}	{"column_settings":{"[\\"name\\",\\"sum\\"]":{"decimals":0}},"progress.goal":250000}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}}]	\N	Ey2qt4I-wcg1E0846iUQS	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
18	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Product category orders per age	Shows a distribution of orders broken down by product category across our customers' individual age values	bar	{"database":1,"query":{"aggregation":[["count"]],"breakout":[["field","Age",{"base-type":"type/BigInteger"}],["field",18,{"base-type":"type/Text","join-alias":"Products"}]],"joins":[{"alias":"Products","condition":["=",["field","PRODUCT_ID",{"base-type":"type/Integer"}],["field",8,{"base-type":"type/BigInteger","join-alias":"Products"}]],"source-table":3,"strategy":"left-join"}],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"graph.dimensions":["Age","CATEGORY"],"graph.metrics":["count"],"graph.show_values":true,"graph.x_axis.scale":"linear","series_settings":{"Doohickey":{"color":"#7172AD"},"Gadget":{"color":"#999AC4"},"Gizmo":{"color":"#C7EAEA"},"Widget":{"color":"#227FD2"}},"stackable.stack_type":"normalized"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Decimal","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/Decimal","field_ref":["field","Age",{"base-type":"type/BigInteger"}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Products → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","join-alias":"Products"}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	byM0vLfOiM1zBI_t1MUcO	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
19	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Number of Orders	Canonical metric for number of orders placed	line	{"database":1,"query":{"aggregation":[["count"]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-3,"year",{"include-current":true}],"source-table":2},"type":"query"}	{"column_settings":null,"graph.dimensions":["CREATED_AT"],"graph.metrics":["count"]}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Month","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"month","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	8EdazRgPwfxdiltp7NCjS	[]	[]	t	\N	metric	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
29	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Enormous Wool Car trend	Compares the total number of orders placed for this product this month with the previous period	smartscalar	{"database":1,"query":{"aggregation":[["sum",["field",2,{"base-type":"type/Integer"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}]],"filter":["and",["between",["field",13,{"base-type":"type/DateTime"}],"2021-01-01","2024-01-23"],["=",["field",14,{"base-type":"type/Integer"}],17]],"source-table":2},"type":"query"}	{"column_settings":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Month","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"month","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Sum of Quantity","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Quantity","settings":{"show_mini_bar":false}}]	\N	HSVx57QxslVTGbo1_XS4G	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
20	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Total orders by product category	Breaks down the overall performance of each of the product categories	pie	{"database":1,"query":{"aggregation":[["metric",19]],"breakout":[["field",18,{"base-type":"type/Text","source-field":14}]],"source-table":2},"type":"query"}	{"column_settings":null,"pie.decimal_places":0,"pie.percent_visibility":"both","pie.rows":[{"color":"#7172AD","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Doohickey","name":"Doohickey","originalName":"Doohickey"},{"color":"#A989C5","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Gadget","name":"Gadget","originalName":"Gadget"},{"color":"#C7EAEA","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Gizmo","name":"Gizmo","originalName":"Gizmo"},{"color":"#227FD2","defaultColor":false,"enabled":true,"hidden":false,"isOther":false,"key":"Widget","name":"Widget","originalName":"Widget"}],"pie.show_labels":false,"pie.sort_rows":false}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	ShsD1PjGTlFIvzm5FM9qC	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
21	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Best selling products	An ordered list of our most successful products	row	{"database":1,"query":{"filter":[">=",["field","count",{"base-type":"type/Integer"}],110],"source-query":{"aggregation":[["count"]],"breakout":[["field",17,{"base-type":"type/Text","source-field":14}],["field",18,{"base-type":"type/Text","source-field":14}]],"filter":["!=",["field",17,{"base-type":"type/Text","source-field":14}],"Incredible Aluminum Knife"],"order-by":[["desc",["aggregation",0]]],"source-table":2}},"type":"query"}	{"column_settings":null,"graph.dimensions":["TITLE"],"graph.metrics":["count"],"graph.series_order":null,"graph.series_order_dimension":null,"graph.show_values":true,"graph.x_axis.title_text":"","graph.y_axis.title_text":"","series_settings":{"count":{"color":"#999AC4"}},"stackable.stack_type":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":"The name of the product as it should be displayed to customers.","display_name":"Product → Title","effective_type":"type/Text","field_ref":["field",17,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":17,"name":"TITLE","semantic_type":"type/Title","settings":{"link_url":"","view_as":null},"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["field","count",{"base-type":"type/Integer"}],"name":"count","semantic_type":"type/Quantity"}]	\N	S-hEu1jZ2-822qvBQ1EiT	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
22	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Average product rating	Indicates the average customer review of our products	gauge	{"database":1,"query":{"aggregation":[["avg",["field",16,{"base-type":"type/Float"}]]],"source-table":3},"type":"query"}	{"column_settings":null,"gauge.segments":[{"color":"#ED6E6E","label":"","max":1,"min":0},{"color":"#F2A86F","label":"","max":2,"min":1},{"color":"#F9D45C","label":"","max":3,"min":2},{"color":"#A7D07C","label":"","max":4,"min":3},{"color":"#689636","label":"","max":5,"min":4}]}	13371338	1	3	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Float","display_name":"Average of Rating","effective_type":"type/Float","field_ref":["aggregation",0],"name":"avg","semantic_type":"type/Score","settings":null}]	\N	fKu0z-vEC1WwVv1Lu95jD	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
23	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Most recent subscription	The most recent subscription in our database	object	{"database":1,"query":{"fields":[["field",24,{"base-type":"type/BigInteger"}],["field",37,{"base-type":"type/Text"}],["field",36,{"base-type":"type/Text"}],["field",43,{"base-type":"type/Text"}],["field",41,{"base-type":"type/Text"}],["field",31,{"base-type":"type/DateTime"}],["field",40,{"base-type":"type/DateTime"}],["field",39,{"base-type":"type/DateTime"}],["field",38,{"base-type":"type/Boolean"}],["field",42,{"base-type":"type/Boolean"}]],"filter":["time-interval",["field",31,{"base-type":"type/DateTime"}],-12,"month"],"order-by":[["desc",["field",31,{"base-type":"type/DateTime"}]]],"source-table":6},"type":"query"}	{"column_settings":null,"table.columns":[{"enabled":true,"name":"ID"},{"enabled":true,"name":"FIRST_NAME"},{"enabled":true,"name":"LAST_NAME"},{"enabled":true,"name":"PLAN"},{"enabled":false,"name":"SOURCE"},{"enabled":true,"name":"CREATED_AT"},{"enabled":true,"name":"TRIAL_ENDS_AT"},{"enabled":true,"name":"CANCELED_AT"},{"enabled":false,"name":"TRIAL_CONVERTED"},{"enabled":false,"name":"ACTIVE_SUBSCRIPTION"}]}	13371338	1	6	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","coercion_strategy":null,"description":null,"display_name":"ID","effective_type":"type/BigInteger","field_ref":["field",24,{"base-type":"type/BigInteger"}],"fk_target_field_id":null,"id":24,"name":"ID","semantic_type":"type/PK","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"First Name","effective_type":"type/Text","field_ref":["field",37,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":37,"name":"FIRST_NAME","semantic_type":"type/Name","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Last Name","effective_type":"type/Text","field_ref":["field",36,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":36,"name":"LAST_NAME","semantic_type":"type/Name","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Plan","effective_type":"type/Text","field_ref":["field",43,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":43,"name":"PLAN","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Source","effective_type":"type/Text","field_ref":["field",41,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":41,"name":"SOURCE","semantic_type":"type/Source","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Created At","effective_type":"type/DateTime","field_ref":["field",31,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":31,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Trial Ends At","effective_type":"type/DateTime","field_ref":["field",40,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":40,"name":"TRIAL_ENDS_AT","semantic_type":null,"settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Canceled At","effective_type":"type/DateTime","field_ref":["field",39,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":39,"name":"CANCELED_AT","semantic_type":"type/CancelationTimestamp","settings":null,"visibility_type":"normal"},{"base_type":"type/Boolean","coercion_strategy":null,"description":null,"display_name":"Trial Converted","effective_type":"type/Boolean","field_ref":["field",38,{"base-type":"type/Boolean"}],"fk_target_field_id":null,"id":38,"name":"TRIAL_CONVERTED","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Boolean","coercion_strategy":null,"description":null,"display_name":"Active Subscription","effective_type":"type/Boolean","field_ref":["field",42,{"base-type":"type/Boolean"}],"fk_target_field_id":null,"id":42,"name":"ACTIVE_SUBSCRIPTION","semantic_type":"type/Category","settings":null,"visibility_type":"normal"}]	\N	AXDOILGSNqoWoxV1NuvTt	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
30	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Unique customers per month	Unique customer email addresses last quarter compared to the previous	smartscalar	{"database":1,"query":{"aggregation":[["distinct",["field","EMAIL",{"base-type":"type/Text"}]]],"breakout":[["field","CREATED_AT",{"base-type":"type/DateTime","temporal-unit":"quarter"}]],"filter":["time-interval",["field","CREATED_AT",{"base-type":"type/DateTime"}],-2,"quarter"],"source-table":"card__1"},"type":"query"}	{"column_settings":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field","CREATED_AT",{"base-type":"type/DateTime","temporal-unit":"quarter"}],"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Distinct values of Customer Email","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity","settings":{"link_text":""}}]	\N	leO-OHTwIMltfpcLLOJxj	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
24	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Orders by product category	Compares the orders of each category quarter over quarter	line	{"database":1,"query":{"aggregation":[["metric",19]],"breakout":[["field",18,{"base-type":"type/Text","source-field":14}],["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter","original-temporal-unit":"month"}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-2,"year",{"include-current":true}],"source-table":2},"type":"query"}	{"column_settings":null,"graph.dimensions":["CREATED_AT","CATEGORY"],"graph.goal_value":500,"graph.label_value_formatting":"compact","graph.metrics":["count"],"graph.show_goal":true,"graph.show_trendline":false,"graph.show_values":true,"graph.x_axis.title_text":"","graph.y_axis.title_text":"","series_settings":{"Doohickey":{"color":"#7172AD","display":"area","line.interpolate":"cardinal","line.size":"M","line.style":"solid"},"Gadget":{"color":"#A989C5","line.size":"M"},"Gizmo":{"color":"#C7EAEA","line.size":"M","line.style":"solid"},"Widget":{"color":"#227FD2","line.size":"M"}}}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":"The type of product, valid values include: Doohicky, Gadget, Gizmo and Widget","display_name":"Product → Category","effective_type":"type/Text","field_ref":["field",18,{"base-type":"type/Text","source-field":14}],"fk_target_field_id":null,"id":18,"name":"CATEGORY","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter","original-temporal-unit":"month"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	kgAiQ87dLKJmTnOaTeVsc	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
25	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	All subscriptions in table view	More complete look at all recent subscriptions	table	{"database":1,"query":{"fields":[["field",24,{"base-type":"type/BigInteger"}],["field",37,{"base-type":"type/Text"}],["field",36,{"base-type":"type/Text"}],["field",43,{"base-type":"type/Text"}],["field",41,{"base-type":"type/Text"}],["field",31,{"base-type":"type/DateTime"}],["field",40,{"base-type":"type/DateTime"}],["field",39,{"base-type":"type/DateTime"}],["field",38,{"base-type":"type/Boolean"}],["field",42,{"base-type":"type/Boolean"}]],"filter":["time-interval",["field",31,{"base-type":"type/DateTime"}],-12,"month"],"order-by":[["desc",["field",31,{"base-type":"type/DateTime"}]]],"source-table":6},"type":"query"}	{"column_settings":null,"table.cell_column":"ACTIVE_SUBSCRIPTION","table.columns":[{"enabled":true,"name":"ID"},{"enabled":true,"name":"FIRST_NAME"},{"enabled":true,"name":"LAST_NAME"},{"enabled":true,"name":"PLAN"},{"enabled":false,"name":"SOURCE"},{"enabled":true,"name":"CREATED_AT"},{"enabled":true,"name":"TRIAL_ENDS_AT"},{"enabled":true,"name":"CANCELED_AT"},{"enabled":false,"name":"TRIAL_CONVERTED"},{"enabled":false,"name":"ACTIVE_SUBSCRIPTION"}],"table.pivot_column":"CANCELED_AT"}	13371338	1	6	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","coercion_strategy":null,"description":null,"display_name":"ID","effective_type":"type/BigInteger","field_ref":["field",24,{"base-type":"type/BigInteger"}],"fk_target_field_id":null,"id":24,"name":"ID","semantic_type":"type/PK","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"First Name","effective_type":"type/Text","field_ref":["field",37,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":37,"name":"FIRST_NAME","semantic_type":"type/Name","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Last Name","effective_type":"type/Text","field_ref":["field",36,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":36,"name":"LAST_NAME","semantic_type":"type/Name","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Plan","effective_type":"type/Text","field_ref":["field",43,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":43,"name":"PLAN","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Source","effective_type":"type/Text","field_ref":["field",41,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":41,"name":"SOURCE","semantic_type":"type/Source","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Created At","effective_type":"type/DateTime","field_ref":["field",31,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":31,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Trial Ends At","effective_type":"type/DateTime","field_ref":["field",40,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":40,"name":"TRIAL_ENDS_AT","semantic_type":null,"settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":null,"display_name":"Canceled At","effective_type":"type/DateTime","field_ref":["field",39,{"base-type":"type/DateTime"}],"fk_target_field_id":null,"id":39,"name":"CANCELED_AT","semantic_type":"type/CancelationTimestamp","settings":null,"visibility_type":"normal"},{"base_type":"type/Boolean","coercion_strategy":null,"description":null,"display_name":"Trial Converted","effective_type":"type/Boolean","field_ref":["field",38,{"base-type":"type/Boolean"}],"fk_target_field_id":null,"id":38,"name":"TRIAL_CONVERTED","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/Boolean","coercion_strategy":null,"description":null,"display_name":"Active Subscription","effective_type":"type/Boolean","field_ref":["field",42,{"base-type":"type/Boolean"}],"fk_target_field_id":null,"id":42,"name":"ACTIVE_SUBSCRIPTION","semantic_type":"type/Category","settings":null,"visibility_type":"normal"}]	\N	ucI5e9_FdTQF-1i7RdtIX	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
26	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Heavy-Duty Silk Chair trend	Compares the total number of orders placed for this product this month with the previous period	smartscalar	{"database":1,"query":{"aggregation":[["sum",["field",2,{"base-type":"type/Integer"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}]],"filter":["and",["between",["field",13,{"base-type":"type/DateTime"}],"2021-01-01","2024-01-23"],["=",["field",14,{"base-type":"type/Integer"}],86]],"source-table":2},"type":"query"}	{"column_settings":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Month","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"month","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Sum of Quantity","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Quantity","settings":{"show_mini_bar":false}}]	\N	fdkSuB8zWEbjEq_vWMaI-	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
27	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Quantity sold per quarter	Total sum of products sold last quarter compared to the previous	smartscalar	{"database":1,"query":{"aggregation":[["sum",["field",2,{"base-type":"type/Integer"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-2,"quarter",{"include-current":false}],"source-table":2},"type":"query"}	{"column_settings":null,"scalar.compact_primary_number":true,"scalar.field":"sum"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Sum of Quantity","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Quantity","settings":{"show_mini_bar":false}}]	\N	A5pNCrrWtf2bVka2vXVLx	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
28	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue per age group	Shows the revenue distributed by age group	bar	{"database":1,"query":{"aggregation":[["sum",["field","TOTAL",{"base-type":"type/Float"}]]],"breakout":[["field","Age",{"base-type":"type/BigInteger","binning":{"strategy":"num-bins","num-bins":10}}]],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"graph.dimensions":["Age"],"graph.metrics":["sum"],"graph.show_values":true}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Decimal","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/Decimal","field_ref":["field","Age",{"base-type":"type/BigInteger","binning":{"strategy":"num-bins","num-bins":10,"min-value":20,"max-value":70,"bin-width":5}}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}}]	\N	g7G9X1p0na--gwNCUL75j	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
31	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Checkout funnel - Modified	Flow from viewing our website (empty) to checkout and subscribe	funnel	{"database":1,"query":{"filter":["not-empty",["field","BUTTON_LABEL",{"base-type":"type/Text"}]],"source-query":{"aggregation":[["count"]],"breakout":[["field",29,{"base-type":"type/Text"}]],"source-table":7}},"type":"query"}	{"column_settings":null,"funnel.order_dimension":"BUTTON_LABEL","funnel.rows":[{"enabled":true,"key":"Create Item","name":"Create Item"},{"enabled":true,"key":"Invite","name":"Invite"},{"enabled":true,"key":"Subscribe","name":"Subscribe"},{"enabled":true,"key":"Signup","name":"Signup"},{"enabled":true,"key":"Checkout","name":"Checkout"}]}	13371338	1	7	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Text","coercion_strategy":null,"description":null,"display_name":"Button Label","effective_type":"type/Text","field_ref":["field",29,{"base-type":"type/Text"}],"fk_target_field_id":null,"id":29,"name":"BUTTON_LABEL","semantic_type":"type/Category","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["field","count",{"base-type":"type/Integer"}],"name":"count","semantic_type":"type/Quantity"}]	\N	dzFHc6awtpZCSn9-wscNQ	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
32	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	People with age	\N	table	{"database":1,"query":{"expressions":{"Age":["datetime-diff",["field",12,{"base-type":"type/Date"}],["now"],"year"]},"source-table":1},"type":"query"}	{"column_settings":null,"table.cell_column":"LONGITUDE","table.pivot_column":"SOURCE"}	13371338	1	1	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","coercion_strategy":null,"description":"A unique identifier given to each user.","display_name":"ID","effective_type":"type/BigInteger","field_ref":["field",4,null],"fk_target_field_id":null,"id":4,"name":"ID","semantic_type":"type/PK","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The street address of the account’s billing address","display_name":"Address","effective_type":"type/Text","field_ref":["field",51,null],"fk_target_field_id":null,"id":51,"name":"ADDRESS","semantic_type":null,"settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The contact email for the account.","display_name":"Email","effective_type":"type/Text","field_ref":["field",7,null],"fk_target_field_id":null,"id":7,"name":"EMAIL","semantic_type":"type/Email","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The name of the user who owns an account","display_name":"Name","effective_type":"type/Text","field_ref":["field",48,null],"fk_target_field_id":null,"id":48,"name":"NAME","semantic_type":"type/Name","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The city of the account’s billing address","display_name":"City","effective_type":"type/Text","field_ref":["field",53,null],"fk_target_field_id":null,"id":53,"name":"CITY","semantic_type":"type/City","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"This is the longitude of the user on sign-up. It might be updated in the future to the last seen location.","display_name":"Longitude","effective_type":"type/Float","field_ref":["field",58,null],"fk_target_field_id":null,"id":58,"name":"LONGITUDE","semantic_type":"type/Longitude","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The state or province of the account’s billing address","display_name":"State","effective_type":"type/Text","field_ref":["field",1,null],"fk_target_field_id":null,"id":1,"name":"STATE","semantic_type":"type/State","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The channel through which we acquired this user. Valid values include: Affiliate, Facebook, Google, Organic and Twitter","display_name":"Source","effective_type":"type/Text","field_ref":["field",30,null],"fk_target_field_id":null,"id":30,"name":"SOURCE","semantic_type":"type/Source","settings":null,"visibility_type":"normal"},{"base_type":"type/Date","coercion_strategy":null,"description":"The date of birth of the user","display_name":"Birth Date","effective_type":"type/Date","field_ref":["field",12,null],"fk_target_field_id":null,"id":12,"name":"BIRTH_DATE","semantic_type":"type/Birthdate","settings":null,"visibility_type":"normal"},{"base_type":"type/Text","coercion_strategy":null,"description":"The postal code of the account’s billing address","display_name":"Zip","effective_type":"type/Text","field_ref":["field",61,null],"fk_target_field_id":null,"id":61,"name":"ZIP","semantic_type":"type/ZipCode","settings":null,"visibility_type":"normal"},{"base_type":"type/Float","coercion_strategy":null,"description":"This is the latitude of the user on sign-up. It might be updated in the future to the last seen location.","display_name":"Latitude","effective_type":"type/Float","field_ref":["field",52,null],"fk_target_field_id":null,"id":52,"name":"LATITUDE","semantic_type":"type/Latitude","settings":null,"visibility_type":"normal"},{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date the user record was created. Also referred to as the user’s \\"join date\\"","display_name":"Created At","effective_type":"type/DateTime","field_ref":["field",50,null],"fk_target_field_id":null,"id":50,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Age","effective_type":"type/BigInteger","field_ref":["expression","Age"],"name":"Age","semantic_type":null}]	\N	c5m4bxKyi7GEa1sML-wpu	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
33	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Revenue per individual age	Shows a distribution of revenue per individual age values	bar	{"database":1,"query":{"aggregation":[["sum",["field","TOTAL",{"base-type":"type/Float"}]]],"breakout":[["field","Age",{"base-type":"type/BigInteger"}]],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"graph.dimensions":["Age"],"graph.metrics":["sum"],"graph.show_values":true}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/BigInteger","field_ref":["field","Age",{"base-type":"type/BigInteger"}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Float","display_name":"Sum of Total","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Currency","settings":{"currency":"USD"}}]	\N	T9OjH7_py-tNsyPb4O8yC	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
34	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Discounts given per quarter	Total amount of discounts last quarter compared to the previous	smartscalar	{"database":1,"query":{"aggregation":[["sum",["field",3,{"base-type":"type/Float"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}]],"filter":["time-interval",["field",13,{"base-type":"type/DateTime"}],-2,"quarter",{"include-current":false}],"source-table":2},"type":"query"}	{"column_settings":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Quarter","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"quarter","visibility_type":"normal"},{"base_type":"type/Float","display_name":"Sum of Discount","effective_type":"type/Float","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Discount","settings":null}]	\N	IEp2LZKY_aJMpchBacdjP	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
35	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Orders by source per individual age	Shows a distribution of orders broken down by source across our customers' individual age values	bar	{"database":1,"query":{"aggregation":[["count"]],"breakout":[["field","Age",{"base-type":"type/BigInteger"}],["field",30,{"base-type":"type/Text","source-field":11}]],"joins":[{"alias":"Products","condition":["=",["field","PRODUCT_ID",{"base-type":"type/Integer"}],["field",8,{"base-type":"type/BigInteger","join-alias":"Products"}]],"source-table":3,"strategy":"left-join"}],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"graph.dimensions":["Age","SOURCE"],"graph.metrics":["count"],"graph.show_values":true,"graph.x_axis.scale":"linear","stackable.stack_type":"normalized"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/BigInteger","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/BigInteger","field_ref":["field","Age",{"base-type":"type/BigInteger"}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Text","coercion_strategy":null,"description":"The channel through which we acquired this user. Valid values include: Affiliate, Facebook, Google, Organic and Twitter","display_name":"User → Source","effective_type":"type/Text","field_ref":["field",30,{"base-type":"type/Text","source-field":11}],"fk_target_field_id":null,"id":30,"name":"SOURCE","semantic_type":"type/Source","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	8MovkFBA00WFOq2v5BzfB	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
36	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Orders by source per age group	Shows a distribution of orders broken down by source across our customers' age groups	bar	{"database":1,"query":{"aggregation":[["count"]],"breakout":[["field","Age",{"base-type":"type/BigInteger","binning":{"strategy":"num-bins","num-bins":10}}],["field",30,{"base-type":"type/Text","source-field":11}]],"joins":[{"alias":"Products","condition":["=",["field","PRODUCT_ID",{"base-type":"type/Integer"}],["field",8,{"base-type":"type/BigInteger","join-alias":"Products"}]],"source-table":3,"strategy":"left-join"}],"source-table":"card__1"},"type":"query"}	{"column_settings":null,"graph.dimensions":["Age","SOURCE"],"graph.metrics":["count"],"graph.show_values":true,"graph.x_axis.scale":"linear","stackable.stack_type":"stacked"}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/Decimal","description":"Age of the customer in years.","display_name":"Age","effective_type":"type/Decimal","field_ref":["field","Age",{"base-type":"type/BigInteger","binning":{"strategy":"num-bins","num-bins":10,"min-value":20,"max-value":70,"bin-width":5}}],"name":"Age","semantic_type":"type/Quantity"},{"base_type":"type/Text","coercion_strategy":null,"description":"The channel through which we acquired this user. Valid values include: Affiliate, Facebook, Google, Organic and Twitter","display_name":"User → Source","effective_type":"type/Text","field_ref":["field",30,{"base-type":"type/Text","source-field":11}],"fk_target_field_id":null,"id":30,"name":"SOURCE","semantic_type":"type/Source","settings":null,"visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Count","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"count","semantic_type":"type/Quantity"}]	\N	yBoV-iHmFUrY9xqB0v9Pg	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	1	\N
37	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	Aerodynamic Copper Knife trend	Compares the total number of orders placed for this product this month with the previous period	smartscalar	{"database":1,"query":{"aggregation":[["sum",["field",2,{"base-type":"type/Integer"}]]],"breakout":[["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}]],"filter":["and",["between",["field",13,{"base-type":"type/DateTime"}],"2021-01-01","2024-01-23"],["=",["field",14,{"base-type":"type/Integer"}],165]],"source-table":2},"type":"query"}	{"column_settings":null}	13371338	1	2	query	f	2	\N	\N	f	\N	\N	[{"base_type":"type/DateTime","coercion_strategy":null,"description":"The date and time an order was submitted.","display_name":"Created At: Month","effective_type":"type/DateTime","field_ref":["field",13,{"base-type":"type/DateTime","temporal-unit":"month"}],"fk_target_field_id":null,"id":13,"name":"CREATED_AT","semantic_type":"type/CreationTimestamp","settings":{"time_enabled":"milliseconds"},"unit":"month","visibility_type":"normal"},{"base_type":"type/BigInteger","display_name":"Sum of Quantity","effective_type":"type/BigInteger","field_ref":["aggregation",0],"name":"sum","semantic_type":"type/Quantity","settings":{"show_mini_bar":false}}]	\N	BQAQ6YNiUIMfmAPLpSKQW	[]	[]	t	\N	question	\N	\N	2025-04-13 06:23:57.296644+00	0	f	\N	\N	\N
\.


--
-- Data for Name: report_cardfavorite; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.report_cardfavorite (id, created_at, updated_at, card_id, owner_id) FROM stdin;
\.


--
-- Data for Name: report_dashboard; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.report_dashboard (id, created_at, updated_at, name, description, creator_id, parameters, points_of_interest, caveats, show_in_getting_started, public_uuid, made_public_by_id, enable_embedding, embedding_params, archived, "position", collection_id, collection_position, cache_ttl, entity_id, auto_apply_filters, width, initially_published_at, view_count, archived_directly, last_viewed_at) FROM stdin;
1	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	E-commerce Insights	Overview of sample data and hypothetical sales	13371338	[{"id":"81cd957","name":"Date Range","required":false,"sectionId":"date","slug":"date_range","type":"date/all-options"},{"id":"efd919c7","name":"Date Grouping","sectionId":"temporal-unit","slug":"date_grouping","type":"temporal-unit"},{"default":["Doohickey","Gizmo","Gadget","Widget"],"id":"9d9cddd4","name":"Product Category","required":true,"sectionId":"string","slug":"product_category","type":"string/="},{"id":"1ebab259","isMultiSelect":false,"name":"Vendor","sectionId":"string","slug":"vendor","type":"string/="}]	\N	\N	f	\N	\N	f	\N	f	\N	2	2	\N	xBLdW9FsgRuB2HGhWiBa_	t	fixed	\N	0	f	2025-04-13 06:23:57.296644+00
\.


--
-- Data for Name: report_dashboardcard; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.report_dashboardcard (id, created_at, updated_at, size_x, size_y, "row", col, card_id, dashboard_id, parameter_mappings, visualization_settings, entity_id, action_id, dashboard_tab_id) FROM stdin;
1	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	12	8	10	0	21	1	[]	{"click_behavior":{"parameterMapping":{"9d9cddd4":{"id":"9d9cddd4","source":{"id":"CATEGORY","name":"Product → Category","type":"column"},"target":{"id":"9d9cddd4","type":"parameter"}}},"type":"crossfilter"},"column_settings":null}	OO4kGtX3HOooGeROYUZJe	\N	2
2	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	7	19	0	24	1	[{"card_id":24,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":24,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime"}],{"stage-number":0}]},{"card_id":24,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":24,"parameter_id":"efd919c7","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],{"stage-number":0}]}]	{"column_settings":null}	AmK0nHFFIARIPCWx7RHj8	\N	1
3	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	10	7	26	0	22	1	[]	{"column_settings":null}	YIP_KpvNnw0g7igNvwMVp	\N	2
4	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	12	8	10	12	2	1	[{"card_id":2,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]}]	{"column_settings":null}	gi60ETDzDM8MxIUN9Nt-7	\N	2
5	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	6	18	0	18	1	[]	{"column_settings":null}	4bnIg0l06MqSikGg2jPM1	\N	2
6	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	17	8	2	0	12	1	[{"card_id":12,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":12,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],{"stage-number":0}]},{"card_id":12,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":12,"parameter_id":"efd919c7","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],{"stage-number":0}]}]	{"column_settings":null}	mM0yHMzeaWUi0uJkT1puj	\N	1
7	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	0	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Overall Business Health","virtual_card":{"archived":false,"dataset_query":{},"display":"heading","name":null,"visualization_settings":{}}}	8_qdLmnHn3tGOaDdbLTwn	\N	1
8	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	7	4	2	17	15	1	[{"card_id":15,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":15,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime"}],{"stage-number":0}]},{"card_id":15,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":15,"parameter_id":"efd919c7","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],{"stage-number":0}]}]	{"column_settings":null}	_VxmRsylZKkpe0H-lGwyT	\N	1
9	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	7	4	6	17	17	1	[{"card_id":17,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":17,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime"}],{"stage-number":0}]},{"card_id":17,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]}]	{"column_settings":null}	vPyErYUpYMjucZa7z4smS	\N	1
10	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	12	7	12	12	13	1	[{"card_id":13,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":13,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"month","original-temporal-unit":"quarter"}],{"stage-number":0}]},{"card_id":13,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":13,"parameter_id":"efd919c7","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"month","original-temporal-unit":"quarter"}],{"stage-number":0}]}]	{"column_settings":null}	3MGVK2PTcGxJwDXlDqjSE	\N	1
11	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	10	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Deeper Dive","virtual_card":{"archived":false,"dataset_query":{},"display":"heading","name":null,"visualization_settings":{}}}	zsygIGYHdnaVsoFLgitCe	\N	1
12	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	8	26	0	10	1	[{"card_id":10,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":10,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime"}],{"stage-number":0}]},{"card_id":10,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":10,"parameter_id":"efd919c7","target":["dimension",["field",13,{"base-type":"type/DateTime","temporal-unit":"quarter"}],{"stage-number":0}]}]	{"column_settings":null}	fRjV39ywXfG8mj6NFsXH4	\N	1
13	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	12	7	12	0	20	1	[{"card_id":20,"parameter_id":"1ebab259","target":["dimension",["field",34,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]},{"card_id":20,"parameter_id":"81cd957","target":["dimension",["field",13,{"base-type":"type/DateTime"}],{"stage-number":0}]},{"card_id":20,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]}]	{"column_settings":null}	-zrxIkj-jscf4OwBR435T	\N	1
14	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	0	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Top Performing Products","virtual_card":{"archived":false,"dataset_query":{},"display":"heading","name":null,"visualization_settings":{}}}	wYtzbytCKhibM8Zg9s4VP	\N	2
15	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	12	8	2	0	7	1	[]	{"column_settings":null}	wuIanq5bdBiexA3yhyO0w	\N	2
16	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	1	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Business KPIs _look strong_ based on the consistent MoM revenue growth following the growth in the number of orders","virtual_card":{"archived":false,"dataset_query":{},"display":"text","name":null,"visualization_settings":{}}}	WD8BNj-NyWXaWuFghZNDU	\N	1
17	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	1	0	\N	1	[{"parameter_id":"9d9cddd4","target":["text-tag","product_category"]}]	{"column_settings":null,"dashcard.background":false,"text":"Find below a breakdown of products and their performance, filtered now for {{product_category}}","virtual_card":{"archived":false,"dataset_query":{},"display":"text","name":null,"visualization_settings":{}}}	NZSFQPtNkT7fLZeeW9Oo0	\N	2
18	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	11	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Widget and Gizmo are our leading products, generating the most revenue and orders","virtual_card":{"archived":false,"dataset_query":{},"display":"text","name":null,"visualization_settings":{}}}	f-Hf9bL9_oArQCg-kLSdY	\N	1
19	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	12	8	2	12	8	1	[{"card_id":8,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]}]	{"column_settings":null}	-IoAlBOQzsTLapLzSFQoE	\N	2
20	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	24	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Customer Satisfaction","virtual_card":{"archived":false,"dataset_query":{},"display":"heading","name":null,"visualization_settings":{}}}	YyZMLS7IGhXda6vmEfJ4I	\N	2
21	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	25	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Super important customer ratings for our products","virtual_card":{"archived":false,"dataset_query":{},"display":"text","name":null,"visualization_settings":{}}}	MS4_Du2Fd3qkjpaRZFOqm	\N	2
22	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	14	7	26	10	3	1	[{"card_id":3,"parameter_id":"9d9cddd4","target":["dimension",["field",18,{"base-type":"type/Text","source-field":14}],{"stage-number":0}]}]	{"column_settings":null}	WNCZfFyxCnhkAttN_rsIy	\N	2
23	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	0	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Website Analysis","virtual_card":{"archived":false,"dataset_query":{},"display":"heading","name":null,"visualization_settings":{}}}	K2tgkIzRB0_cSP8jrVZ6p	\N	3
24	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	1	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Take a look into our customer funnel and website performance","virtual_card":{"archived":false,"dataset_query":{},"display":"text","name":null,"visualization_settings":{}}}	DTpP8-129mKPp9oxsq_4R	\N	3
25	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	10	33	0	5	1	[]	{"column_settings":null}	19JbScZRjz5mSQ7chtjuY	\N	2
26	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	14	7	9	0	6	1	[]	{"column_settings":null}	fx-Zfyq1gaIcq2axhIRls	\N	3
27	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	10	7	9	14	16	1	[{"card_id":16,"parameter_id":"81cd957","target":["dimension",["field","TIMESTAMP",{"base-type":"type/DateTime","inherited-temporal-unit":"month"}],{"stage-number":1}]}]	{"column_settings":null}	wZV8zAS2XAMH_ub1DG58A	\N	3
28	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	10	6	16	14	23	1	[{"card_id":23,"parameter_id":"81cd957","target":["dimension",["field",31,{"base-type":"type/DateTime"}],{"stage-number":0}]}]	{"column_settings":null}	R6UJhgRJd678v2nvAioH_	\N	3
29	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	10	1	22	14	\N	1	[]	{"column_settings":null,"link":{"entity":{"collection_id":1788,"db_id":null,"description":"More complete look at all recent subscriptions","display":"table","id":25,"model":"card","name":"All subscriptions in table view"}},"virtual_card":{"archived":false,"dataset_query":{},"display":"link","name":null,"visualization_settings":{}}}	ZuOmZNE78gKe16jyqSRX4	\N	3
30	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	7	2	0	11	1	[]	{"column_settings":null}	x6_b5ifhvPkZKw3ZgFcPy	\N	3
31	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	10	25	0	\N	1	[]	{"column_settings":null,"iframe":"https://www.youtube.com/watch?v=dnT2Xj52mnk","virtual_card":{"archived":false,"dataset_query":{},"display":"iframe","name":null,"visualization_settings":{}}}	sCNcFfp3EeaizKg0VtW4e	\N	3
32	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	24	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Find more guides and tutorials on Metabase, analytics, data modeling, and more at [Metabase Learn](https://www.metabase.com/learn/)\\n\\n","virtual_card":{"archived":false,"dataset_query":{},"display":"text","name":null,"visualization_settings":{}}}	OlrrrzZShIqvGE6RAjqbr	\N	3
33	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	24	1	23	0	\N	1	[]	{"column_settings":null,"dashcard.background":false,"text":"Appendix","virtual_card":{"archived":false,"dataset_query":{},"display":"heading","name":null,"visualization_settings":{}}}	Rq9NMjA_Y28ZDB-nwO8vI	\N	3
34	2025-04-13 06:23:57.296644+00	2025-04-13 06:23:57.296644+00	14	7	16	0	14	1	[{"card_id":14,"parameter_id":"81cd957","target":["dimension",["field",31,{"base-type":"type/DateTime"}],{"stage-number":1}]}]	{"column_settings":null}	VkOq2o1cbIeE2MYeP4mfx	\N	3
\.


--
-- Data for Name: revision; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.revision (id, model, model_id, user_id, "timestamp", object, is_reversion, is_creation, message, most_recent, metabase_version) FROM stdin;
\.


--
-- Data for Name: sandboxes; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.sandboxes (id, group_id, table_id, card_id, attribute_remappings) FROM stdin;
\.


--
-- Data for Name: search_index_metadata; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.search_index_metadata (id, engine, version, index_name, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: secret; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.secret (id, version, creator_id, created_at, updated_at, name, kind, source, value) FROM stdin;
\.


--
-- Data for Name: segment; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.segment (id, table_id, creator_id, name, description, archived, definition, created_at, updated_at, points_of_interest, caveats, show_in_getting_started, entity_id) FROM stdin;
\.


--
-- Data for Name: setting; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.setting (key, value) FROM stdin;
example-dashboard-id	1
encryption-check	unencrypted
setup-token	351fde9a-e4b3-4424-8982-09ac46220941
redirect-all-requests-to-https	false
site-url	http://localhost:3000
analytics-uuid	27e8c9ea-6bb3-4bfd-b955-ffa6243fb913
instance-creation	2025-04-13T06:23:48.896986Z
site-name	company
admin-email	admin@example.com
site-locale	en
site-uuid	c411e1ae-1f32-4d5f-b06b-45460345edd9
anon-tracking-enabled	false
setup-license-active-at-setup	false
startup-time-millis	4226
settings-last-updated	2025-04-13 06:59:46.477876+00
\.


--
-- Data for Name: table_privileges; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.table_privileges (table_id, role, "select", update, insert, delete) FROM stdin;
17	\N	t	t	t	t
14	\N	t	t	t	t
16	\N	t	t	t	t
18	\N	t	t	t	t
10	\N	t	t	t	t
9	\N	t	t	t	t
15	\N	t	t	t	t
12	\N	t	t	t	t
11	\N	t	t	t	t
13	\N	t	t	t	t
\.


--
-- Data for Name: task_history; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.task_history (id, task, db_id, started_at, ended_at, duration, task_details, status) FROM stdin;
2	sync-dbms-version	1	2025-04-13 06:24:05.228072+00	2025-04-13 06:24:05.281105+00	53	{"flavor":"H2","version":"2.1.214 (2022-06-13)","semantic-version":[2,1]}	success
3	sync-timezone	1	2025-04-13 06:24:05.306358+00	2025-04-13 06:24:05.348067+00	41	{"timezone-id":"GMT"}	success
4	sync-tables	1	2025-04-13 06:24:05.356849+00	2025-04-13 06:24:05.401869+00	45	{"updated-tables":0,"total-tables":8}	success
5	sync-fields	1	2025-04-13 06:24:05.410709+00	2025-04-13 06:24:05.614495+00	203	{"total-fields":71,"updated-fields":0}	success
6	sync-fks	1	2025-04-13 06:24:05.631258+00	2025-04-13 06:24:05.697377+00	66	{"total-fks":6,"updated-fks":0,"total-failed":0}	success
7	sync-indexes	1	2025-04-13 06:24:05.703951+00	2025-04-13 06:24:06.003225+00	299	{"total-indexes":0,"added-indexes":0,"removed-indexes":0}	success
8	sync-metabase-metadata	1	2025-04-13 06:24:06.010638+00	2025-04-13 06:24:06.624539+00	613	{}	success
9	sync-table-privileges	1	2025-04-13 06:24:06.629272+00	2025-04-13 06:24:06.6345+00	5	\N	success
1	sync	1	2025-04-13 06:24:05.185322+00	2025-04-13 06:24:06.640429+00	1455	\N	success
11	fingerprint-fields	1	2025-04-13 06:24:06.657209+00	2025-04-13 06:24:06.697399+00	40	{"no-data-fingerprints":0,"failed-fingerprints":0,"updated-fingerprints":0,"fingerprints-attempted":0}	success
12	classify-fields	1	2025-04-13 06:24:06.70294+00	2025-04-13 06:24:06.731807+00	28	{"fields-classified":0,"fields-failed":0}	success
13	classify-tables	1	2025-04-13 06:24:06.737384+00	2025-04-13 06:24:06.753174+00	15	{"tables-classified":0,"total-tables":8}	success
10	analyze	1	2025-04-13 06:24:06.652464+00	2025-04-13 06:24:06.761383+00	108	\N	success
15	delete-expired-advanced-field-values	1	2025-04-13 06:24:06.778984+00	2025-04-13 06:24:07.045724+00	266	{"deleted":0}	success
16	update-field-values	1	2025-04-13 06:24:07.061289+00	2025-04-13 06:24:07.221404+00	160	{"errors":0,"created":0,"updated":0,"deleted":0}	success
14	field values scanning	1	2025-04-13 06:24:06.771736+00	2025-04-13 06:24:07.237768+00	466	\N	success
18	sync-dbms-version	2	2025-04-13 06:25:40.82637+00	2025-04-13 06:25:40.862489+00	36	{"flavor":"PostgreSQL","version":"17.0 (Debian 17.0-1.pgdg120+1)","semantic-version":[17,0]}	success
19	sync-timezone	2	2025-04-13 06:25:40.869456+00	2025-04-13 06:25:40.906389+00	36	{"timezone-id":"GMT"}	success
20	sync-tables	2	2025-04-13 06:25:40.91206+00	2025-04-13 06:25:41.262871+00	350	{"updated-tables":10,"total-tables":0}	success
21	sync-fields	2	2025-04-13 06:25:41.269383+00	2025-04-13 06:25:41.563732+00	294	{"total-fields":62,"updated-fields":62}	success
22	sync-fks	2	2025-04-13 06:25:41.570533+00	2025-04-13 06:25:41.595018+00	24	{"total-fks":0,"updated-fks":0,"total-failed":0}	success
23	sync-indexes	2	2025-04-13 06:25:41.599606+00	2025-04-13 06:25:41.627583+00	27	{"total-indexes":1,"added-indexes":1,"removed-indexes":0}	success
24	sync-metabase-metadata	2	2025-04-13 06:25:41.633526+00	2025-04-13 06:25:41.638744+00	5	{}	success
25	sync-table-privileges	2	2025-04-13 06:25:41.645841+00	2025-04-13 06:25:41.665383+00	19	{"total-table-privileges":10}	success
17	sync	2	2025-04-13 06:25:40.819026+00	2025-04-13 06:25:41.670391+00	851	\N	success
27	fingerprint-fields	2	2025-04-13 06:25:41.700108+00	2025-04-13 06:25:43.654977+00	1954	{"no-data-fingerprints":0,"failed-fingerprints":0,"updated-fingerprints":60,"fingerprints-attempted":60}	success
28	classify-fields	2	2025-04-13 06:25:43.659518+00	2025-04-13 06:25:43.813647+00	154	{"fields-classified":60,"fields-failed":0}	success
29	classify-tables	2	2025-04-13 06:25:43.817722+00	2025-04-13 06:25:43.874057+00	56	{"tables-classified":10,"total-tables":10}	success
26	analyze	2	2025-04-13 06:25:41.695315+00	2025-04-13 06:25:43.878716+00	2183	\N	success
31	delete-expired-advanced-field-values	2	2025-04-13 06:25:43.897614+00	2025-04-13 06:25:44.064851+00	167	{"deleted":0}	success
32	update-field-values	2	2025-04-13 06:25:44.079107+00	2025-04-13 06:25:44.19562+00	116	{"errors":0,"created":0,"updated":0,"deleted":0}	success
30	field values scanning	2	2025-04-13 06:25:43.893761+00	2025-04-13 06:25:44.212223+00	318	\N	success
34	sync-dbms-version	2	2025-04-13 06:59:46.63884+00	2025-04-13 06:59:46.649603+00	10	{"flavor":"PostgreSQL","version":"17.0 (Debian 17.0-1.pgdg120+1)","semantic-version":[17,0]}	success
35	sync-timezone	2	2025-04-13 06:59:46.668308+00	2025-04-13 06:59:46.684747+00	16	{"timezone-id":"GMT"}	success
36	sync-tables	2	2025-04-13 06:59:46.693693+00	2025-04-13 06:59:46.759866+00	66	{"updated-tables":0,"total-tables":10}	success
37	sync-fields	2	2025-04-13 06:59:46.768852+00	2025-04-13 06:59:47.065992+00	297	{"total-fields":62,"updated-fields":0}	success
38	sync-fks	2	2025-04-13 06:59:47.083213+00	2025-04-13 06:59:47.131526+00	48	{"total-fks":0,"updated-fks":0,"total-failed":0}	success
39	sync-indexes	2	2025-04-13 06:59:47.141515+00	2025-04-13 06:59:47.170667+00	29	{"total-indexes":0,"added-indexes":0,"removed-indexes":0}	success
40	sync-metabase-metadata	2	2025-04-13 06:59:47.1778+00	2025-04-13 06:59:47.184395+00	6	{}	success
41	sync-table-privileges	2	2025-04-13 06:59:47.190795+00	2025-04-13 06:59:47.214604+00	23	{"total-table-privileges":10}	success
33	sync	2	2025-04-13 06:59:46.597146+00	2025-04-13 06:59:47.220688+00	623	\N	success
43	fingerprint-fields	2	2025-04-13 06:59:47.239368+00	2025-04-13 06:59:47.295707+00	56	{"no-data-fingerprints":0,"failed-fingerprints":0,"updated-fingerprints":0,"fingerprints-attempted":0}	success
44	classify-fields	2	2025-04-13 06:59:47.30195+00	2025-04-13 06:59:47.341871+00	39	{"fields-classified":0,"fields-failed":0}	success
45	classify-tables	2	2025-04-13 06:59:47.349711+00	2025-04-13 06:59:47.371426+00	21	{"tables-classified":0,"total-tables":10}	success
42	analyze	2	2025-04-13 06:59:47.23374+00	2025-04-13 06:59:47.381026+00	147	\N	success
\.


--
-- Data for Name: timeline; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.timeline (id, name, description, icon, collection_id, archived, creator_id, created_at, updated_at, "default", entity_id) FROM stdin;
\.


--
-- Data for Name: timeline_event; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.timeline_event (id, timeline_id, name, description, "timestamp", time_matters, timezone, icon, archived, creator_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: user_key_value; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.user_key_value (id, user_id, namespace, key, value, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: user_parameter_value; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.user_parameter_value (id, user_id, parameter_id, value, dashboard_id) FROM stdin;
\.


--
-- Data for Name: view_log; Type: TABLE DATA; Schema: public; Owner: metabase
--

COPY public.view_log (id, user_id, model, model_id, "timestamp", metadata, has_access, context, embedding_client, embedding_version) FROM stdin;
\.


--
-- Name: action_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.action_id_seq', 1, false);


--
-- Name: api_key_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.api_key_id_seq', 1, false);


--
-- Name: application_permissions_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.application_permissions_revision_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- Name: bookmark_ordering_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.bookmark_ordering_id_seq', 1, false);


--
-- Name: cache_config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.cache_config_id_seq', 1, false);


--
-- Name: card_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.card_bookmark_id_seq', 1, false);


--
-- Name: card_label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.card_label_id_seq', 1, false);


--
-- Name: channel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.channel_id_seq', 1, false);


--
-- Name: channel_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.channel_template_id_seq', 3, true);


--
-- Name: cloud_migration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.cloud_migration_id_seq', 1, false);


--
-- Name: collection_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.collection_bookmark_id_seq', 1, false);


--
-- Name: collection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.collection_id_seq', 4, true);


--
-- Name: collection_permission_graph_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.collection_permission_graph_revision_id_seq', 1, false);


--
-- Name: connection_impersonations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.connection_impersonations_id_seq', 1, false);


--
-- Name: core_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.core_user_id_seq', 1, true);


--
-- Name: dashboard_bookmark_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.dashboard_bookmark_id_seq', 1, false);


--
-- Name: dashboard_favorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.dashboard_favorite_id_seq', 1, false);


--
-- Name: dashboard_tab_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.dashboard_tab_id_seq', 3, true);


--
-- Name: dashboardcard_series_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.dashboardcard_series_id_seq', 1, false);


--
-- Name: data_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.data_permissions_id_seq', 11, true);


--
-- Name: dependency_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.dependency_id_seq', 1, false);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.dimension_id_seq', 1, false);


--
-- Name: field_usage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.field_usage_id_seq', 1, false);


--
-- Name: group_table_access_policy_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.group_table_access_policy_id_seq', 1, false);


--
-- Name: label_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.label_id_seq', 1, false);


--
-- Name: login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.login_history_id_seq', 1, true);


--
-- Name: metabase_database_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.metabase_database_id_seq', 2, true);


--
-- Name: metabase_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.metabase_field_id_seq', 133, true);


--
-- Name: metabase_fieldvalues_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.metabase_fieldvalues_id_seq', 1, false);


--
-- Name: metabase_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.metabase_table_id_seq', 18, true);


--
-- Name: metric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.metric_id_seq', 1, false);


--
-- Name: metric_important_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.metric_important_field_id_seq', 1, false);


--
-- Name: model_index_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.model_index_id_seq', 1, false);


--
-- Name: moderation_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.moderation_review_id_seq', 1, false);


--
-- Name: native_query_snippet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.native_query_snippet_id_seq', 1, false);


--
-- Name: notification_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.notification_card_id_seq', 1, false);


--
-- Name: notification_handler_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.notification_handler_id_seq', 3, true);


--
-- Name: notification_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.notification_id_seq', 3, true);


--
-- Name: notification_recipient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.notification_recipient_id_seq', 4, true);


--
-- Name: notification_subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.notification_subscription_id_seq', 3, true);


--
-- Name: parameter_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.parameter_card_id_seq', 1, false);


--
-- Name: permissions_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.permissions_group_id_seq', 2, true);


--
-- Name: permissions_group_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.permissions_group_membership_id_seq', 3, true);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.permissions_id_seq', 6, true);


--
-- Name: permissions_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.permissions_revision_id_seq', 1, false);


--
-- Name: persisted_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.persisted_info_id_seq', 1, false);


--
-- Name: pulse_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.pulse_card_id_seq', 1, false);


--
-- Name: pulse_channel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.pulse_channel_id_seq', 1, false);


--
-- Name: pulse_channel_recipient_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.pulse_channel_recipient_id_seq', 1, false);


--
-- Name: pulse_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.pulse_id_seq', 1, false);


--
-- Name: query_analysis_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.query_analysis_id_seq', 1, false);


--
-- Name: query_execution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.query_execution_id_seq', 1, false);


--
-- Name: query_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.query_field_id_seq', 1, false);


--
-- Name: query_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.query_table_id_seq', 1, false);


--
-- Name: recent_views_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.recent_views_id_seq', 1, false);


--
-- Name: report_card_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.report_card_id_seq', 37, true);


--
-- Name: report_cardfavorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.report_cardfavorite_id_seq', 1, false);


--
-- Name: report_dashboard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.report_dashboard_id_seq', 1, true);


--
-- Name: report_dashboardcard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.report_dashboardcard_id_seq', 34, true);


--
-- Name: revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.revision_id_seq', 1, false);


--
-- Name: search_index_metadata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.search_index_metadata_id_seq', 1, false);


--
-- Name: secret_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.secret_id_seq', 1, false);


--
-- Name: segment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.segment_id_seq', 1, false);


--
-- Name: task_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.task_history_id_seq', 45, true);


--
-- Name: timeline_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.timeline_event_id_seq', 1, false);


--
-- Name: timeline_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.timeline_id_seq', 1, false);


--
-- Name: user_key_value_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.user_key_value_id_seq', 1, false);


--
-- Name: user_parameter_value_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.user_parameter_value_id_seq', 1, false);


--
-- Name: view_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: metabase
--

SELECT pg_catalog.setval('public.view_log_id_seq', 1, false);


--
-- Name: action action_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_entity_id_key UNIQUE (entity_id);


--
-- Name: action action_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_pkey PRIMARY KEY (id);


--
-- Name: action action_public_uuid_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT action_public_uuid_key UNIQUE (public_uuid);


--
-- Name: api_key api_key_key_prefix_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_prefix_key UNIQUE (key_prefix);


--
-- Name: api_key api_key_name_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_name_key UNIQUE (name);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: bookmark_ordering bookmark_ordering_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.bookmark_ordering
    ADD CONSTRAINT bookmark_ordering_pkey PRIMARY KEY (id);


--
-- Name: cache_config cache_config_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.cache_config
    ADD CONSTRAINT cache_config_pkey PRIMARY KEY (id);


--
-- Name: card_bookmark card_bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_bookmark
    ADD CONSTRAINT card_bookmark_pkey PRIMARY KEY (id);


--
-- Name: card_label card_label_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT card_label_pkey PRIMARY KEY (id);


--
-- Name: channel channel_name_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_name_key UNIQUE (name);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_template channel_template_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.channel_template
    ADD CONSTRAINT channel_template_pkey PRIMARY KEY (id);


--
-- Name: cloud_migration cloud_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.cloud_migration
    ADD CONSTRAINT cloud_migration_pkey PRIMARY KEY (id);


--
-- Name: collection_bookmark collection_bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection_bookmark
    ADD CONSTRAINT collection_bookmark_pkey PRIMARY KEY (id);


--
-- Name: collection collection_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection
    ADD CONSTRAINT collection_entity_id_key UNIQUE (entity_id);


--
-- Name: collection collection_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection
    ADD CONSTRAINT collection_pkey PRIMARY KEY (id);


--
-- Name: collection_permission_graph_revision collection_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection_permission_graph_revision
    ADD CONSTRAINT collection_revision_pkey PRIMARY KEY (id);


--
-- Name: connection_impersonations conn_impersonation_unique_group_id_db_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.connection_impersonations
    ADD CONSTRAINT conn_impersonation_unique_group_id_db_id UNIQUE (group_id, db_id);


--
-- Name: connection_impersonations connection_impersonations_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.connection_impersonations
    ADD CONSTRAINT connection_impersonations_pkey PRIMARY KEY (id);


--
-- Name: core_session core_session_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.core_session
    ADD CONSTRAINT core_session_pkey PRIMARY KEY (id);


--
-- Name: core_user core_user_email_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_email_key UNIQUE (email);


--
-- Name: core_user core_user_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_entity_id_key UNIQUE (entity_id);


--
-- Name: core_user core_user_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_pkey PRIMARY KEY (id);


--
-- Name: dashboard_bookmark dashboard_bookmark_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_bookmark
    ADD CONSTRAINT dashboard_bookmark_pkey PRIMARY KEY (id);


--
-- Name: dashboard_favorite dashboard_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_favorite
    ADD CONSTRAINT dashboard_favorite_pkey PRIMARY KEY (id);


--
-- Name: dashboard_tab dashboard_tab_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_tab
    ADD CONSTRAINT dashboard_tab_entity_id_key UNIQUE (entity_id);


--
-- Name: dashboard_tab dashboard_tab_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_tab
    ADD CONSTRAINT dashboard_tab_pkey PRIMARY KEY (id);


--
-- Name: dashboardcard_series dashboardcard_series_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboardcard_series
    ADD CONSTRAINT dashboardcard_series_pkey PRIMARY KEY (id);


--
-- Name: data_permissions data_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.data_permissions
    ADD CONSTRAINT data_permissions_pkey PRIMARY KEY (id);


--
-- Name: dependency dependency_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dependency
    ADD CONSTRAINT dependency_pkey PRIMARY KEY (id);


--
-- Name: dimension dimension_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dimension
    ADD CONSTRAINT dimension_entity_id_key UNIQUE (entity_id);


--
-- Name: dimension dimension_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dimension
    ADD CONSTRAINT dimension_pkey PRIMARY KEY (id);


--
-- Name: field_usage field_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.field_usage
    ADD CONSTRAINT field_usage_pkey PRIMARY KEY (id);


--
-- Name: application_permissions_revision general_permissions_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.application_permissions_revision
    ADD CONSTRAINT general_permissions_revision_pkey PRIMARY KEY (id);


--
-- Name: sandboxes group_table_access_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.sandboxes
    ADD CONSTRAINT group_table_access_policy_pkey PRIMARY KEY (id);


--
-- Name: cache_config idx_cache_config_unique_model; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.cache_config
    ADD CONSTRAINT idx_cache_config_unique_model UNIQUE (model, model_id);


--
-- Name: databasechangelog idx_databasechangelog_id_author_filename; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.databasechangelog
    ADD CONSTRAINT idx_databasechangelog_id_author_filename UNIQUE (id, author, filename);


--
-- Name: search_index_metadata idx_search_index_metadata_unique_status; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.search_index_metadata
    ADD CONSTRAINT idx_search_index_metadata_unique_status UNIQUE (engine, version, status);


--
-- Name: metabase_table idx_uniq_table_db_id_schema_name; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_table
    ADD CONSTRAINT idx_uniq_table_db_id_schema_name UNIQUE (db_id, schema, name);


--
-- Name: report_cardfavorite idx_unique_cardfavorite_card_id_owner_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_cardfavorite
    ADD CONSTRAINT idx_unique_cardfavorite_card_id_owner_id UNIQUE (card_id, owner_id);


--
-- Name: metabase_field idx_unique_field; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_field
    ADD CONSTRAINT idx_unique_field UNIQUE (name, table_id, unique_field_helper);


--
-- Name: label label_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_pkey PRIMARY KEY (id);


--
-- Name: label label_slug_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.label
    ADD CONSTRAINT label_slug_key UNIQUE (slug);


--
-- Name: login_history login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT login_history_pkey PRIMARY KEY (id);


--
-- Name: metabase_cluster_lock metabase_cluster_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_cluster_lock
    ADD CONSTRAINT metabase_cluster_lock_pkey PRIMARY KEY (lock_name);


--
-- Name: metabase_database metabase_database_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_database
    ADD CONSTRAINT metabase_database_entity_id_key UNIQUE (entity_id);


--
-- Name: metabase_database metabase_database_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_database
    ADD CONSTRAINT metabase_database_pkey PRIMARY KEY (id);


--
-- Name: metabase_field metabase_field_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_field
    ADD CONSTRAINT metabase_field_entity_id_key UNIQUE (entity_id);


--
-- Name: metabase_field metabase_field_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_field
    ADD CONSTRAINT metabase_field_pkey PRIMARY KEY (id);


--
-- Name: metabase_fieldvalues metabase_fieldvalues_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_fieldvalues
    ADD CONSTRAINT metabase_fieldvalues_pkey PRIMARY KEY (id);


--
-- Name: metabase_table metabase_table_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_table
    ADD CONSTRAINT metabase_table_entity_id_key UNIQUE (entity_id);


--
-- Name: metabase_table metabase_table_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_table
    ADD CONSTRAINT metabase_table_pkey PRIMARY KEY (id);


--
-- Name: metric metric_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric
    ADD CONSTRAINT metric_entity_id_key UNIQUE (entity_id);


--
-- Name: metric_important_field metric_important_field_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric_important_field
    ADD CONSTRAINT metric_important_field_pkey PRIMARY KEY (id);


--
-- Name: metric metric_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric
    ADD CONSTRAINT metric_pkey PRIMARY KEY (id);


--
-- Name: model_index model_index_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.model_index
    ADD CONSTRAINT model_index_pkey PRIMARY KEY (id);


--
-- Name: moderation_review moderation_review_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.moderation_review
    ADD CONSTRAINT moderation_review_pkey PRIMARY KEY (id);


--
-- Name: native_query_snippet native_query_snippet_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.native_query_snippet
    ADD CONSTRAINT native_query_snippet_entity_id_key UNIQUE (entity_id);


--
-- Name: native_query_snippet native_query_snippet_name_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.native_query_snippet
    ADD CONSTRAINT native_query_snippet_name_key UNIQUE (name);


--
-- Name: native_query_snippet native_query_snippet_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.native_query_snippet
    ADD CONSTRAINT native_query_snippet_pkey PRIMARY KEY (id);


--
-- Name: notification_card notification_card_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_card
    ADD CONSTRAINT notification_card_pkey PRIMARY KEY (id);


--
-- Name: notification_handler notification_handler_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_handler
    ADD CONSTRAINT notification_handler_pkey PRIMARY KEY (id);


--
-- Name: notification notification_internal_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_internal_id_key UNIQUE (internal_id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: notification_recipient notification_recipient_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_recipient
    ADD CONSTRAINT notification_recipient_pkey PRIMARY KEY (id);


--
-- Name: notification_subscription notification_subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_subscription
    ADD CONSTRAINT notification_subscription_pkey PRIMARY KEY (id);


--
-- Name: parameter_card parameter_card_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.parameter_card
    ADD CONSTRAINT parameter_card_pkey PRIMARY KEY (id);


--
-- Name: permissions_group permissions_group_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group
    ADD CONSTRAINT permissions_group_entity_id_key UNIQUE (entity_id);


--
-- Name: permissions permissions_group_id_object_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_group_id_object_key UNIQUE (group_id, object);


--
-- Name: permissions_group_membership permissions_group_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group_membership
    ADD CONSTRAINT permissions_group_membership_pkey PRIMARY KEY (id);


--
-- Name: permissions_group permissions_group_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group
    ADD CONSTRAINT permissions_group_pkey PRIMARY KEY (id);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: permissions_revision permissions_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_revision
    ADD CONSTRAINT permissions_revision_pkey PRIMARY KEY (id);


--
-- Name: persisted_info persisted_info_card_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.persisted_info
    ADD CONSTRAINT persisted_info_card_id_key UNIQUE (card_id);


--
-- Name: persisted_info persisted_info_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.persisted_info
    ADD CONSTRAINT persisted_info_pkey PRIMARY KEY (id);


--
-- Name: http_action pk_http_action; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.http_action
    ADD CONSTRAINT pk_http_action PRIMARY KEY (action_id);


--
-- Name: implicit_action pk_implicit_action; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.implicit_action
    ADD CONSTRAINT pk_implicit_action PRIMARY KEY (action_id);


--
-- Name: qrtz_blob_triggers pk_qrtz_blob_triggers; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_blob_triggers
    ADD CONSTRAINT pk_qrtz_blob_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_calendars pk_qrtz_calendars; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_calendars
    ADD CONSTRAINT pk_qrtz_calendars PRIMARY KEY (sched_name, calendar_name);


--
-- Name: qrtz_cron_triggers pk_qrtz_cron_triggers; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_cron_triggers
    ADD CONSTRAINT pk_qrtz_cron_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_fired_triggers pk_qrtz_fired_triggers; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_fired_triggers
    ADD CONSTRAINT pk_qrtz_fired_triggers PRIMARY KEY (sched_name, entry_id);


--
-- Name: qrtz_job_details pk_qrtz_job_details; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_job_details
    ADD CONSTRAINT pk_qrtz_job_details PRIMARY KEY (sched_name, job_name, job_group);


--
-- Name: qrtz_locks pk_qrtz_locks; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_locks
    ADD CONSTRAINT pk_qrtz_locks PRIMARY KEY (sched_name, lock_name);


--
-- Name: qrtz_scheduler_state pk_qrtz_scheduler_state; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_scheduler_state
    ADD CONSTRAINT pk_qrtz_scheduler_state PRIMARY KEY (sched_name, instance_name);


--
-- Name: qrtz_simple_triggers pk_qrtz_simple_triggers; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_simple_triggers
    ADD CONSTRAINT pk_qrtz_simple_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_simprop_triggers pk_qrtz_simprop_triggers; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_simprop_triggers
    ADD CONSTRAINT pk_qrtz_simprop_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_triggers pk_qrtz_triggers; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_triggers
    ADD CONSTRAINT pk_qrtz_triggers PRIMARY KEY (sched_name, trigger_name, trigger_group);


--
-- Name: query_action pk_query_action; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_action
    ADD CONSTRAINT pk_query_action PRIMARY KEY (action_id);


--
-- Name: qrtz_paused_trigger_grps pk_sched_name; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_paused_trigger_grps
    ADD CONSTRAINT pk_sched_name PRIMARY KEY (sched_name, trigger_group);


--
-- Name: pulse_card pulse_card_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_card
    ADD CONSTRAINT pulse_card_entity_id_key UNIQUE (entity_id);


--
-- Name: pulse_card pulse_card_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_card
    ADD CONSTRAINT pulse_card_pkey PRIMARY KEY (id);


--
-- Name: pulse_channel pulse_channel_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel
    ADD CONSTRAINT pulse_channel_entity_id_key UNIQUE (entity_id);


--
-- Name: pulse_channel pulse_channel_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel
    ADD CONSTRAINT pulse_channel_pkey PRIMARY KEY (id);


--
-- Name: pulse_channel_recipient pulse_channel_recipient_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel_recipient
    ADD CONSTRAINT pulse_channel_recipient_pkey PRIMARY KEY (id);


--
-- Name: pulse pulse_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse
    ADD CONSTRAINT pulse_entity_id_key UNIQUE (entity_id);


--
-- Name: pulse pulse_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse
    ADD CONSTRAINT pulse_pkey PRIMARY KEY (id);


--
-- Name: query_analysis query_analysis_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_analysis
    ADD CONSTRAINT query_analysis_pkey PRIMARY KEY (id);


--
-- Name: query_cache query_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_cache
    ADD CONSTRAINT query_cache_pkey PRIMARY KEY (query_hash);


--
-- Name: query_execution query_execution_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_execution
    ADD CONSTRAINT query_execution_pkey PRIMARY KEY (id);


--
-- Name: query_field query_field_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_field
    ADD CONSTRAINT query_field_pkey PRIMARY KEY (id);


--
-- Name: query query_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query
    ADD CONSTRAINT query_pkey PRIMARY KEY (query_hash);


--
-- Name: query_table query_table_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_table
    ADD CONSTRAINT query_table_pkey PRIMARY KEY (id);


--
-- Name: recent_views recent_views_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.recent_views
    ADD CONSTRAINT recent_views_pkey PRIMARY KEY (id);


--
-- Name: report_card report_card_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT report_card_entity_id_key UNIQUE (entity_id);


--
-- Name: report_card report_card_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT report_card_pkey PRIMARY KEY (id);


--
-- Name: report_card report_card_public_uuid_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT report_card_public_uuid_key UNIQUE (public_uuid);


--
-- Name: report_cardfavorite report_cardfavorite_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_cardfavorite
    ADD CONSTRAINT report_cardfavorite_pkey PRIMARY KEY (id);


--
-- Name: report_dashboard report_dashboard_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboard
    ADD CONSTRAINT report_dashboard_entity_id_key UNIQUE (entity_id);


--
-- Name: report_dashboard report_dashboard_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboard
    ADD CONSTRAINT report_dashboard_pkey PRIMARY KEY (id);


--
-- Name: report_dashboard report_dashboard_public_uuid_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboard
    ADD CONSTRAINT report_dashboard_public_uuid_key UNIQUE (public_uuid);


--
-- Name: report_dashboardcard report_dashboardcard_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboardcard
    ADD CONSTRAINT report_dashboardcard_entity_id_key UNIQUE (entity_id);


--
-- Name: report_dashboardcard report_dashboardcard_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboardcard
    ADD CONSTRAINT report_dashboardcard_pkey PRIMARY KEY (id);


--
-- Name: revision revision_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.revision
    ADD CONSTRAINT revision_pkey PRIMARY KEY (id);


--
-- Name: search_index_metadata search_index_metadata_index_name_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.search_index_metadata
    ADD CONSTRAINT search_index_metadata_index_name_key UNIQUE (index_name);


--
-- Name: search_index_metadata search_index_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.search_index_metadata
    ADD CONSTRAINT search_index_metadata_pkey PRIMARY KEY (id);


--
-- Name: secret secret_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.secret
    ADD CONSTRAINT secret_pkey PRIMARY KEY (id, version);


--
-- Name: segment segment_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.segment
    ADD CONSTRAINT segment_entity_id_key UNIQUE (entity_id);


--
-- Name: segment segment_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.segment
    ADD CONSTRAINT segment_pkey PRIMARY KEY (id);


--
-- Name: setting setting_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.setting
    ADD CONSTRAINT setting_pkey PRIMARY KEY (key);


--
-- Name: task_history task_history_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.task_history
    ADD CONSTRAINT task_history_pkey PRIMARY KEY (id);


--
-- Name: timeline timeline_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline
    ADD CONSTRAINT timeline_entity_id_key UNIQUE (entity_id);


--
-- Name: timeline_event timeline_event_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline_event
    ADD CONSTRAINT timeline_event_pkey PRIMARY KEY (id);


--
-- Name: timeline timeline_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline
    ADD CONSTRAINT timeline_pkey PRIMARY KEY (id);


--
-- Name: bookmark_ordering unique_bookmark_user_id_ordering; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.bookmark_ordering
    ADD CONSTRAINT unique_bookmark_user_id_ordering UNIQUE (user_id, ordering);


--
-- Name: bookmark_ordering unique_bookmark_user_id_type_item_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.bookmark_ordering
    ADD CONSTRAINT unique_bookmark_user_id_type_item_id UNIQUE (user_id, type, item_id);


--
-- Name: card_bookmark unique_card_bookmark_user_id_card_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_bookmark
    ADD CONSTRAINT unique_card_bookmark_user_id_card_id UNIQUE (user_id, card_id);


--
-- Name: card_label unique_card_label_card_id_label_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT unique_card_label_card_id_label_id UNIQUE (card_id, label_id);


--
-- Name: collection_bookmark unique_collection_bookmark_user_id_collection_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection_bookmark
    ADD CONSTRAINT unique_collection_bookmark_user_id_collection_id UNIQUE (user_id, collection_id);


--
-- Name: collection unique_collection_personal_owner_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection
    ADD CONSTRAINT unique_collection_personal_owner_id UNIQUE (personal_owner_id);


--
-- Name: dashboard_bookmark unique_dashboard_bookmark_user_id_dashboard_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_bookmark
    ADD CONSTRAINT unique_dashboard_bookmark_user_id_dashboard_id UNIQUE (user_id, dashboard_id);


--
-- Name: dashboard_favorite unique_dashboard_favorite_user_id_dashboard_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_favorite
    ADD CONSTRAINT unique_dashboard_favorite_user_id_dashboard_id UNIQUE (user_id, dashboard_id);


--
-- Name: dimension unique_dimension_field_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dimension
    ADD CONSTRAINT unique_dimension_field_id UNIQUE (field_id);


--
-- Name: sandboxes unique_gtap_table_id_group_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.sandboxes
    ADD CONSTRAINT unique_gtap_table_id_group_id UNIQUE (table_id, group_id);


--
-- Name: metric_important_field unique_metric_important_field_metric_id_field_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric_important_field
    ADD CONSTRAINT unique_metric_important_field_metric_id_field_id UNIQUE (metric_id, field_id);


--
-- Name: model_index_value unique_model_index_value_model_index_id_model_pk; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.model_index_value
    ADD CONSTRAINT unique_model_index_value_model_index_id_model_pk UNIQUE (model_index_id, model_pk);


--
-- Name: parameter_card unique_parameterized_object_card_parameter; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.parameter_card
    ADD CONSTRAINT unique_parameterized_object_card_parameter UNIQUE (parameterized_object_id, parameterized_object_type, parameter_id);


--
-- Name: permissions_group_membership unique_permissions_group_membership_user_id_group_id; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group_membership
    ADD CONSTRAINT unique_permissions_group_membership_user_id_group_id UNIQUE (user_id, group_id);


--
-- Name: permissions_group unique_permissions_group_name; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group
    ADD CONSTRAINT unique_permissions_group_name UNIQUE (name);


--
-- Name: user_key_value unique_user_key_value_user_id_namespace_key; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.user_key_value
    ADD CONSTRAINT unique_user_key_value_user_id_namespace_key UNIQUE (user_id, namespace, key);


--
-- Name: user_key_value user_key_value_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.user_key_value
    ADD CONSTRAINT user_key_value_pkey PRIMARY KEY (id);


--
-- Name: user_parameter_value user_parameter_value_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.user_parameter_value
    ADD CONSTRAINT user_parameter_value_pkey PRIMARY KEY (id);


--
-- Name: view_log view_log_pkey; Type: CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.view_log
    ADD CONSTRAINT view_log_pkey PRIMARY KEY (id);


--
-- Name: idx_action_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_action_creator_id ON public.action USING btree (creator_id);


--
-- Name: idx_action_made_public_by_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_action_made_public_by_id ON public.action USING btree (made_public_by_id);


--
-- Name: idx_action_model_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_action_model_id ON public.action USING btree (model_id);


--
-- Name: idx_action_public_uuid; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_action_public_uuid ON public.action USING btree (public_uuid);


--
-- Name: idx_api_key_created_by; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_api_key_created_by ON public.api_key USING btree (creator_id);


--
-- Name: idx_api_key_updated_by_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_api_key_updated_by_id ON public.api_key USING btree (updated_by_id);


--
-- Name: idx_api_key_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_api_key_user_id ON public.api_key USING btree (user_id);


--
-- Name: idx_application_permissions_revision_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_application_permissions_revision_user_id ON public.application_permissions_revision USING btree (user_id);


--
-- Name: idx_audit_log_entity_qualified_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_audit_log_entity_qualified_id ON public.audit_log USING btree ((
CASE
    WHEN ((model)::text = 'Dataset'::text) THEN ('card_'::text || model_id)
    WHEN (model_id IS NULL) THEN NULL::text
    ELSE ((lower((model)::text) || '_'::text) || model_id)
END));


--
-- Name: idx_bookmark_ordering_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_bookmark_ordering_user_id ON public.bookmark_ordering USING btree (user_id);


--
-- Name: idx_card_bookmark_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_bookmark_card_id ON public.card_bookmark USING btree (card_id);


--
-- Name: idx_card_bookmark_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_bookmark_user_id ON public.card_bookmark USING btree (user_id);


--
-- Name: idx_card_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_collection_id ON public.report_card USING btree (collection_id);


--
-- Name: idx_card_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_creator_id ON public.report_card USING btree (creator_id);


--
-- Name: idx_card_label_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_label_card_id ON public.card_label USING btree (card_id);


--
-- Name: idx_card_label_label_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_label_label_id ON public.card_label USING btree (label_id);


--
-- Name: idx_card_public_uuid; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_card_public_uuid ON public.report_card USING btree (public_uuid);


--
-- Name: idx_cardfavorite_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_cardfavorite_card_id ON public.report_cardfavorite USING btree (card_id);


--
-- Name: idx_cardfavorite_owner_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_cardfavorite_owner_id ON public.report_cardfavorite USING btree (owner_id);


--
-- Name: idx_collection_bookmark_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_collection_bookmark_collection_id ON public.collection_bookmark USING btree (collection_id);


--
-- Name: idx_collection_bookmark_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_collection_bookmark_user_id ON public.collection_bookmark USING btree (user_id);


--
-- Name: idx_collection_location; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_collection_location ON public.collection USING btree (location);


--
-- Name: idx_collection_permission_graph_revision_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_collection_permission_graph_revision_user_id ON public.collection_permission_graph_revision USING btree (user_id);


--
-- Name: idx_collection_personal_owner_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_collection_personal_owner_id ON public.collection USING btree (personal_owner_id);


--
-- Name: idx_collection_type; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_collection_type ON public.collection USING btree (type);


--
-- Name: idx_conn_impersonations_db_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_conn_impersonations_db_id ON public.connection_impersonations USING btree (db_id);


--
-- Name: idx_conn_impersonations_group_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_conn_impersonations_group_id ON public.connection_impersonations USING btree (group_id);


--
-- Name: idx_core_session_key_hashed; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_core_session_key_hashed ON public.core_session USING btree (key_hashed);


--
-- Name: idx_core_session_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_core_session_user_id ON public.core_session USING btree (user_id);


--
-- Name: idx_dashboard_bookmark_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_bookmark_dashboard_id ON public.dashboard_bookmark USING btree (dashboard_id);


--
-- Name: idx_dashboard_bookmark_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_bookmark_user_id ON public.dashboard_bookmark USING btree (user_id);


--
-- Name: idx_dashboard_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_collection_id ON public.report_dashboard USING btree (collection_id);


--
-- Name: idx_dashboard_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_creator_id ON public.report_dashboard USING btree (creator_id);


--
-- Name: idx_dashboard_favorite_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_favorite_dashboard_id ON public.dashboard_favorite USING btree (dashboard_id);


--
-- Name: idx_dashboard_favorite_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_favorite_user_id ON public.dashboard_favorite USING btree (user_id);


--
-- Name: idx_dashboard_public_uuid; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_public_uuid ON public.report_dashboard USING btree (public_uuid);


--
-- Name: idx_dashboard_tab_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboard_tab_dashboard_id ON public.dashboard_tab USING btree (dashboard_id);


--
-- Name: idx_dashboardcard_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboardcard_card_id ON public.report_dashboardcard USING btree (card_id);


--
-- Name: idx_dashboardcard_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboardcard_dashboard_id ON public.report_dashboardcard USING btree (dashboard_id);


--
-- Name: idx_dashboardcard_series_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboardcard_series_card_id ON public.dashboardcard_series USING btree (card_id);


--
-- Name: idx_dashboardcard_series_dashboardcard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dashboardcard_series_dashboardcard_id ON public.dashboardcard_series USING btree (dashboardcard_id);


--
-- Name: idx_data_permissions_db_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_data_permissions_db_id ON public.data_permissions USING btree (db_id);


--
-- Name: idx_data_permissions_group_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_data_permissions_group_id ON public.data_permissions USING btree (group_id);


--
-- Name: idx_data_permissions_group_id_db_id_perm_value; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_data_permissions_group_id_db_id_perm_value ON public.data_permissions USING btree (group_id, db_id, perm_value);


--
-- Name: idx_data_permissions_group_id_db_id_table_id_perm_value; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_data_permissions_group_id_db_id_table_id_perm_value ON public.data_permissions USING btree (group_id, db_id, table_id, perm_value);


--
-- Name: idx_data_permissions_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_data_permissions_table_id ON public.data_permissions USING btree (table_id);


--
-- Name: idx_dependency_dependent_on_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dependency_dependent_on_id ON public.dependency USING btree (dependent_on_id);


--
-- Name: idx_dependency_dependent_on_model; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dependency_dependent_on_model ON public.dependency USING btree (dependent_on_model);


--
-- Name: idx_dependency_model; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dependency_model ON public.dependency USING btree (model);


--
-- Name: idx_dependency_model_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dependency_model_id ON public.dependency USING btree (model_id);


--
-- Name: idx_dimension_field_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dimension_field_id ON public.dimension USING btree (field_id);


--
-- Name: idx_dimension_human_readable_field_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_dimension_human_readable_field_id ON public.dimension USING btree (human_readable_field_id);


--
-- Name: idx_field_entity_qualified_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_field_entity_qualified_id ON public.metabase_field USING btree ((('field_'::text || id)));


--
-- Name: idx_field_name_lower; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_field_name_lower ON public.metabase_field USING btree (lower((name)::text));


--
-- Name: idx_field_parent_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_field_parent_id ON public.metabase_field USING btree (parent_id);


--
-- Name: idx_field_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_field_table_id ON public.metabase_field USING btree (table_id);


--
-- Name: idx_field_usage_field_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_field_usage_field_id ON public.field_usage USING btree (field_id);


--
-- Name: idx_field_usage_query_execution_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_field_usage_query_execution_id ON public.field_usage USING btree (query_execution_id);


--
-- Name: idx_fieldvalues_field_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_fieldvalues_field_id ON public.metabase_fieldvalues USING btree (field_id);


--
-- Name: idx_gtap_table_id_group_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_gtap_table_id_group_id ON public.sandboxes USING btree (table_id, group_id);


--
-- Name: idx_label_slug; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_label_slug ON public.label USING btree (slug);


--
-- Name: idx_lower_email; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_lower_email ON public.core_user USING btree (lower((email)::text));


--
-- Name: idx_metabase_database_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metabase_database_creator_id ON public.metabase_database USING btree (creator_id);


--
-- Name: idx_metabase_table_db_id_schema; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metabase_table_db_id_schema ON public.metabase_table USING btree (db_id, schema);


--
-- Name: idx_metabase_table_show_in_getting_started; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metabase_table_show_in_getting_started ON public.metabase_table USING btree (show_in_getting_started);


--
-- Name: idx_metric_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metric_creator_id ON public.metric USING btree (creator_id);


--
-- Name: idx_metric_important_field_field_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metric_important_field_field_id ON public.metric_important_field USING btree (field_id);


--
-- Name: idx_metric_important_field_metric_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metric_important_field_metric_id ON public.metric_important_field USING btree (metric_id);


--
-- Name: idx_metric_show_in_getting_started; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metric_show_in_getting_started ON public.metric USING btree (show_in_getting_started);


--
-- Name: idx_metric_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_metric_table_id ON public.metric USING btree (table_id);


--
-- Name: idx_model_index_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_model_index_creator_id ON public.model_index USING btree (creator_id);


--
-- Name: idx_model_index_model_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_model_index_model_id ON public.model_index USING btree (model_id);


--
-- Name: idx_moderation_review_item_type_item_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_moderation_review_item_type_item_id ON public.moderation_review USING btree (moderated_item_type, moderated_item_id);


--
-- Name: idx_native_query_snippet_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_native_query_snippet_creator_id ON public.native_query_snippet USING btree (creator_id);


--
-- Name: idx_notification_card_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_card_card_id ON public.notification_card USING btree (card_id);


--
-- Name: idx_notification_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_creator_id ON public.notification USING btree (creator_id);


--
-- Name: idx_notification_handler_channel_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_handler_channel_id ON public.notification_handler USING btree (channel_id);


--
-- Name: idx_notification_handler_notification_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_handler_notification_id ON public.notification_handler USING btree (notification_id);


--
-- Name: idx_notification_handler_template_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_handler_template_id ON public.notification_handler USING btree (template_id);


--
-- Name: idx_notification_recipient_notification_handler_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_recipient_notification_handler_id ON public.notification_recipient USING btree (notification_handler_id);


--
-- Name: idx_notification_recipient_permissions_group_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_recipient_permissions_group_id ON public.notification_recipient USING btree (permissions_group_id);


--
-- Name: idx_notification_recipient_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_recipient_user_id ON public.notification_recipient USING btree (user_id);


--
-- Name: idx_notification_subscription_notification_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_notification_subscription_notification_id ON public.notification_subscription USING btree (notification_id);


--
-- Name: idx_parameter_card_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_parameter_card_card_id ON public.parameter_card USING btree (card_id);


--
-- Name: idx_parameter_card_parameterized_object_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_parameter_card_parameterized_object_id ON public.parameter_card USING btree (parameterized_object_id);


--
-- Name: idx_permissions_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_collection_id ON public.permissions USING btree (collection_id);


--
-- Name: idx_permissions_group_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_group_id ON public.permissions USING btree (group_id);


--
-- Name: idx_permissions_group_id_object; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_group_id_object ON public.permissions USING btree (group_id, object);


--
-- Name: idx_permissions_group_membership_group_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_group_membership_group_id ON public.permissions_group_membership USING btree (group_id);


--
-- Name: idx_permissions_group_membership_group_id_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_group_membership_group_id_user_id ON public.permissions_group_membership USING btree (group_id, user_id);


--
-- Name: idx_permissions_group_membership_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_group_membership_user_id ON public.permissions_group_membership USING btree (user_id);


--
-- Name: idx_permissions_group_name; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_group_name ON public.permissions_group USING btree (name);


--
-- Name: idx_permissions_object; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_object ON public.permissions USING btree (object);


--
-- Name: idx_permissions_perm_type; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_perm_type ON public.permissions USING btree (perm_type);


--
-- Name: idx_permissions_perm_value; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_perm_value ON public.permissions USING btree (perm_value);


--
-- Name: idx_permissions_revision_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_permissions_revision_user_id ON public.permissions_revision USING btree (user_id);


--
-- Name: idx_persisted_info_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_persisted_info_creator_id ON public.persisted_info USING btree (creator_id);


--
-- Name: idx_persisted_info_database_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_persisted_info_database_id ON public.persisted_info USING btree (database_id);


--
-- Name: idx_pulse_card_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_card_card_id ON public.pulse_card USING btree (card_id);


--
-- Name: idx_pulse_card_dashboard_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_card_dashboard_card_id ON public.pulse_card USING btree (dashboard_card_id);


--
-- Name: idx_pulse_card_pulse_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_card_pulse_id ON public.pulse_card USING btree (pulse_id);


--
-- Name: idx_pulse_channel_pulse_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_channel_pulse_id ON public.pulse_channel USING btree (pulse_id);


--
-- Name: idx_pulse_channel_recipient_pulse_channel_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_channel_recipient_pulse_channel_id ON public.pulse_channel_recipient USING btree (pulse_channel_id);


--
-- Name: idx_pulse_channel_recipient_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_channel_recipient_user_id ON public.pulse_channel_recipient USING btree (user_id);


--
-- Name: idx_pulse_channel_schedule_type; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_channel_schedule_type ON public.pulse_channel USING btree (schedule_type);


--
-- Name: idx_pulse_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_collection_id ON public.pulse USING btree (collection_id);


--
-- Name: idx_pulse_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_creator_id ON public.pulse USING btree (creator_id);


--
-- Name: idx_pulse_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_pulse_dashboard_id ON public.pulse USING btree (dashboard_id);


--
-- Name: idx_qrtz_ft_inst_job_req_rcvry; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_ft_inst_job_req_rcvry ON public.qrtz_fired_triggers USING btree (sched_name, instance_name, requests_recovery);


--
-- Name: idx_qrtz_ft_j_g; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_ft_j_g ON public.qrtz_fired_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: idx_qrtz_ft_jg; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_ft_jg ON public.qrtz_fired_triggers USING btree (sched_name, job_group);


--
-- Name: idx_qrtz_ft_t_g; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_ft_t_g ON public.qrtz_fired_triggers USING btree (sched_name, trigger_name, trigger_group);


--
-- Name: idx_qrtz_ft_tg; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_ft_tg ON public.qrtz_fired_triggers USING btree (sched_name, trigger_group);


--
-- Name: idx_qrtz_ft_trig_inst_name; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_ft_trig_inst_name ON public.qrtz_fired_triggers USING btree (sched_name, instance_name);


--
-- Name: idx_qrtz_j_grp; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_j_grp ON public.qrtz_job_details USING btree (sched_name, job_group);


--
-- Name: idx_qrtz_j_req_recovery; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_j_req_recovery ON public.qrtz_job_details USING btree (sched_name, requests_recovery);


--
-- Name: idx_qrtz_t_c; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_c ON public.qrtz_triggers USING btree (sched_name, calendar_name);


--
-- Name: idx_qrtz_t_g; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_g ON public.qrtz_triggers USING btree (sched_name, trigger_group);


--
-- Name: idx_qrtz_t_j; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_j ON public.qrtz_triggers USING btree (sched_name, job_name, job_group);


--
-- Name: idx_qrtz_t_jg; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_jg ON public.qrtz_triggers USING btree (sched_name, job_group);


--
-- Name: idx_qrtz_t_n_g_state; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_n_g_state ON public.qrtz_triggers USING btree (sched_name, trigger_group, trigger_state);


--
-- Name: idx_qrtz_t_n_state; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_n_state ON public.qrtz_triggers USING btree (sched_name, trigger_name, trigger_group, trigger_state);


--
-- Name: idx_qrtz_t_next_fire_time; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_next_fire_time ON public.qrtz_triggers USING btree (sched_name, next_fire_time);


--
-- Name: idx_qrtz_t_nft_misfire; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_nft_misfire ON public.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time);


--
-- Name: idx_qrtz_t_nft_st; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_nft_st ON public.qrtz_triggers USING btree (sched_name, trigger_state, next_fire_time);


--
-- Name: idx_qrtz_t_nft_st_misfire; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_nft_st_misfire ON public.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_state);


--
-- Name: idx_qrtz_t_nft_st_misfire_grp; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_nft_st_misfire_grp ON public.qrtz_triggers USING btree (sched_name, misfire_instr, next_fire_time, trigger_group, trigger_state);


--
-- Name: idx_qrtz_t_state; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_qrtz_t_state ON public.qrtz_triggers USING btree (sched_name, trigger_state);


--
-- Name: idx_query_action_database_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_action_database_id ON public.query_action USING btree (database_id);


--
-- Name: idx_query_analysis_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_analysis_card_id ON public.query_analysis USING btree (card_id);


--
-- Name: idx_query_cache_updated_at; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_cache_updated_at ON public.query_cache USING btree (updated_at);


--
-- Name: idx_query_execution_action_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_action_id ON public.query_execution USING btree (action_id);


--
-- Name: idx_query_execution_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_card_id ON public.query_execution USING btree (card_id);


--
-- Name: idx_query_execution_card_id_started_at; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_card_id_started_at ON public.query_execution USING btree (card_id, started_at);


--
-- Name: idx_query_execution_card_qualified_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_card_qualified_id ON public.query_execution USING btree ((('card_'::text || card_id)));


--
-- Name: idx_query_execution_context; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_context ON public.query_execution USING btree (context);


--
-- Name: idx_query_execution_executor_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_executor_id ON public.query_execution USING btree (executor_id);


--
-- Name: idx_query_execution_query_hash_started_at; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_query_hash_started_at ON public.query_execution USING btree (hash, started_at);


--
-- Name: idx_query_execution_started_at; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_execution_started_at ON public.query_execution USING btree (started_at);


--
-- Name: idx_query_field_analysis_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_field_analysis_id ON public.query_field USING btree (analysis_id);


--
-- Name: idx_query_field_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_field_card_id ON public.query_field USING btree (card_id);


--
-- Name: idx_query_field_field_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_field_field_id ON public.query_field USING btree (field_id);


--
-- Name: idx_query_table_analysis_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_table_analysis_id ON public.query_table USING btree (analysis_id);


--
-- Name: idx_query_table_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_table_card_id ON public.query_table USING btree (card_id);


--
-- Name: idx_query_table_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_query_table_table_id ON public.query_table USING btree (table_id);


--
-- Name: idx_recent_views_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_recent_views_user_id ON public.recent_views USING btree (user_id);


--
-- Name: idx_report_card_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_card_dashboard_id ON public.report_card USING btree (dashboard_id);


--
-- Name: idx_report_card_database_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_card_database_id ON public.report_card USING btree (database_id);


--
-- Name: idx_report_card_made_public_by_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_card_made_public_by_id ON public.report_card USING btree (made_public_by_id);


--
-- Name: idx_report_card_source_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_card_source_card_id ON public.report_card USING btree (source_card_id);


--
-- Name: idx_report_card_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_card_table_id ON public.report_card USING btree (table_id);


--
-- Name: idx_report_dashboard_made_public_by_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_dashboard_made_public_by_id ON public.report_dashboard USING btree (made_public_by_id);


--
-- Name: idx_report_dashboard_show_in_getting_started; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_dashboard_show_in_getting_started ON public.report_dashboard USING btree (show_in_getting_started);


--
-- Name: idx_report_dashboardcard_action_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_dashboardcard_action_id ON public.report_dashboardcard USING btree (action_id);


--
-- Name: idx_report_dashboardcard_dashboard_tab_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_report_dashboardcard_dashboard_tab_id ON public.report_dashboardcard USING btree (dashboard_tab_id);


--
-- Name: idx_revision_model_model_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_revision_model_model_id ON public.revision USING btree (model, model_id);


--
-- Name: idx_revision_most_recent; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_revision_most_recent ON public.revision USING btree (most_recent);


--
-- Name: idx_revision_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_revision_user_id ON public.revision USING btree (user_id);


--
-- Name: idx_sandboxes_card_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_sandboxes_card_id ON public.sandboxes USING btree (card_id);


--
-- Name: idx_secret_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_secret_creator_id ON public.secret USING btree (creator_id);


--
-- Name: idx_segment_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_segment_creator_id ON public.segment USING btree (creator_id);


--
-- Name: idx_segment_show_in_getting_started; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_segment_show_in_getting_started ON public.segment USING btree (show_in_getting_started);


--
-- Name: idx_segment_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_segment_table_id ON public.segment USING btree (table_id);


--
-- Name: idx_session_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_session_id ON public.login_history USING btree (session_id);


--
-- Name: idx_snippet_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_snippet_collection_id ON public.native_query_snippet USING btree (collection_id);


--
-- Name: idx_snippet_name; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_snippet_name ON public.native_query_snippet USING btree (name);


--
-- Name: idx_table_db_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_table_db_id ON public.metabase_table USING btree (db_id);


--
-- Name: idx_table_privileges_role; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_table_privileges_role ON public.table_privileges USING btree (role);


--
-- Name: idx_table_privileges_table_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_table_privileges_table_id ON public.table_privileges USING btree (table_id);


--
-- Name: idx_task_history_db_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_task_history_db_id ON public.task_history USING btree (db_id);


--
-- Name: idx_task_history_end_time; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_task_history_end_time ON public.task_history USING btree (ended_at);


--
-- Name: idx_task_history_started_at; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_task_history_started_at ON public.task_history USING btree (started_at);


--
-- Name: idx_timeline_collection_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_timeline_collection_id ON public.timeline USING btree (collection_id);


--
-- Name: idx_timeline_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_timeline_creator_id ON public.timeline USING btree (creator_id);


--
-- Name: idx_timeline_event_creator_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_timeline_event_creator_id ON public.timeline_event USING btree (creator_id);


--
-- Name: idx_timeline_event_timeline_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_timeline_event_timeline_id ON public.timeline_event USING btree (timeline_id);


--
-- Name: idx_timeline_event_timeline_id_timestamp; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_timeline_event_timeline_id_timestamp ON public.timeline_event USING btree (timeline_id, "timestamp");


--
-- Name: idx_timestamp; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_timestamp ON public.login_history USING btree ("timestamp");


--
-- Name: idx_uniq_table_db_id_schema_name_2col; Type: INDEX; Schema: public; Owner: metabase
--

CREATE UNIQUE INDEX idx_uniq_table_db_id_schema_name_2col ON public.metabase_table USING btree (db_id, name) WHERE (schema IS NULL);


--
-- Name: idx_user_full_name; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_full_name ON public.core_user USING btree (((((first_name)::text || ' '::text) || (last_name)::text)));


--
-- Name: idx_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_id ON public.login_history USING btree (user_id);


--
-- Name: idx_user_id_device_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_id_device_id ON public.login_history USING btree (user_id, device_id);


--
-- Name: idx_user_id_timestamp; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_id_timestamp ON public.login_history USING btree (user_id, "timestamp");


--
-- Name: idx_user_parameter_value_dashboard_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_parameter_value_dashboard_id ON public.user_parameter_value USING btree (dashboard_id);


--
-- Name: idx_user_parameter_value_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_parameter_value_user_id ON public.user_parameter_value USING btree (user_id);


--
-- Name: idx_user_parameter_value_user_id_dashboard_id_parameter_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_parameter_value_user_id_dashboard_id_parameter_id ON public.user_parameter_value USING btree (user_id, dashboard_id, parameter_id);


--
-- Name: idx_user_qualified_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_user_qualified_id ON public.core_user USING btree ((('user_'::text || id)));


--
-- Name: idx_view_log_entity_qualified_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_view_log_entity_qualified_id ON public.view_log USING btree (((((model)::text || '_'::text) || model_id)));


--
-- Name: idx_view_log_model_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_view_log_model_id ON public.view_log USING btree (model_id);


--
-- Name: idx_view_log_timestamp; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_view_log_timestamp ON public.view_log USING btree ("timestamp");


--
-- Name: idx_view_log_user_id; Type: INDEX; Schema: public; Owner: metabase
--

CREATE INDEX idx_view_log_user_id ON public.view_log USING btree (user_id);


--
-- Name: action fk_action_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT fk_action_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id);


--
-- Name: action fk_action_made_public_by_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT fk_action_made_public_by_id FOREIGN KEY (made_public_by_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: action fk_action_model_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.action
    ADD CONSTRAINT fk_action_model_id FOREIGN KEY (model_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: api_key fk_api_key_created_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT fk_api_key_created_by_user_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id);


--
-- Name: api_key fk_api_key_updated_by_id_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT fk_api_key_updated_by_id_user_id FOREIGN KEY (updated_by_id) REFERENCES public.core_user(id);


--
-- Name: api_key fk_api_key_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT fk_api_key_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id);


--
-- Name: bookmark_ordering fk_bookmark_ordering_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.bookmark_ordering
    ADD CONSTRAINT fk_bookmark_ordering_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: card_bookmark fk_card_bookmark_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_bookmark
    ADD CONSTRAINT fk_card_bookmark_dashboard_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: card_bookmark fk_card_bookmark_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_bookmark
    ADD CONSTRAINT fk_card_bookmark_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_card fk_card_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_card_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE SET NULL;


--
-- Name: card_label fk_card_label_ref_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT fk_card_label_ref_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: card_label fk_card_label_ref_label_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.card_label
    ADD CONSTRAINT fk_card_label_ref_label_id FOREIGN KEY (label_id) REFERENCES public.label(id) ON DELETE CASCADE;


--
-- Name: report_card fk_card_made_public_by_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_card_made_public_by_id FOREIGN KEY (made_public_by_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_card fk_card_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_card_ref_user_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_cardfavorite fk_cardfavorite_ref_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_cardfavorite
    ADD CONSTRAINT fk_cardfavorite_ref_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: report_cardfavorite fk_cardfavorite_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_cardfavorite
    ADD CONSTRAINT fk_cardfavorite_ref_user_id FOREIGN KEY (owner_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: collection_bookmark fk_collection_bookmark_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection_bookmark
    ADD CONSTRAINT fk_collection_bookmark_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE CASCADE;


--
-- Name: collection_bookmark fk_collection_bookmark_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection_bookmark
    ADD CONSTRAINT fk_collection_bookmark_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: collection fk_collection_personal_owner_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection
    ADD CONSTRAINT fk_collection_personal_owner_id FOREIGN KEY (personal_owner_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: collection_permission_graph_revision fk_collection_revision_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.collection_permission_graph_revision
    ADD CONSTRAINT fk_collection_revision_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: connection_impersonations fk_conn_impersonation_db_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.connection_impersonations
    ADD CONSTRAINT fk_conn_impersonation_db_id FOREIGN KEY (db_id) REFERENCES public.metabase_database(id) ON DELETE CASCADE;


--
-- Name: connection_impersonations fk_conn_impersonation_group_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.connection_impersonations
    ADD CONSTRAINT fk_conn_impersonation_group_id FOREIGN KEY (group_id) REFERENCES public.permissions_group(id) ON DELETE CASCADE;


--
-- Name: dashboard_bookmark fk_dashboard_bookmark_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_bookmark
    ADD CONSTRAINT fk_dashboard_bookmark_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: dashboard_bookmark fk_dashboard_bookmark_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_bookmark
    ADD CONSTRAINT fk_dashboard_bookmark_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_dashboard fk_dashboard_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboard
    ADD CONSTRAINT fk_dashboard_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE SET NULL;


--
-- Name: dashboard_favorite fk_dashboard_favorite_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_favorite
    ADD CONSTRAINT fk_dashboard_favorite_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: dashboard_favorite fk_dashboard_favorite_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_favorite
    ADD CONSTRAINT fk_dashboard_favorite_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_dashboard fk_dashboard_made_public_by_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboard
    ADD CONSTRAINT fk_dashboard_made_public_by_id FOREIGN KEY (made_public_by_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_dashboard fk_dashboard_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboard
    ADD CONSTRAINT fk_dashboard_ref_user_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: dashboard_tab fk_dashboard_tab_ref_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboard_tab
    ADD CONSTRAINT fk_dashboard_tab_ref_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: report_dashboardcard fk_dashboardcard_ref_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboardcard
    ADD CONSTRAINT fk_dashboardcard_ref_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: report_dashboardcard fk_dashboardcard_ref_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboardcard
    ADD CONSTRAINT fk_dashboardcard_ref_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: dashboardcard_series fk_dashboardcard_series_ref_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboardcard_series
    ADD CONSTRAINT fk_dashboardcard_series_ref_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: dashboardcard_series fk_dashboardcard_series_ref_dashboardcard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dashboardcard_series
    ADD CONSTRAINT fk_dashboardcard_series_ref_dashboardcard_id FOREIGN KEY (dashboardcard_id) REFERENCES public.report_dashboardcard(id) ON DELETE CASCADE;


--
-- Name: data_permissions fk_data_permissions_ref_db_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.data_permissions
    ADD CONSTRAINT fk_data_permissions_ref_db_id FOREIGN KEY (db_id) REFERENCES public.metabase_database(id) ON DELETE CASCADE;


--
-- Name: data_permissions fk_data_permissions_ref_permissions_group; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.data_permissions
    ADD CONSTRAINT fk_data_permissions_ref_permissions_group FOREIGN KEY (group_id) REFERENCES public.permissions_group(id) ON DELETE CASCADE;


--
-- Name: data_permissions fk_data_permissions_ref_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.data_permissions
    ADD CONSTRAINT fk_data_permissions_ref_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: metabase_database fk_database_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_database
    ADD CONSTRAINT fk_database_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE SET NULL;


--
-- Name: dimension fk_dimension_displayfk_ref_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dimension
    ADD CONSTRAINT fk_dimension_displayfk_ref_field_id FOREIGN KEY (human_readable_field_id) REFERENCES public.metabase_field(id) ON DELETE CASCADE;


--
-- Name: dimension fk_dimension_ref_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.dimension
    ADD CONSTRAINT fk_dimension_ref_field_id FOREIGN KEY (field_id) REFERENCES public.metabase_field(id) ON DELETE CASCADE;


--
-- Name: timeline_event fk_event_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline_event
    ADD CONSTRAINT fk_event_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: timeline_event fk_events_timeline_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline_event
    ADD CONSTRAINT fk_events_timeline_id FOREIGN KEY (timeline_id) REFERENCES public.timeline(id) ON DELETE CASCADE;


--
-- Name: metabase_field fk_field_parent_ref_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_field
    ADD CONSTRAINT fk_field_parent_ref_field_id FOREIGN KEY (parent_id) REFERENCES public.metabase_field(id) ON DELETE RESTRICT;


--
-- Name: metabase_field fk_field_ref_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_field
    ADD CONSTRAINT fk_field_ref_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: field_usage fk_field_usage_field_id_metabase_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.field_usage
    ADD CONSTRAINT fk_field_usage_field_id_metabase_field_id FOREIGN KEY (field_id) REFERENCES public.metabase_field(id) ON DELETE CASCADE;


--
-- Name: field_usage fk_field_usage_query_execution_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.field_usage
    ADD CONSTRAINT fk_field_usage_query_execution_id FOREIGN KEY (query_execution_id) REFERENCES public.query_execution(id) ON DELETE CASCADE;


--
-- Name: metabase_fieldvalues fk_fieldvalues_ref_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_fieldvalues
    ADD CONSTRAINT fk_fieldvalues_ref_field_id FOREIGN KEY (field_id) REFERENCES public.metabase_field(id) ON DELETE CASCADE;


--
-- Name: application_permissions_revision fk_general_permissions_revision_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.application_permissions_revision
    ADD CONSTRAINT fk_general_permissions_revision_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id);


--
-- Name: sandboxes fk_gtap_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.sandboxes
    ADD CONSTRAINT fk_gtap_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: sandboxes fk_gtap_group_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.sandboxes
    ADD CONSTRAINT fk_gtap_group_id FOREIGN KEY (group_id) REFERENCES public.permissions_group(id) ON DELETE CASCADE;


--
-- Name: sandboxes fk_gtap_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.sandboxes
    ADD CONSTRAINT fk_gtap_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: http_action fk_http_action_ref_action_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.http_action
    ADD CONSTRAINT fk_http_action_ref_action_id FOREIGN KEY (action_id) REFERENCES public.action(id) ON DELETE CASCADE;


--
-- Name: implicit_action fk_implicit_action_action_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.implicit_action
    ADD CONSTRAINT fk_implicit_action_action_id FOREIGN KEY (action_id) REFERENCES public.action(id) ON DELETE CASCADE;


--
-- Name: login_history fk_login_history_session_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT fk_login_history_session_id FOREIGN KEY (session_id) REFERENCES public.core_session(id) ON DELETE SET NULL;


--
-- Name: login_history fk_login_history_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.login_history
    ADD CONSTRAINT fk_login_history_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: metric_important_field fk_metric_important_field_metabase_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric_important_field
    ADD CONSTRAINT fk_metric_important_field_metabase_field_id FOREIGN KEY (field_id) REFERENCES public.metabase_field(id) ON DELETE CASCADE;


--
-- Name: metric_important_field fk_metric_important_field_metric_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric_important_field
    ADD CONSTRAINT fk_metric_important_field_metric_id FOREIGN KEY (metric_id) REFERENCES public.metric(id) ON DELETE CASCADE;


--
-- Name: metric fk_metric_ref_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric
    ADD CONSTRAINT fk_metric_ref_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: metric fk_metric_ref_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metric
    ADD CONSTRAINT fk_metric_ref_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: model_index fk_model_index_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.model_index
    ADD CONSTRAINT fk_model_index_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: model_index fk_model_index_model_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.model_index
    ADD CONSTRAINT fk_model_index_model_id FOREIGN KEY (model_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: model_index_value fk_model_index_value_model_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.model_index_value
    ADD CONSTRAINT fk_model_index_value_model_id FOREIGN KEY (model_index_id) REFERENCES public.model_index(id) ON DELETE CASCADE;


--
-- Name: notification_card fk_notification_card_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_card
    ADD CONSTRAINT fk_notification_card_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: notification fk_notification_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT fk_notification_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: notification_handler fk_notification_handler_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_handler
    ADD CONSTRAINT fk_notification_handler_channel_id FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: notification_handler fk_notification_handler_notification_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_handler
    ADD CONSTRAINT fk_notification_handler_notification_id FOREIGN KEY (notification_id) REFERENCES public.notification(id) ON DELETE CASCADE;


--
-- Name: notification_handler fk_notification_handler_template_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_handler
    ADD CONSTRAINT fk_notification_handler_template_id FOREIGN KEY (template_id) REFERENCES public.channel_template(id) ON DELETE SET NULL;


--
-- Name: notification_recipient fk_notification_recipient_notification_handler_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_recipient
    ADD CONSTRAINT fk_notification_recipient_notification_handler_id FOREIGN KEY (notification_handler_id) REFERENCES public.notification_handler(id) ON DELETE CASCADE;


--
-- Name: notification_recipient fk_notification_recipient_permissions_group_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_recipient
    ADD CONSTRAINT fk_notification_recipient_permissions_group_id FOREIGN KEY (permissions_group_id) REFERENCES public.permissions_group(id) ON DELETE CASCADE;


--
-- Name: notification_recipient fk_notification_recipient_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_recipient
    ADD CONSTRAINT fk_notification_recipient_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: notification_subscription fk_notification_subscription_notification_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.notification_subscription
    ADD CONSTRAINT fk_notification_subscription_notification_id FOREIGN KEY (notification_id) REFERENCES public.notification(id) ON DELETE CASCADE;


--
-- Name: parameter_card fk_parameter_card_ref_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.parameter_card
    ADD CONSTRAINT fk_parameter_card_ref_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: permissions_group_membership fk_permissions_group_group_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group_membership
    ADD CONSTRAINT fk_permissions_group_group_id FOREIGN KEY (group_id) REFERENCES public.permissions_group(id) ON DELETE CASCADE;


--
-- Name: permissions fk_permissions_group_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT fk_permissions_group_id FOREIGN KEY (group_id) REFERENCES public.permissions_group(id) ON DELETE CASCADE;


--
-- Name: permissions_group_membership fk_permissions_group_membership_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_group_membership
    ADD CONSTRAINT fk_permissions_group_membership_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: permissions fk_permissions_ref_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT fk_permissions_ref_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE CASCADE;


--
-- Name: permissions_revision fk_permissions_revision_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.permissions_revision
    ADD CONSTRAINT fk_permissions_revision_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: persisted_info fk_persisted_info_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.persisted_info
    ADD CONSTRAINT fk_persisted_info_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE SET NULL;


--
-- Name: persisted_info fk_persisted_info_database_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.persisted_info
    ADD CONSTRAINT fk_persisted_info_database_id FOREIGN KEY (database_id) REFERENCES public.metabase_database(id) ON DELETE CASCADE;


--
-- Name: persisted_info fk_persisted_info_ref_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.persisted_info
    ADD CONSTRAINT fk_persisted_info_ref_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id);


--
-- Name: pulse_card fk_pulse_card_ref_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_card
    ADD CONSTRAINT fk_pulse_card_ref_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: pulse_card fk_pulse_card_ref_pulse_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_card
    ADD CONSTRAINT fk_pulse_card_ref_pulse_card_id FOREIGN KEY (dashboard_card_id) REFERENCES public.report_dashboardcard(id) ON DELETE CASCADE;


--
-- Name: pulse_card fk_pulse_card_ref_pulse_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_card
    ADD CONSTRAINT fk_pulse_card_ref_pulse_id FOREIGN KEY (pulse_id) REFERENCES public.pulse(id) ON DELETE CASCADE;


--
-- Name: pulse_channel fk_pulse_channel_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel
    ADD CONSTRAINT fk_pulse_channel_channel_id FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: pulse_channel_recipient fk_pulse_channel_recipient_ref_pulse_channel_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel_recipient
    ADD CONSTRAINT fk_pulse_channel_recipient_ref_pulse_channel_id FOREIGN KEY (pulse_channel_id) REFERENCES public.pulse_channel(id) ON DELETE CASCADE;


--
-- Name: pulse_channel_recipient fk_pulse_channel_recipient_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel_recipient
    ADD CONSTRAINT fk_pulse_channel_recipient_ref_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: pulse_channel fk_pulse_channel_ref_pulse_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse_channel
    ADD CONSTRAINT fk_pulse_channel_ref_pulse_id FOREIGN KEY (pulse_id) REFERENCES public.pulse(id) ON DELETE CASCADE;


--
-- Name: pulse fk_pulse_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse
    ADD CONSTRAINT fk_pulse_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE SET NULL;


--
-- Name: pulse fk_pulse_ref_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse
    ADD CONSTRAINT fk_pulse_ref_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: pulse fk_pulse_ref_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.pulse
    ADD CONSTRAINT fk_pulse_ref_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: qrtz_blob_triggers fk_qrtz_blob_triggers_triggers; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_blob_triggers
    ADD CONSTRAINT fk_qrtz_blob_triggers_triggers FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_cron_triggers fk_qrtz_cron_triggers_triggers; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_cron_triggers
    ADD CONSTRAINT fk_qrtz_cron_triggers_triggers FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_simple_triggers fk_qrtz_simple_triggers_triggers; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_simple_triggers
    ADD CONSTRAINT fk_qrtz_simple_triggers_triggers FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_simprop_triggers fk_qrtz_simprop_triggers_triggers; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_simprop_triggers
    ADD CONSTRAINT fk_qrtz_simprop_triggers_triggers FOREIGN KEY (sched_name, trigger_name, trigger_group) REFERENCES public.qrtz_triggers(sched_name, trigger_name, trigger_group);


--
-- Name: qrtz_triggers fk_qrtz_triggers_job_details; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.qrtz_triggers
    ADD CONSTRAINT fk_qrtz_triggers_job_details FOREIGN KEY (sched_name, job_name, job_group) REFERENCES public.qrtz_job_details(sched_name, job_name, job_group);


--
-- Name: query_action fk_query_action_database_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_action
    ADD CONSTRAINT fk_query_action_database_id FOREIGN KEY (database_id) REFERENCES public.metabase_database(id) ON DELETE CASCADE;


--
-- Name: query_action fk_query_action_ref_action_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_action
    ADD CONSTRAINT fk_query_action_ref_action_id FOREIGN KEY (action_id) REFERENCES public.action(id) ON DELETE CASCADE;


--
-- Name: query_analysis fk_query_analysis_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_analysis
    ADD CONSTRAINT fk_query_analysis_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: query_field fk_query_field_analysis_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_field
    ADD CONSTRAINT fk_query_field_analysis_id FOREIGN KEY (analysis_id) REFERENCES public.query_analysis(id) ON DELETE CASCADE;


--
-- Name: query_field fk_query_field_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_field
    ADD CONSTRAINT fk_query_field_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: query_field fk_query_field_field_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_field
    ADD CONSTRAINT fk_query_field_field_id FOREIGN KEY (field_id) REFERENCES public.metabase_field(id) ON DELETE CASCADE;


--
-- Name: query_table fk_query_table_analysis_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_table
    ADD CONSTRAINT fk_query_table_analysis_id FOREIGN KEY (analysis_id) REFERENCES public.query_analysis(id) ON DELETE CASCADE;


--
-- Name: query_table fk_query_table_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_table
    ADD CONSTRAINT fk_query_table_card_id FOREIGN KEY (card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: query_table fk_query_table_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.query_table
    ADD CONSTRAINT fk_query_table_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: recent_views fk_recent_views_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.recent_views
    ADD CONSTRAINT fk_recent_views_ref_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: report_card fk_report_card_ref_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_report_card_ref_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: report_card fk_report_card_ref_database_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_report_card_ref_database_id FOREIGN KEY (database_id) REFERENCES public.metabase_database(id) ON DELETE CASCADE;


--
-- Name: report_card fk_report_card_ref_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_report_card_ref_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: report_card fk_report_card_source_card_id_ref_report_card_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_card
    ADD CONSTRAINT fk_report_card_source_card_id_ref_report_card_id FOREIGN KEY (source_card_id) REFERENCES public.report_card(id) ON DELETE CASCADE;


--
-- Name: report_dashboardcard fk_report_dashboardcard_ref_action_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboardcard
    ADD CONSTRAINT fk_report_dashboardcard_ref_action_id FOREIGN KEY (action_id) REFERENCES public.action(id) ON DELETE CASCADE;


--
-- Name: report_dashboardcard fk_report_dashboardcard_ref_dashboard_tab_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.report_dashboardcard
    ADD CONSTRAINT fk_report_dashboardcard_ref_dashboard_tab_id FOREIGN KEY (dashboard_tab_id) REFERENCES public.dashboard_tab(id) ON DELETE CASCADE;


--
-- Name: revision fk_revision_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.revision
    ADD CONSTRAINT fk_revision_ref_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: secret fk_secret_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.secret
    ADD CONSTRAINT fk_secret_ref_user_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id);


--
-- Name: segment fk_segment_ref_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.segment
    ADD CONSTRAINT fk_segment_ref_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: segment fk_segment_ref_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.segment
    ADD CONSTRAINT fk_segment_ref_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: core_session fk_session_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.core_session
    ADD CONSTRAINT fk_session_ref_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: native_query_snippet fk_snippet_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.native_query_snippet
    ADD CONSTRAINT fk_snippet_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE SET NULL;


--
-- Name: native_query_snippet fk_snippet_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.native_query_snippet
    ADD CONSTRAINT fk_snippet_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: table_privileges fk_table_privileges_table_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.table_privileges
    ADD CONSTRAINT fk_table_privileges_table_id FOREIGN KEY (table_id) REFERENCES public.metabase_table(id) ON DELETE CASCADE;


--
-- Name: metabase_table fk_table_ref_database_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.metabase_table
    ADD CONSTRAINT fk_table_ref_database_id FOREIGN KEY (db_id) REFERENCES public.metabase_database(id) ON DELETE CASCADE;


--
-- Name: timeline fk_timeline_collection_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline
    ADD CONSTRAINT fk_timeline_collection_id FOREIGN KEY (collection_id) REFERENCES public.collection(id) ON DELETE CASCADE;


--
-- Name: timeline fk_timeline_creator_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.timeline
    ADD CONSTRAINT fk_timeline_creator_id FOREIGN KEY (creator_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: user_key_value fk_user_key_value_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.user_key_value
    ADD CONSTRAINT fk_user_key_value_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id);


--
-- Name: user_parameter_value fk_user_parameter_value_dashboard_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.user_parameter_value
    ADD CONSTRAINT fk_user_parameter_value_dashboard_id FOREIGN KEY (dashboard_id) REFERENCES public.report_dashboard(id) ON DELETE CASCADE;


--
-- Name: user_parameter_value fk_user_parameter_value_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.user_parameter_value
    ADD CONSTRAINT fk_user_parameter_value_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;


--
-- Name: view_log fk_view_log_ref_user_id; Type: FK CONSTRAINT; Schema: public; Owner: metabase
--

ALTER TABLE ONLY public.view_log
    ADD CONSTRAINT fk_view_log_ref_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) ON DELETE CASCADE;



CREATE DATABASE customer_support WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';
ALTER DATABASE customer_support OWNER TO metabase;




--
-- PostgreSQL database dump complete
--

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

-- Dumped from database version 17.0 (Debian 17.0-1.pgdg120+1)
-- Dumped by pg_dump version 17.0 (Debian 17.0-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

--
-- PostgreSQL database cluster dump complete
--


